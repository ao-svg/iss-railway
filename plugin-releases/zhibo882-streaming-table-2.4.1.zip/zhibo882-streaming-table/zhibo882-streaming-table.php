<?php
/**
 * Plugin Name: Zhibo Streaming Table
 * Description: Live sports schedule for any site — zhibo82.com's matches and look, every match opens on the destination site. Setup wizard, sport pages and theme included; run many domains from one hub.
 * Version: 2.4.1
 * Author: Zhibo
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * Update URI: https://zhibo-hub/zhibo882-streaming-table
 */

if (!defined('ABSPATH')) exit;

define('Z882_VERSION',  '2.4.1');
define('Z882_FILE',     __FILE__);
define('Z882_DIR',      plugin_dir_path(__FILE__));
define('Z882_URL',      plugin_dir_url(__FILE__));
define('Z882_BASENAME', plugin_basename(__FILE__));

// Defaults for standalone sites; network sites get these from the hub
define('Z882_PLAYER_SITE',           'https://zhibo82.com');
define('Z882_DEFAULT_FEED_FIXTURES', 'https://iss-railway-production.up.railway.app/fixtures.json');
define('Z882_DEFAULT_FEED_LIVE',     'https://iss-railway-production.up.railway.app/live.json');

require Z882_DIR . 'includes/config.php';    // settings: hub (network) or local (standalone)
require Z882_DIR . 'includes/record.php';    // what the plugin changed, for clean removal
require Z882_DIR . 'includes/table.php';     // feeds, matching rules, rendering, [zhibo882_streaming]
require Z882_DIR . 'includes/pages.php';     // homepage + sport pages, header menu
require Z882_DIR . 'includes/theme.php';     // GeneratePress + bundled child theme
require Z882_DIR . 'includes/updater.php';   // updates from the hub
require Z882_DIR . 'includes/remote.php';    // hub commands (setup / uninstall), REST for ABS3, silent removal
if (is_admin()) require Z882_DIR . 'includes/admin.php';   // 直播设置: status + setup wizard

// Activation: the homepage gets the table right away (no wizard needed for it), then the wizard opens
register_activation_hook(__FILE__, function () {
    if (!get_option('z882_home_done')) {
        if (z882_setup_homepage()) update_option('z882_home_done', 1, false);
    }
    set_transient('z882_activation_redirect', 1, 60);
});
