<?php
/**
 * The match table: feeds, zhibo82.com's matching rules, rendering, shortcode and “加载更多”.
 */

if (!defined('ABSPATH')) exit;

// Enqueue assets
// assets/table.css is a copy of zhibo82.com's table stylesheet (the markup below uses its z82-* classes);
// assets/style.css holds the few zhibo882 additions.
add_action('wp_enqueue_scripts', function() {
    $plugin_url = Z882_URL;
    $dir        = Z882_DIR;
    $ver        = function ($file) use ($dir) { return file_exists($dir . $file) ? filemtime($dir . $file) : Z882_VERSION; };

    wp_enqueue_style('zhibo882-table', $plugin_url . 'assets/table.css', array(), $ver('assets/table.css'));
    wp_enqueue_style('zhibo882-style', $plugin_url . 'assets/style.css', array('zhibo882-table'), $ver('assets/style.css'));
    wp_enqueue_script('zhibo882-script', $plugin_url . 'assets/script.js', array(), $ver('assets/script.js'), true);

    wp_localize_script('zhibo882-script', 'z882Config', array(
        'playerSite' => z882_player_site(),
        'rotation'   => z882_cfg('rotation') ?: array(),
        'version'    => Z882_VERSION,
        'ajaxUrl'    => admin_url('admin-ajax.php'),
    ));
});


// ── Feeds ────────────────────────────────────────────────────
// A list of match objects, or null when the feed failed or answered with something else
// (e.g. {"error": "No data yet"})
function z882_fetch_json($url) {
    $response = wp_remote_get($url, array('timeout' => 15, 'user-agent' => 'Mozilla/5.0'));
    if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) return null;
    $data = json_decode(wp_remote_retrieve_body($response), true);
    if (!is_array($data) || ($data && !isset($data[0]))) return null;
    return array_values(array_filter($data, function ($m) { return is_array($m) && !empty($m['eventId']); }));
}

// Both feeds merged the way zhibo82.com merges them (live overrides fixture), cached per clock slot
function z882_fetch_matches() {
    static $memo = null;
    if ($memo !== null) return $memo;

    $dur = (int) z882_cfg('cache');
    $tz  = wp_timezone();
    $now = new DateTime('now', $tz);
    $slot_min  = intval($now->format('i')) - (intval($now->format('i')) % max(1, $dur));
    $cache_key = 'z882_feed_' . md5($now->format('Y-m-d H') . ':' . $slot_min);

    if ($dur > 0) {
        $cached = get_transient($cache_key);
        if ($cached !== false) return $memo = $cached;
    }

    $fixtures = z882_fetch_json(z882_feed_url('fixtures'));
    $live     = z882_fetch_json(z882_feed_url('live')) ?? array();

    if ($fixtures === null) {
        // Feed down: keep showing the last good copy, and try again in a minute
        $last = get_option('z882_feed_last');
        $matches = is_array($last) ? $last : array();
        set_transient($cache_key, $matches, 60);
        return $memo = $matches;
    }

    $byId = array();
    foreach ($fixtures as $m) { $m['_feed'] = 'fixture'; $byId[$m['eventId']] = $m; }
    foreach ($live as $m)     { $m['_feed'] = 'live';    $byId[$m['eventId']] = $m; }
    $matches = array_values($byId);

    update_option('z882_feed_last', $matches, false);

    if ($dur > 0) {
        $next_min = $slot_min + $dur;
        $next     = clone $now;
        $next->setTime(intval($now->format('H')), $next_min >= 60 ? $next_min - 60 : $next_min, 0);
        if ($next_min >= 60) $next->modify('+1 hour');
        set_transient($cache_key, $matches, max(60, $next->getTimestamp() - time()));
    }
    return $memo = $matches;
}

// The feed wraps some links in its redirect: https://<feed>/go?u=<real link>
function z882_unwrap_source($url) {
    $host = wp_parse_url($url, PHP_URL_HOST);
    if (!$host || $host !== wp_parse_url(z882_feed_url('fixtures'), PHP_URL_HOST)) return $url;
    parse_str((string) wp_parse_url($url, PHP_URL_QUERY), $params);
    $inner = isset($params['u']) ? (string) $params['u'] : '';
    return preg_match('~^https?://~i', $inner) ? $inner : $url;
}

// One feed entry → a row, using zhibo82.com's rules (names, Beijing time, live/ended, which
// matches are dropped). Returns null for matches zhibo82.com doesn't show.
function z882_parse_match($m) {
    $home  = !empty($m['homeTeamZH']) ? $m['homeTeamZH'] : ($m['homeTeam'] ?? '');
    $away  = !empty($m['awayTeamZH']) ? $m['awayTeamZH'] : ($m['awayTeam'] ?? '');
    $match = $away ? $home . ' vs ' . $away : $home;
    $league = !empty($m['leagueZH']) ? $m['leagueZH'] : ($m['league'] ?? '');
    $type   = $m['sportType'] ?? '';
    $feed   = $m['_feed'] ?? 'fixture';

    $dateObj = null;
    $rawDate = $rawTime = '';
    if (!empty($m['matchDateUTC'])) {
        try {
            $dateObj = new DateTime($m['matchDateUTC']);
            $dateObj->setTimezone(new DateTimeZone('Asia/Shanghai'));
            $rawDate = $dateObj->format('Y年m月d日');
            $rawTime = $dateObj->format('H:i');
        } catch (Exception $e) {}
    }

    $sourceCount = 0;
    $source1 = '';
    $ytIds   = array();   // YouTube videos among the sources (for the thumbnail strip)
    $ytCount = 0;
    foreach ($m['channels'] ?? array() as $ch) {
        foreach ($ch['sources'] ?? array() as $i => $url) {
            if (empty($url)) continue;
            // Dead per the feed's check: zhibo82.com shows no button for it, so it doesn't count here
            if (($ch['sourceWorking'][$i] ?? null) === false) continue;
            $url = z882_unwrap_source($url);
            if (!$sourceCount) $source1 = $url;
            $sourceCount++;
            if (preg_match('~(?:youtube\.com|youtu\.be)~i', $url)) {
                $ytCount++;
                if (preg_match('~(?:youtu\.be/|[?&]v=|/embed/|/live/|/shorts/|/v/)([A-Za-z0-9_-]{11})~', $url, $vm) && !in_array($vm[1], $ytIds, true)) $ytIds[] = $vm[1];
            }
        }
    }

    $isLive = false;
    $isOver = false;
    $countdown = '';
    if ($dateObj) {
        $diffMinutes = (time() - $dateObj->getTimestamp()) / 60;
        $durations   = array('Football' => 120, 'Basketball' => 180, 'Tennis' => 240, 'Cricket' => 360, 'default' => 150);
        $duration    = $durations[$type] ?? $durations['default'];

        if (($m['status'] ?? '') === 'live')                     $isLive = true;
        elseif ($diffMinutes >= -15 && $diffMinutes <= $duration) $isLive = true;
        elseif ($diffMinutes > $duration)                         $isOver = true;

        if (!$isLive && !$isOver) {
            $minsUntil = abs($diffMinutes);
            $h   = floor($minsUntil / 60);
            $min = (int) $minsUntil % 60;
            $countdown = $h > 0 ? $h . '小时' . $min . '分后' : $min . '分钟后';
        }
    }

    if ($isOver && !$sourceCount) return null;
    if ($isLive && !$sourceCount && $feed === 'live') return null;

    $isSoon = !$sourceCount || stripos($source1, 'soon') !== false;
    if ($isLive && $isSoon) return null;   // zhibo82.com skips these when rendering

    // Date label, as on zhibo82.com: 今天 / 明天 / m月d日
    $displayDate = $rawDate;
    if ($dateObj) {
        $tz  = new DateTimeZone('Asia/Shanghai');
        $day = $dateObj->format('Y-m-d');
        if ($day === (new DateTime('now', $tz))->format('Y-m-d'))          $displayDate = '今天';
        elseif ($day === (new DateTime('tomorrow', $tz))->format('Y-m-d')) $displayDate = '明天';
        else                                                               $displayDate = $dateObj->format('m月d日');
    }

    return array(
        'matchId'     => 'match-' . md5($m['eventId']),
        'match'       => $match,
        'league'      => $league,
        'type'        => $type,
        'homeLogo'    => !empty($m['homeLogo']) ? $m['homeLogo'] : '',
        'awayLogo'    => !empty($m['awayLogo']) ? $m['awayLogo'] : '',
        'rawDate'     => $rawDate,
        'rawTime'     => $rawTime,
        'ts'          => $dateObj ? $dateObj->getTimestamp() : 0,
        'day'         => $dateObj ? $dateObj->format('Ymd') : '99999999',
        'displayDate' => $displayDate,
        // 今天 / 明天 still get the date itself, small under the time (as on zhibo82.com)
        'dayDate'     => ($dateObj && $displayDate !== $dateObj->format('m月d日')) ? $dateObj->format('m月d日') : '',
        'isLive'      => $isLive,
        'isOver'      => $isOver,
        'endedAgo'    => $isOver ? $diffMinutes - $duration : null,   // minutes since its estimated end
        'isSoon'      => $isSoon,
        'sources'     => $sourceCount,
        'ytIds'       => array_slice($ytIds, 0, 4),
        // Only YouTube: hidden until the visitor's browser can reach YouTube, as on zhibo82.com
        'ytOnly'      => $sourceCount > 0 && $ytCount === $sourceCount,
        'countdown'   => $countdown,
    );
}

// Ended matches as zhibo82.com keeps them (z82_recent_ended): ended in the last 120 minutes,
// at most the 20 most recent, big competitions first, then latest first
function z882_recent_ended(array $ended, $priority) {
    $ended = array_values(array_filter($ended, function ($p) {
        return $p['endedAgo'] !== null && $p['endedAgo'] <= 120;
    }));
    $byRecent = function ($a, $b) { return $a['endedAgo'] <=> $b['endedAgo']; };
    usort($ended, $byRecent);
    $ended = array_slice($ended, 0, 20);
    usort($ended, function ($a, $b) use ($priority, $byRecent) {
        return ($priority($a) - $priority($b)) ?: $byRecent($a, $b);
    });
    return $ended;
}

// All matches zhibo82.com lists, split and sorted exactly as it does.
// 'types' always covers every sport, so a sport page's filter bar still lists the others.
function z882_collect($typeFilter = '') {
    $live = $upcoming = $ended = $types = array();
    foreach (z882_fetch_matches() as $raw) {
        $p = z882_parse_match($raw);
        if (!$p) continue;
        if ($p['type'] !== '' && !in_array($p['type'], $types, true)) $types[] = $p['type'];
        if ($typeFilter !== '' && $p['type'] !== $typeFilter) continue;
        if ($p['isLive'])     $live[]     = $p;
        elseif ($p['isOver']) $ended[]    = $p;
        else                  $upcoming[] = $p;
    }
    sort($types);

    // World Cup > Champions League > Premier League > other, then kickoff time
    $priority = function ($p) {
        $text = strtolower($p['league'] . ' ' . $p['match']);
        foreach (array('world cup','世界杯','wc 2026','wc2026','concacaf/uefa','afc/uefa','concacaf/conmebol','caf/afc','caf/uefa') as $kw) { if (strpos($text, $kw) !== false) return 0; }
        foreach (array('champions league','欧冠','冠军联赛','ucl') as $kw) { if (strpos($text, $kw) !== false) return 1; }
        foreach (array('premier league','英超') as $kw) { if (strpos($text, $kw) !== false) return 2; }
        return 3;
    };
    $sortFn = function ($a, $b) use ($priority) {
        $pa = $priority($a); $pb = $priority($b);
        if ($pa !== $pb) return $pa - $pb;
        return $a['ts'] - $b['ts'];
    };
    // Upcoming: soonest day first, big competitions first within a day
    $upcomingSortFn = function ($a, $b) use ($sortFn) {
        if ($a['day'] !== $b['day']) return strcmp($a['day'], $b['day']);
        return $sortFn($a, $b);
    };
    usort($live, $sortFn);
    usort($upcoming, $upcomingSortFn);
    $ended = z882_recent_ended($ended, $priority);

    return compact('live', 'upcoming', 'ended', 'types');
}

// Upcoming rows to show: the first N overall plus however many were loaded per sport.
// Each sport's rows keep the overall order, so what's shown is always a prefix of each sport.
function z882_page_upcoming($upcoming, $limits) {
    $pageSize  = z882_upcoming_page_size();
    $remaining = array('' => 0);
    if ($pageSize <= 0) return array($upcoming, $remaining);

    $overall  = max($pageSize, (int) ($limits[''] ?? 0));
    $shown    = array();
    $sportIdx = array();
    foreach ($upcoming as $i => $p) {
        $t = $p['type'];
        $sportIdx[$t] = isset($sportIdx[$t]) ? $sportIdx[$t] + 1 : 0;
        if ($i < $overall || $sportIdx[$t] < (int) ($limits[$t] ?? 0)) {
            $shown[] = $p;
        } else {
            $remaining['']++;
            $remaining[$t] = ($remaining[$t] ?? 0) + 1;
        }
    }
    return array($shown, $remaining);
}

function z882_keyword_list($leagueKeywords) {
    return array_map('strtolower', array_filter(array_map('trim', explode(',', (string) $leagueKeywords))));
}

function z882_kw_hidden($m, $keywordList) {
    if (!$keywordList) return false;
    $text = strtolower($m['league'] . ' ' . $m['match']);
    foreach ($keywordList as $kw) { if (strpos($text, $kw) !== false) return false; }
    return true;
}

// Only the attributes that shape the table, sanitised — they round-trip through the browser
function z882_public_atts($atts) {
    return array(
        'type_filter'     => sanitize_text_field($atts['type_filter'] ?? ''),
        'league_keywords' => sanitize_text_field($atts['league_keywords'] ?? ''),
    );
}

function z882_sanitize_limits($limits) {
    $out = array();
    if (!is_array($limits)) return $out;
    foreach (array_slice($limits, 0, 50, true) as $sport => $n) {
        $out[sanitize_text_field((string) $sport)] = min(absint($n), 5000);
    }
    return $out;
}

// ── Sport pages ──────────────────────────────────────────────
// "Ice Hockey" → "ice-hockey": the same slug zhibo82.com uses in its #football routes
function z882_sport_slug($type) {
    return trim(preg_replace('/[^a-z0-9]+/', '-', strtolower((string) $type)), '-');
}

// The published page for a sport — the one picked in the setup wizard, else /<sport-slug>/ — or null
function z882_sport_page($type) {
    static $pages = array();
    if ($type === '') return null;
    if (!array_key_exists($type, $pages)) {
        $map  = (array) get_option('z882_pages', array());
        $page = !empty($map[$type]) ? get_post((int) $map[$type]) : get_page_by_path(z882_sport_slug($type));
        $pages[$type] = ($page && $page->post_type === 'page' && $page->post_status === 'publish') ? $page : null;
    }
    return $pages[$type];
}

// Where a match opens on zhibo82.com — inside its sport's view when listed on a sport page
function z882_watch_url($matchId, $sportContext = '') {
    $route = $sportContext !== '' ? z882_sport_slug($sportContext) . '/' . $matchId : $matchId;
    return z882_player_site() . '/#' . $route;
}

// ── Main shortcode ───────────────────────────────────────────
add_shortcode('zhibo882_streaming', 'z882_streaming_shortcode');
function z882_streaming_shortcode($atts) {
    $atts = shortcode_atts(array(
        'type_filter'      => '',
        'show_type_filter' => 'true',
        'league_keywords'  => '',
        'heading'          => '',
        'show_date'        => 'false',
        'date_subtitle'    => '今日直播赛事',
        'all_matches_url'  => '',
        'no_match_action'  => 'message',
    ), $atts);

    return z882_generate_table($atts);
}

function z882_generate_table($atts) {
    $typeFilter = (string) $atts['type_filter'];
    $data       = z882_collect($typeFilter);
    if (!$data['types']) return '<div class="z82-wrapper z882-wrapper"><div class="z82-error">暂无比赛数据</div></div>';

    $tableId     = 'z882-table-' . uniqid();
    $keywordList = z882_keyword_list($atts['league_keywords']);
    $showFilters = $atts['show_type_filter'] === 'true';

    list($upShown, $remaining) = z882_page_upcoming($data['upcoming'], array());

    // Would ANY row survive the keyword filter? "show_all" drops the filter when none would
    $all = array_merge($data['ended'], $data['live'], $upShown);
    $allKwHidden = (bool) $keywordList && (bool) $all;
    foreach ($all as $m) { if (!z882_kw_hidden($m, $keywordList)) { $allKwHidden = false; break; } }
    $showAll = $allKwHidden && $atts['no_match_action'] === 'show_all';
    if ($showAll) $keywordList = array();

    ob_start();
    ?>
    <div class="z82-wrapper z882-wrapper"
         data-atts="<?php echo esc_attr(wp_json_encode(z882_public_atts($atts))); ?>"
         data-page="<?php echo esc_attr(z882_upcoming_page_size()); ?>"
         <?php if (!empty($atts['all_matches_url'])) echo 'data-all-matches-url="' . esc_attr($atts['all_matches_url']) . '"'; ?>
         <?php if ($keywordList) echo 'data-keywords="' . esc_attr($atts['league_keywords']) . '"'; ?>>

        <?php if ($keywordList): ?>
        <div class="z82-kw-reset-bar">
            <span class="z82-kw-reset-label">当前为筛选视图</span>
            <button type="button" class="z82-kw-reset-btn" onclick="z882ResetKeywords('<?php echo esc_js($tableId); ?>')">查看所有比赛</button>
        </div>
        <?php endif; ?>

        <?php if (!empty($atts['heading']) || $atts['show_date'] === 'true'): ?>
        <?php
        $today   = new DateTime('now', wp_timezone());
        $weekday = array('日', '一', '二', '三', '四', '五', '六')[(int) $today->format('w')];
        ?>
        <div class="z882-header">
            <?php if (!empty($atts['heading'])): ?>
            <h2 class="z882-heading"><?php echo esc_html($atts['heading']); ?></h2>
            <?php endif; ?>
            <?php if ($atts['show_date'] === 'true'): ?>
            <div class="z882-date-row">
                <span class="z882-date-cn"><?php echo esc_html($today->format('Y年m月d日') . '（星期' . $weekday . '）'); ?></span>
                <?php if (!empty($atts['date_subtitle'])): ?>
                <span class="z882-date-subtitle"><?php echo esc_html($atts['date_subtitle']); ?></span>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </div>
        <?php endif; ?>

        <?php echo z882_render_yt_strip(array_merge($data['live'], $upShown), $typeFilter); ?>

        <?php if ($showFilters): ?>
        <?php echo z882_render_filters($tableId, $data['types'], $typeFilter, (bool) $keywordList); ?>
        <?php endif; ?>

        <div class="z82-tz-note">时间均为北京时间（UTC+8）</div>

        <div class="z82-table-container" id="<?php echo esc_attr($tableId); ?>">
            <?php
            if (!$data['live'] && !$data['upcoming'] && !$data['ended']) {
                // A sport page while that sport has nothing scheduled
                echo '<div class="z82-no-matches"><div class="z82-no-matches-title">暂无' . esc_html(z882_get_sport_name_cn($typeFilter)) . '比赛</div>'
                   . '<div class="z82-no-matches-text">新的赛事会在开赛前自动上线，请稍后再来。</div>'
                   . '<a class="z82-btn-reset-filter" href="' . esc_url(home_url('/')) . '">查看全部比赛</a></div>';
            }

            if ($allKwHidden && !$showAll) {
                echo '<div class="z82-no-matches" id="z882-kw-nomatch-' . esc_attr($tableId) . '"><div class="z82-no-matches-title">暂无相关比赛</div>'
                   . '<button type="button" class="z82-btn-reset-filter" onclick="z882ResetKeywords(\'' . esc_js($tableId) . '\')">查看所有比赛</button></div>';
            }

            // Same order as zhibo82.com: ended (3 visible, the rest behind a toggle) → live → upcoming
            $ended = $data['ended'];
            if (count($ended) > 3): ?>
            <button type="button" class="z82-ended-info" aria-expanded="false" onclick="z882ToggleEnded(this)">
                <span class="z82-ended-info-label" data-show="显示全部 <?php echo count($ended); ?> 场已结束的比赛" data-hide="收起已结束的比赛">显示全部 <?php echo count($ended); ?> 场已结束的比赛</span>
                <svg class="z82-icon z82-ended-info-chevron" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>
            </button>
            <?php endif;
            foreach ($ended as $i => $m)  echo z882_render_row($m, $typeFilter, $i >= 3, z882_kw_hidden($m, $keywordList));
            foreach ($data['live'] as $m) echo z882_render_row($m, $typeFilter, false, z882_kw_hidden($m, $keywordList));
            ?>
            <div class="z882-upcoming">
                <?php echo z882_render_upcoming($upShown, $remaining, $typeFilter, $keywordList); ?>
            </div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

// Sport filter bar, as on zhibo82.com. A sport with its own page links to it; others filter in place
// (from another sport's page they go to the front page's #<sport> view).
function z882_render_filters($tableId, $types, $current, $hidden) {
    $btn = function ($type, $label, $icon) use ($tableId, $current) {
        $active = $type === $current;
        $attrs  = 'class="z82-filter-btn' . ($active ? ' active' : '') . '" data-sport="' . esc_attr($type) . '"'
                . ' data-slug="' . esc_attr(z882_sport_slug($type)) . '" role="tab" aria-selected="' . ($active ? 'true' : 'false') . '"';
        $inner  = $icon . '<span>' . esc_html($label) . '</span>';

        if ($type === '') {
            if ($current === '') return '<button type="button" ' . $attrs . ' onclick="z882FilterType(\'' . esc_js($tableId) . '\', \'\', this)">' . $inner . '</button>';
            return '<a ' . $attrs . ' href="' . esc_url(home_url('/')) . '">' . $inner . '</a>';
        }
        $page = z882_sport_page($type);
        if ($page)          return '<a ' . $attrs . ' href="' . esc_url(get_permalink($page)) . '">' . $inner . '</a>';
        if ($current === '') return '<button type="button" ' . $attrs . ' onclick="z882FilterType(\'' . esc_js($tableId) . '\', this.getAttribute(\'data-sport\'), this)">' . $inner . '</button>';
        return '<a ' . $attrs . ' href="' . esc_url(home_url('/#' . z882_sport_slug($type))) . '">' . $inner . '</a>';
    };

    $out  = '<div class="z82-filters-wrap"' . ($hidden ? ' id="z882-filter-container-hidden" hidden' : '') . '>';
    $out .= '<nav class="z82-filters" role="tablist" aria-label="运动类型">';
    $out .= $btn('', '全部', '');
    foreach ($types as $type) $out .= $btn($type, z882_get_sport_name_cn($type), z882_get_sport_icon($type));
    $out .= '</nav></div>';
    return $out;
}

function z882_render_upcoming($rows, $remaining, $sportContext, $keywordList) {
    $out = '';
    foreach ($rows as $m) $out .= z882_render_row($m, $sportContext, false, z882_kw_hidden($m, $keywordList));
    if ($remaining[''] > 0) {
        $out .= '<button type="button" class="z82-load-more" data-remaining="' . esc_attr(wp_json_encode($remaining)) . '" onclick="z882LoadMore(this)">'
              . '<span class="z82-load-more-label">加载更多比赛</span><span class="z82-load-more-count"></span></button>';
    }
    return $out;
}

// “加载更多”: the upcoming section again, with more rows for the sport being viewed
function z882_ajax_more() {
    $atts   = json_decode(wp_unslash($_POST['atts'] ?? '{}'), true);
    $atts   = z882_public_atts(is_array($atts) ? $atts : array());
    $limits = z882_sanitize_limits(json_decode(wp_unslash($_POST['limits'] ?? '{}'), true));

    $data = z882_collect($atts['type_filter']);
    list($rows, $remaining) = z882_page_upcoming($data['upcoming'], $limits);

    // Rows the visitor un-filtered client side come back unfiltered too
    $keywordList = (($_POST['kw'] ?? '1') === '1') ? z882_keyword_list($atts['league_keywords']) : array();
    wp_send_json_success(array('html' => z882_render_upcoming($rows, $remaining, $atts['type_filter'], $keywordList)));
}
add_action('wp_ajax_z882_more', 'z882_ajax_more');
add_action('wp_ajax_nopriv_z882_more', 'z882_ajax_more');

// One match: zhibo82.com's row, where the whole row is a link to that match on zhibo82.com
// YouTube thumbnail strip: live matches first, then upcoming ones; each card opens the match on the
// destination site. Rendered hidden with the images not yet requested — script.js shows it only
// when the visitor's browser can reach YouTube and the thumbnails actually load.
function z882_render_yt_strip($matches, $sportContext = '') {
    $cards = '';
    $n = 0;
    foreach ($matches as $m) {
        if (empty($m['ytIds'])) continue;
        $cards .= '<a class="z882-yt-thumb" href="' . esc_url(z882_watch_url($m['matchId'], $sportContext)) . '" target="_blank" rel="nofollow noopener" hidden>'
            . '<span class="z882-yt-img-wrap"><img alt="" width="320" height="180" decoding="async" data-src="' . esc_url('https://i.ytimg.com/vi/' . $m['ytIds'][0] . '/mqdefault.jpg') . '">'
            . '<span class="z882-yt-play" aria-hidden="true"><span class="z882-yt-play-icon"></span></span>'
            . ($m['isLive'] ? '<span class="z882-yt-live"><span class="z82-live-dot" aria-hidden="true"></span>直播</span>' : '')
            . '</span><span class="z882-yt-label">' . esc_html($m['match']) . '</span></a>';
        if (++$n >= 20) break;
    }
    return $cards ? '<div class="z882-yt-strip-wrap" data-yt-strip hidden><div class="z882-yt-strip">' . $cards . '</div></div>' : '';
}

function z882_render_row($m, $sportContext = '', $hidden = false, $kwHidden = false) {
    $classes = 'z82-match-row ' . ($m['isLive'] ? 'live' : ($m['isOver'] ? 'finished' : 'upcoming'));
    if ($hidden)   $classes .= ' z82-match-hidden';
    if ($kwHidden) $classes .= ' z82-kw-hidden';
    if (!empty($m['ytOnly'])) $classes .= ' z882-yt-only';

    $watchUrl = z882_watch_url($m['matchId'], $sportContext);

    ob_start();
    ?>
    <div class="<?php echo esc_attr($classes); ?>" data-type="<?php echo esc_attr($m['type']); ?>" data-match-id="<?php echo esc_attr($m['matchId']); ?>" data-search="<?php echo esc_attr(strtolower($m['league'] . ' ' . $m['match'])); ?>">
        <a class="z82-row-header" href="<?php echo esc_url($watchUrl); ?>" target="_blank" rel="nofollow noopener">
            <div class="z82-row-time">
                <div class="z82-date"><?php echo esc_html($m['displayDate']); ?></div>
                <div class="z82-time"><?php echo esc_html($m['rawTime']); ?></div>
                <?php if (!empty($m['dayDate'])): ?><div class="z82-day"><?php echo esc_html($m['dayDate']); ?></div><?php endif; ?>
            </div>
            <div class="z82-row-info">
                <?php if ($m['homeLogo'] || $m['awayLogo']): ?>
                <div class="z82-team-logos">
                    <?php if ($m['homeLogo']): ?><img src="<?php echo esc_url($m['homeLogo']); ?>" class="z82-team-badge" loading="lazy" onerror="this.style.display='none'" alt="" /><?php endif; ?>
                    <?php if ($m['awayLogo']): ?><span class="z82-vs-sep">vs</span><img src="<?php echo esc_url($m['awayLogo']); ?>" class="z82-team-badge" loading="lazy" onerror="this.style.display='none'" alt="" /><?php endif; ?>
                </div>
                <?php endif; ?>
                <div class="z82-teams"><?php echo esc_html($m['match']); ?></div>
                <div class="z82-league"><?php echo z882_get_sport_icon($m['type']); ?> <?php echo esc_html($m['league']); ?></div>
            </div>
            <div class="z82-row-right">
                <?php if ($m['isLive']): ?>
                <span class="z82-live-badge"><span class="z82-live-dot" aria-hidden="true"></span>直播中</span>
                <?php elseif ($m['isOver']): ?>
                <span class="z82-ended-badge">已结束</span>
                <?php elseif ($m['countdown']): ?>
                <span class="z82-countdown" data-start="<?php echo esc_attr($m['ts']); ?>"><?php echo esc_html($m['countdown']); ?></span>
                <?php endif; ?>
                <?php if ($m['sources'] && !$m['isSoon']): ?>
                <span class="z82-sources-count"><?php echo (int) $m['sources']; ?>个直播</span>
                <?php elseif ($m['isSoon'] && !$m['isOver']): ?>
                <span class="z82-soon-badge">即将上线</span>
                <?php endif; ?>
                <svg class="z82-icon z82-chevron z882-go" viewBox="0 0 24 24" aria-hidden="true"><path d="M9 6l6 6-6 6"/></svg>
            </div>
        </a>
        <?php if (!$m['isOver'] && $m['rawDate'] && $m['rawTime']) echo z882_build_schema($m, $watchUrl, z882_player_site()); ?>
    </div>
    <?php
    return ob_get_clean();
}

function z882_build_schema($m, $matchUrl, $siteUrl) {
    // Build ISO 8601 startDate with +08:00 from Chinese date/time
    $startDate = '';
    if (preg_match('/(\d{4})年(\d{2})月(\d{2})日/', $m['rawDate'], $dm)) {
        $timeClean = preg_replace('/^(\d{1,2}:\d{2}).*$/', '$1', $m['rawTime']);
        // Pad hour if needed
        if (preg_match('/^(\d):/', $timeClean, $hm)) {
            $timeClean = '0' . $timeClean;
        }
        $startDate = $dm[1] . '-' . $dm[2] . '-' . $dm[3] . 'T' . $timeClean . ':00+08:00';
    }

    if (!$startDate) return '';

    // Event status
    if ($m['isLive']) {
        $status = 'https://schema.org/EventScheduled'; // live = in progress, still scheduled
    } else {
        $status = 'https://schema.org/EventScheduled';
    }

    // Sport name map for schema
    $sports = array(
        'Football' => 'Football', 'Basketball' => 'Basketball',
        'Tennis' => 'Tennis', 'Cricket' => 'Cricket',
        'Rugby' => 'Rugby', 'Golf' => 'Golf',
        'Table Tennis' => 'Table Tennis', 'Volleyball' => 'Volleyball',
        'Cycling' => 'Cycling', 'Darts' => 'Darts',
        'Ice Hockey' => 'Ice Hockey', 'Motorsport' => 'Motorsport',
        'UFC/MMA' => 'Mixed Martial Arts', 'Baseball' => 'Baseball',
    );
    $sport = isset($sports[$m['type']]) ? $sports[$m['type']] : $m['type'];

    $description = esc_js($m['league'] ? $m['league'] . ' — 免费直播' : '免费直播');
    $name        = esc_js($m['match']);
    $sport       = esc_js($sport);
    $matchUrl    = esc_url($siteUrl . '/#' . $m['matchId']);
    $siteUrl     = esc_url($siteUrl . '/');

    $schema = array(
        '@context'             => 'https://schema.org',
        '@type'                => 'SportsEvent',
        'name'                 => $m['match'],
        'startDate'            => $startDate,
        'eventStatus'          => $status,
        'eventAttendanceMode'  => 'https://schema.org/OnlineEventAttendanceMode',
        'sport'                => $sport,
        'description'          => ($m['league'] ? $m['league'] . ' — 免费直播' : '免费直播'),
        'url'                  => $siteUrl,
        'isAccessibleForFree'  => true,
        'location'             => array(
            '@type' => 'VirtualLocation',
            'url'   => $siteUrl,
        ),
        'offers'               => array(
            '@type'        => 'Offer',
            'price'        => '0',
            'priceCurrency' => 'CNY',
            'availability' => 'https://schema.org/InStock',
            'url'          => $siteUrl,
        ),
    );

    if (!empty($m['league'])) {
        $schema['organizer'] = array(
            '@type' => 'SportsOrganization',
            'name'  => $m['league'],
        );
    }

    // BroadcastEvent — isLiveBroadcast true for live, false for upcoming
    $siteName = parse_url($siteUrl, PHP_URL_HOST) ?: 'zhibo882.com';
    $schema['subjectOf'] = array(
        '@type'                => 'BroadcastEvent',
        'name'                 => $m['match'] . ($m['isLive'] ? ' 直播' : ' 即将直播'),
        'isLiveBroadcast'      => (bool) $m['isLive'],
        'broadcastDisplayName' => $siteName,
        'videoFormat'          => 'HD',
        'publishedOn'          => array(
            '@type'                  => 'BroadcastService',
            'name'                   => $siteName,
            'broadcastDisplayName'   => $siteName,
            'broadcastTimezone'      => 'Asia/Shanghai',
            'broadcastAffiliateOf'   => array(
                '@type' => 'Organization',
                'name'  => $siteName,
                'url'   => $siteUrl,
            ),
        ),
    );

    return '<script type="application/ld+json">' . json_encode($schema, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . '</script>' . "\n";
}

// ── Sport icon helper (same SVG icons as zhibo82.com) ───────
function z882_get_sport_icon($type) {
    $paths = [
        'football'   => '<circle cx="12" cy="12" r="9"/><path d="M12 7.5l4.3 3.1-1.6 5H9.3l-1.6-5z"/><path d="M12 7.5V3.2M16.3 10.6l4.2-1.4M14.7 15.6l2.6 3.6M9.3 15.6l-2.6 3.6M7.7 10.6L3.5 9.2"/>',
        'basketball' => '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3v18"/><path d="M5.6 5.6a9 9 0 0 1 2.6 6.4 9 9 0 0 1-2.6 6.4M18.4 5.6a9 9 0 0 0-2.6 6.4 9 9 0 0 0 2.6 6.4"/>',
        'ball'       => '<circle cx="12" cy="12" r="9"/><path d="M5.2 5.9a9.5 9.5 0 0 1 0 12.2M18.8 5.9a9.5 9.5 0 0 0 0 12.2"/>',
        'oval'       => '<ellipse cx="12" cy="12" rx="10" ry="6" transform="rotate(-45 12 12)"/><path d="M9 15l6-6M9.6 12.6l1.8 1.8M11.1 11.1l1.8 1.8M12.6 9.6l1.8 1.8"/>',
        'hockey'     => '<path d="M5 3l6.5 13.5H19a1.5 1.5 0 0 1 0 3h-8.5a1.5 1.5 0 0 1-1.3-.8L2.5 4.2"/><ellipse cx="5" cy="19" rx="2.8" ry="1.4"/>',
        'cricket'    => '<path d="M17 4.5l2.5 2.5-10 10-3.5 1 1-3.5z"/><path d="M18.5 5.5L21 3"/><circle cx="6" cy="6" r="2.2"/>',
        'golf'       => '<path d="M12 18V3l7 3.5-7 3.5"/><ellipse cx="12" cy="18.5" rx="7" ry="2.5"/>',
        'racing'     => '<path d="M5 21V4"/><path d="M5 4h13.5l-2.5 4.5 2.5 4.5H5"/>',
        'pingpong'   => '<circle cx="10" cy="10" r="6.5"/><path d="M14.6 14.6l5 5"/><circle cx="19" cy="5.5" r="1.8"/>',
        'fight'      => '<path d="M7 12V8a5 5 0 0 1 10 0v5a4 4 0 0 1-4 4H9.5A2.5 2.5 0 0 1 7 14.5z"/><path d="M7 11H5.5a2 2 0 0 0 0 4H7"/><path d="M9 17v4h6.5v-4.3"/>',
        'volleyball' => '<circle cx="12" cy="12" r="9"/><path d="M12 3c-1 3.5-.5 6.5 0 9M12 12c2.8 1.8 5.8 2.5 8.6 1.8M12 12c-2.3 2.5-3.5 5.3-3.6 8.3"/>',
        'darts'      => '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
        'cue'        => '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="3.5"/>',
        'cycling'    => '<circle cx="6" cy="16" r="3.5"/><circle cx="18" cy="16" r="3.5"/><path d="M6 16l3.5-7h6L18 16M9.5 9l2.5 7H6M15.5 9l-1-3h-2"/>',
        'horse'      => '<path d="M7 20H4.5L4 12a8 8 0 0 1 16 0l-.5 8H17l.4-8a5.4 5.4 0 0 0-10.8 0z"/>',
        'timer'      => '<circle cx="12" cy="13" r="8"/><path d="M12 13V9M10 2h4M12 2v3"/>',
        'trophy'     => '<path d="M8 21h8M12 17v4M7 4h10v5a5 5 0 0 1-10 0z"/><path d="M17 5h3v2a3 3 0 0 1-3 3M7 5H4v2a3 3 0 0 0 3 3"/>',
    ];
    $map = [
        'Football' => 'football', 'Soccer' => 'football',
        'Basketball' => 'basketball', 'Netball' => 'basketball',
        'Tennis' => 'ball', 'Baseball' => 'ball',
        'American Football' => 'oval', 'Rugby' => 'oval', 'Australian Rules' => 'oval',
        'Ice Hockey' => 'hockey', 'Cricket' => 'cricket', 'Golf' => 'golf',
        'Motorsport' => 'racing', 'MotoGP' => 'racing',
        'Table Tennis' => 'pingpong',
        'Boxing' => 'fight', 'UFC/MMA' => 'fight',
        'Volleyball' => 'volleyball', 'Handball' => 'volleyball', 'Water Polo' => 'volleyball',
        'Darts' => 'darts', 'Snooker' => 'cue', 'Billiard' => 'cue',
        'Cycling' => 'cycling', 'Horse Racing' => 'horse',
        'Athletics' => 'timer', 'Swimming' => 'timer', 'Weightlifting' => 'timer', 'Gymnastics' => 'timer',
    ];
    $key = $map[$type] ?? 'trophy';
    return '<svg class="z82-icon z82-sport-icon" viewBox="0 0 24 24" aria-hidden="true">' . $paths[$key] . '</svg>';
}

// Same names as zhibo82.com
function z882_get_sport_name_cn($type) {
    $names = array(
        'Football' => '足球', 'Soccer' => '足球',
        'Basketball' => '篮球', 'American Football' => '美式橄榄球',
        'Tennis' => '网球', 'Table Tennis' => '乒乓球',
        'Cricket' => '板球', 'Rugby' => '橄榄球',
        'Ice Hockey' => '冰球', 'Baseball' => '棒球',
        'Golf' => '高尔夫', 'Boxing' => '拳击',
        'Volleyball' => '排球', 'Cycling' => '自行车',
        'Motorsport' => '赛车', 'MotoGP' => '摩托车',
        'Darts' => '飞镖', 'Snooker' => '斯诺克',
        'Billiard' => '台球', 'UFC/MMA' => '综合格斗',
        'Horse Racing' => '赛马', 'Handball' => '手球',
        'Australian Rules' => '澳式橄榄球', 'Netball' => '无板篮球',
        'Water Polo' => '水球', 'Athletics' => '田径',
        'Gymnastics' => '体操', 'Weightlifting' => '举重',
        'Other' => '其他',
    );
    return isset($names[$type]) ? $names[$type] : $type;
}
