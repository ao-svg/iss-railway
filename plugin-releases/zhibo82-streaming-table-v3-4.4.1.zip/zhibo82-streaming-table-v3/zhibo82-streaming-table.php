<?php
/**
 * Plugin Name: Zhibo82 Streaming Table
 * Plugin URI: https://zhibo82.com
 * Description: Sports streaming table — live HLS player + fixture links
 * Version: 4.4.1
 * Update URI: https://zhibo-hub/zhibo82-streaming-table-v3
 * Author: Zhibo82
 * License: GPL v2 or later
 * Text Domain: zhibo82-streaming-table
 */

if (!defined('ABSPATH')) exit;

define('Z82_PLUGIN_URL',   plugin_dir_url(__FILE__));
define('Z82_PLUGIN_PATH',  plugin_dir_path(__FILE__));
define('Z82_VERSION',      '4.4.1');
define('Z82_PLUGIN_FILE',  __FILE__);

// ── Data feeds ────────────────────────────────────────────────
// Set under Settings → Zhibo82. Feed URLs are used only on the server; the page gets the feed's
// play links (/go?u=…, relayed), screenshots/GIFs are served from this site — includes/feed.php.
define('Z82_DEFAULT_FEED_FIXTURES', 'https://iss-railway-production.up.railway.app/fixtures.json');
define('Z82_DEFAULT_FEED_LIVE',     'https://iss-railway-production.up.railway.app/live.json');

require Z82_PLUGIN_PATH . 'includes/feed.php';

require Z82_PLUGIN_PATH . 'includes/hub.php';   // player site of the network: check-ins, feeds and updates from the hub

require Z82_PLUGIN_PATH . 'includes/push.php';

register_deactivation_hook(__FILE__, function () {
    wp_clear_scheduled_hook('z82_push_cron');
    wp_clear_scheduled_hook('z82_media_cleanup');
    wp_clear_scheduled_hook('z82_media_cleanup');
});

// ── Popup stream player page ──────────────────────────────────
// Intercepts ?z82_stream=1&url=...&title=... and serves a standalone player page
add_action('init', function() {
    if (!isset($_GET['z82_stream']) || $_GET['z82_stream'] !== '1') return;

    // Older links double-encoded the URL; a plain one (e.g. the feed's /go?u=<encoded link>)
    // must not be decoded again or its inner link falls apart
    $param = function ($k) {
        if (!isset($_GET[$k])) return '';
        $v = (string) wp_unslash($_GET[$k]);
        return esc_url_raw(preg_match('~^https?://~i', $v) ? $v : urldecode($v));
    };
    $url   = $param('url');
    $raw   = $param('raw');   // the real link, tried once if the feed's relay link fails
    if ($raw === $url) $raw = '';
    $title = isset($_GET['title']) ? sanitize_text_field(urldecode($_GET['title'])) : '直播';
    $idx   = isset($_GET['src'])   ? intval($_GET['src']) : 0;
    $total = isset($_GET['total']) ? intval($_GET['total']) : 1;

    if (empty($url)) wp_die('Missing stream URL');

    $isYouTube = (strpos($url, 'youtube.com') !== false || strpos($url, 'youtu.be') !== false);
    $hlsjsUrl  = 'https://cdn.jsdelivr.net/npm/hls.js@1.5.14/dist/hls.min.js';

    header('Content-Type: text/html; charset=utf-8');
    header('X-Frame-Options: SAMEORIGIN');
    header('Referrer-Policy: no-referrer');
    ?><!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="referrer" content="no-referrer">
<title><?php echo esc_html($title); ?> — 直播</title>
<style>
* { margin: 0; padding: 0; box-sizing: border-box; }
html, body { width: 100%; height: 100%; background: #0a0a0a; color: #fff; font-family: -apple-system, sans-serif; overflow: hidden; }

#wrap { display: flex; flex-direction: column; height: 100vh; }

#topbar {
    display: flex; align-items: center; gap: 12px;
    padding: 10px 16px;
    background: #111;
    border-bottom: 1px solid #222;
    flex-shrink: 0;
}
#topbar h1 { font-size: 14px; font-weight: 600; flex: 1; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
#src-btns { display: flex; gap: 6px; }
.src-btn {
    background: #222; border: 1px solid #333; color: #ccc;
    padding: 4px 12px; border-radius: 4px; font-size: 12px; cursor: pointer;
}
.src-btn.active { background: #f59e0b; border-color: #f59e0b; color: #000; font-weight: 700; }
.src-btn:hover:not(.active) { background: #333; }

#player-wrap { position: relative; flex: 1; background: #000; overflow: hidden; }
#player-wrap video, #player-wrap iframe {
    width: 100%; height: 100%; display: block; border: none;
}

/* Status overlay */
#overlay {
    position: absolute; inset: 0;
    background: rgba(0,0,0,0.85);
    display: flex; flex-direction: column;
    align-items: center; justify-content: center;
    gap: 14px; z-index: 10;
}
#overlay.hidden { display: none; }

.prog-wrap { display: flex; align-items: center; gap: 10px; width: 280px; }
.prog-bar { flex: 1; height: 4px; background: rgba(255,255,255,0.15); border-radius: 2px; overflow: hidden; }
.prog-fill { height: 100%; background: #f59e0b; border-radius: 2px; transition: width 0.4s ease; }
.prog-pct { color: rgba(255,255,255,0.4); font-size: 11px; font-family: monospace; min-width: 28px; }

#status { font-size: 15px; font-weight: 600; }
#substatus { font-size: 12px; color: rgba(255,255,255,0.5); }

.retry-btn {
    margin-top: 4px;
    background: #f59e0b; color: #000;
    border: none; padding: 10px 28px;
    border-radius: 6px; font-size: 14px;
    font-weight: 700; cursor: pointer;
}

#bottombar {
    padding: 8px 16px;
    background: #111;
    border-top: 1px solid #1a1a1a;
    font-size: 11px; color: #555;
    flex-shrink: 0;
}

/* URL bar */
#url-bar {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 8px 12px;
    background: #0d0d0d;
    border-top: 1px solid #222;
    flex-shrink: 0;
}
#url-label {
    color: #555;
    font-size: 11px;
    white-space: nowrap;
    flex-shrink: 0;
}
#url-display {
    flex: 1;
    background: #1a1a1a;
    border: 1px solid #333;
    color: #aaa;
    font-size: 11px;
    font-family: monospace;
    padding: 4px 8px;
    border-radius: 4px;
    min-width: 0;
    cursor: text;
}
#url-display:focus { outline: 1px solid #f59e0b; color: #fff; }
#copy-btn, #vlc-link {
    background: #222;
    border: 1px solid #333;
    color: #aaa;
    padding: 4px 10px;
    border-radius: 4px;
    font-size: 11px;
    cursor: pointer;
    white-space: nowrap;
    text-decoration: none;
    flex-shrink: 0;
}
#copy-btn:hover, #vlc-link:hover { background: #333; color: #fff; }
#copy-btn.copied { background: #14532d; color: #4ade80; border-color: #166534; }
</style>
</head>
<body>
<div id="wrap">
    <div id="topbar">
        <h1 id="match-title"><?php echo esc_html($title); ?></h1>
        <div id="src-btns"></div>
        <button class="src-btn" onclick="window.close()" style="color:#888" aria-label="关闭"><svg width="12" height="12" viewBox="0 0 12 12" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M2 2l8 8M10 2l-8 8"/></svg></button>
    </div>

    <div id="player-wrap">
        <div id="overlay">
            <div class="prog-wrap">
                <div class="prog-bar"><div class="prog-fill" id="prog" style="width:0%"></div></div>
                <div class="prog-pct" id="pct">0%</div>
            </div>
            <div id="status">正在连接...</div>
            <div id="substatus"></div>
        </div>
        <video id="vid" controls autoplay playsinline style="display:none"></video>
    </div>

    <!-- URL bar: always visible so user can copy to VLC etc. -->
    <div id="url-bar">
        <span id="url-label">直播地址</span>
        <input id="url-display" type="text" readonly onclick="this.select()" value="" />
        <button onclick="copyUrl()" id="copy-btn">复制</button>
        <a id="vlc-link" href="" target="_blank">VLC ↗</a>
    </div>

    <div id="bottombar">
        如浏览器无法播放，可复制地址到 VLC · PotPlayer · IPTV 播放器
    </div>
</div>

<script src="<?php echo esc_url($hlsjsUrl); ?>"></script>
<script>
// Sources are passed from the opener via postMessage or URL param
// URL param approach: just the single URL passed in
// Nothing for the stream's origin to trace back: no opener link, no window name
try { window.opener = null; } catch (e) {}
window.name = '';

const INITIAL_URL   = <?php echo json_encode($url); ?>;
const INITIAL_RAW   = <?php echo json_encode($raw ?: null); ?>;
const IS_YOUTUBE    = <?php echo $isYouTube ? 'true' : 'false'; ?>;
const INITIAL_IDX   = <?php echo $idx; ?>;
const TOTAL_SOURCES = <?php echo $total; ?>;

let currentHls  = null;
let hasPlayed   = false;
let stallTimer  = null;
let pct         = 0;

const overlay   = document.getElementById('overlay');
const vid       = document.getElementById('vid');
const progEl    = document.getElementById('prog');
const pctEl     = document.getElementById('pct');
const statusEl  = document.getElementById('status');
const subEl     = document.getElementById('substatus');
const srcBtns   = document.getElementById('src-btns');

// Listen for source list from parent window
window.addEventListener('message', (e) => {
    if (e.data?.type === 'z82_sources') {
        buildSourceButtons(e.data.sources, e.data.index || 0);
    }
});

function buildSourceButtons(sources, activeIdx) {
    srcBtns.innerHTML = '';
    sources.forEach((src, i) => {
        const btn = document.createElement('button');
        btn.className = 'src-btn' + (i === activeIdx ? ' active' : '');
        btn.textContent = '直播' + (i + 1);
        btn.onclick = () => {
            srcBtns.querySelectorAll('.src-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            loadStream(src.url, src.raw);
        };
        srcBtns.appendChild(btn);
    });
}

function setProgress(p, msg, sub) {
    pct = Math.max(pct, p);
    progEl.style.width = pct + '%';
    pctEl.textContent  = pct + '%';
    if (msg) statusEl.textContent = msg;
    if (sub !== undefined) subEl.textContent = sub;
}

function showError(msg, sub) {
    if (stallTimer) { clearTimeout(stallTimer); stallTimer = null; }
    pct = 0;
    overlay.classList.remove('hidden');
    overlay.innerHTML = `
        <div id="status" style="font-size:16px">${msg}</div>
        <div id="substatus" style="font-size:12px;color:rgba(255,255,255,0.5)">${sub || ''}</div>
        <button class="retry-btn" onclick="loadStream(currentUrl, currentRaw)">重试</button>
    `;
}

function hideOverlay() {
    hasPlayed = true;
    if (stallTimer) { clearTimeout(stallTimer); stallTimer = null; }
    overlay.classList.add('hidden');
    vid.style.display = 'block';
}

let currentUrl = INITIAL_URL;
let currentRaw = INITIAL_RAW;

function copyUrl() {
    const input = document.getElementById('url-display');
    if (!input || !input.value) return;
    navigator.clipboard?.writeText(input.value).then(() => {
        const btn = document.getElementById('copy-btn');
        btn.textContent = '✓ 已复制';
        btn.classList.add('copied');
        setTimeout(() => { btn.textContent = '复制'; btn.classList.remove('copied'); }, 2000);
    }).catch(() => { input.select(); document.execCommand('copy'); });
}

function setUrlBar(url) {
    const input = document.getElementById('url-display');
    const vlc   = document.getElementById('vlc-link');
    if (input) input.value = url || '';
    if (vlc)   vlc.href   = url || '#';
}

// url: the feed's relay link (/go?u=…) when there is one; raw: the real link, tried once if
// that fails before playing (some sources play directly but not through the relay)
function loadStream(url, raw, isFallback) {
    if (!isFallback) { currentUrl = url; currentRaw = raw || null; }
    const fallback = !isFallback && raw && raw !== url ? raw : null;
    hasPlayed  = false;
    pct        = 0;

    // Update URL bar immediately so user can copy to VLC even if player fails
    setUrlBar(url);

    // Destroy old HLS
    if (currentHls) { currentHls.destroy(); currentHls = null; }

    // Remove old iframe if any
    const oldIframe = document.getElementById('stream-iframe');
    if (oldIframe) oldIframe.remove();

    // Reset video
    vid.style.display = 'none';
    vid.src = '';

    // Reset overlay
    overlay.innerHTML = `
        <div class="prog-wrap">
            <div class="prog-bar"><div class="prog-fill" id="prog" style="width:0%"></div></div>
            <div class="prog-pct" id="pct">0%</div>
        </div>
        <div id="status">正在连接...</div>
        <div id="substatus"></div>
    `;
    overlay.classList.remove('hidden');

    const progEl   = () => document.getElementById('prog');
    const pctEl2   = () => document.getElementById('pct');
    const statusEl2 = () => document.getElementById('status');
    const subEl2   = () => document.getElementById('substatus');

    const setP = (p, msg, sub) => {
        pct = Math.max(pct, p);
        if (progEl()) progEl().style.width = pct + '%';
        if (pctEl2()) pctEl2().textContent = pct + '%';
        if (msg && statusEl2()) statusEl2().textContent = msg;
        if (sub !== undefined && subEl2()) subEl2().textContent = sub;
    };

    const isYT   = /youtube\.com|youtu\.be/i.test(url);
    const isM3U8 = /\.m3u8|\.mpd/i.test(url) || (!isYT);

    if (isYT) {
        const m = url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/)([^&\n?#]+)/);
        if (!m) { showError('无效YouTube链接', ''); return; }
        const iframe = document.createElement('iframe');
        iframe.id  = 'stream-iframe';
        iframe.src = `https://www.youtube-nocookie.com/embed/${m[1]}?autoplay=1&rel=0`;
        iframe.style.cssText = 'width:100%;height:100%;border:none;position:absolute;inset:0;';
        iframe.allowFullscreen = true;
        iframe.setAttribute('allow', 'autoplay; fullscreen');
        document.getElementById('player-wrap').appendChild(iframe);
        overlay.classList.add('hidden');

    } else if (window.Hls && Hls.isSupported()) {
        vid.style.display = 'block';
        setP(5, '正在连接...', '');

        const hls = new Hls({
            enableWorker: true, lowLatencyMode: true,
            // The feed's /go resolves the link fresh before answering: give it longer
            manifestLoadingTimeOut: fallback ? 15000 : 8000, manifestLoadingMaxRetry: 0,
            levelLoadingTimeOut: 10000, fragLoadingTimeOut: 15000,
        });

        hls.on(Hls.Events.MANIFEST_LOADING,  () => setP(15, '正在获取直播信息...', ''));
        hls.on(Hls.Events.MANIFEST_PARSED,   () => setP(40, '直播信息获取成功', '正在加载视频流...'));
        hls.on(Hls.Events.LEVEL_LOADED,      () => setP(60, '正在加载视频流...', ''));
        hls.on(Hls.Events.FRAG_LOADING,      () => setP(70, '正在缓冲...', ''));
        hls.on(Hls.Events.FRAG_LOADED,       () => setP(85, '缓冲完成', '准备播放...'));
        hls.on(Hls.Events.FRAG_BUFFERED,     () => setP(95, '即将开始...', ''));

        vid.addEventListener('playing', hideOverlay, { once: true });
        vid.addEventListener('waiting', () => {
            if (!hasPlayed || stallTimer) return;
            stallTimer = setTimeout(() => {
                stallTimer = null;
                overlay.classList.remove('hidden');
                overlay.innerHTML = `
                    <div class="prog-wrap"><div class="prog-bar"><div class="prog-fill" style="width:40%;animation:slide 1.2s infinite"></div></div></div>
                    <div id="status">重新连接中...</div>`;
            }, 8000);
        });
        vid.addEventListener('playing', () => { if (stallTimer) { clearTimeout(stallTimer); stallTimer = null; } });

        hls.on(Hls.Events.ERROR, (e, data) => {
            if (!data.fatal) return;
            if (data.type === Hls.ErrorTypes.NETWORK_ERROR) {
                if (!hasPlayed && fallback) {
                    loadStream(fallback, null, true);
                } else if (!hasPlayed) {
                    showError('无法连接直播源', '服务器未响应或直播已结束');
                } else { hls.startLoad(); }
            } else if (data.type === Hls.ErrorTypes.MEDIA_ERROR) {
                hls.recoverMediaError();
            } else {
                showError('直播源无法播放', '请尝试其他直播源');
                hls.destroy();
            }
        });

        hls.loadSource(url);
        hls.attachMedia(vid);
        currentHls = hls;

    } else if (vid.canPlayType('application/vnd.apple.mpegurl')) {
        vid.style.display = 'block';
        vid.src = url;
        vid.addEventListener('loadedmetadata', hideOverlay, { once: true });
        if (fallback) {
            vid.addEventListener('error', () => {
                // vid.error: a real failure of this load, not the reset above (src = '')
                if (!hasPlayed && currentUrl === url && vid.error) loadStream(fallback, null, true);
            }, { once: true });
        }
    } else {
        showError('请使用 Safari 或 Chrome', '');
    }
}

// Build initial source buttons if total > 1
if (TOTAL_SOURCES <= 1) {
    // Single source: no buttons needed
} else {
    // Buttons will come via postMessage from parent
}

// Start playing initial URL
setUrlBar(INITIAL_URL);
loadStream(INITIAL_URL, INITIAL_RAW);
</script>
</body>
</html>
<?php
    exit;
});


// ── Enqueue assets ───────────────────────────────────────────
add_action('wp_enqueue_scripts', function() {
    $url  = Z82_PLUGIN_URL;
    $path = Z82_PLUGIN_PATH;
    $css_ver = file_exists($path . 'assets/style.css')  ? filemtime($path . 'assets/style.css')  : Z82_VERSION;
    $js_ver  = file_exists($path . 'assets/script.js')  ? filemtime($path . 'assets/script.js')  : Z82_VERSION;

    wp_enqueue_style('z82-style',  $url . 'assets/style.css',  [], $css_ver);
    wp_enqueue_script('z82-script', $url . 'assets/script.js', [], $js_ver, true);
    wp_localize_script('z82-script', 'z82Config', [
        'pluginUrl' => $url,
        'ajaxUrl'   => admin_url('admin-ajax.php'),
        'nonce'     => wp_create_nonce('z82_nonce'),
        'push'      => z82_push_client_config(),
    ]);
});

// ── Admin menu ───────────────────────────────────────────────
add_action('admin_menu', function() {
    add_options_page('Zhibo82 Settings', 'Zhibo82', 'manage_options', 'zhibo82-settings', 'z82_admin_page');
});

add_action('admin_init', 'z82_register_settings');
function z82_register_settings() {
    register_setting('zhibo82_settings', 'z82_cache_duration');
    register_setting('zhibo82_settings', 'z82_app_download_url');
    register_setting('zhibo82_settings', 'z82_gas_webhook_url');
    register_setting('zhibo82_settings', 'z82_refresh_interval', ['sanitize_callback' => 'absint']);
    register_setting('zhibo82_settings', 'z82_upcoming_page', ['sanitize_callback' => 'absint']);
    register_setting('zhibo82_settings', 'z82_push_enabled', ['sanitize_callback' => function ($v) { return $v === '1' ? '1' : '0'; }]);
    register_setting('zhibo82_settings', 'z82_push_lead', ['sanitize_callback' => 'absint']);
    register_setting('zhibo82_settings', 'z82_photo_bank', ['sanitize_callback' => 'z82_sanitize_photo_bank']);
    register_setting('zhibo82_settings', 'z82_feed_fixtures', ['sanitize_callback' => 'esc_url_raw']);
    register_setting('zhibo82_settings', 'z82_feed_live', ['sanitize_callback' => 'esc_url_raw']);
    register_setting('zhibo82_settings', 'z82_hub_url', ['sanitize_callback' => function ($v) { return untrailingslashit(esc_url_raw(trim((string) $v))); }]);
    register_setting('zhibo82_settings', 'z82_network_key', ['sanitize_callback' => 'sanitize_text_field']);
}

// ── AJAX: flush cache ────────────────────────────────────────
add_action('wp_ajax_z82_flush_cache_ajax', function() {
    check_ajax_referer('z82_flush_cache_ajax_nonce', 'nonce');
    if (!current_user_can('manage_options')) wp_die('Unauthorized');
    global $wpdb;
    $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_z82_v4_%' OR option_name LIKE '_transient_timeout_z82_v4_%'");
    wp_send_json_success('Cache flushed.');
});

// ── Admin page ───────────────────────────────────────────────
function z82_admin_page() {
    if (isset($_POST['z82_flush_cache']) && check_admin_referer('z82_flush_cache_nonce')) {
        global $wpdb;
        $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_z82_v4_%' OR option_name LIKE '_transient_timeout_z82_v4_%'");
        echo '<div class="notice notice-success"><p>Cache flushed.</p></div>';
    }
    $dur = intval(get_option('z82_cache_duration', 5));
    ?>
    <div class="wrap">
        <h1>Zhibo82 Settings (v<?php echo Z82_VERSION; ?>)</h1>
        <form method="post" action="options.php">
            <?php settings_fields('zhibo82_settings'); ?>
            <table class="form-table">
                <tr>
                    <th>Cache Duration (minutes)</th>
                    <td><input type="number" name="z82_cache_duration" min="0" max="60" value="<?php echo esc_attr($dur); ?>" /></td>
                </tr>
                <tr>
                    <th>Auto Refresh (seconds)</th>
                    <td><input type="number" name="z82_refresh_interval" min="0" max="3600" value="<?php echo esc_attr(z82_refresh_interval()); ?>" />
                        <p class="description">How often open pages check for updated matches and sources. The table is only replaced when something changed. 0 = off.</p></td>
                </tr>
                <tr>
                    <th>Upcoming Matches per Page</th>
                    <td><input type="number" name="z82_upcoming_page" min="0" max="500" value="<?php echo esc_attr(z82_upcoming_page_size()); ?>" />
                        <p class="description">Matches that haven't started yet are shown in batches with a “加载更多” button. Live and ended matches are always shown. 0 = show all.</p></td>
                </tr>
                <tr>
                    <th>Match Reminders</th>
                    <td>
                        <input type="hidden" name="z82_push_enabled" value="0" />
                        <label><input type="checkbox" name="z82_push_enabled" value="1" <?php checked(z82_push_enabled()); ?> /> Show a bell on upcoming matches and send a browser notification before kickoff</label>
                        <p><input type="number" name="z82_push_lead" min="0" max="60" value="<?php echo esc_attr(z82_push_lead()); ?>" style="width:70px" /> minutes before kickoff</p>
                        <?php $ps = z82_push_stats(); ?>
                        <p class="description">Subscribed browsers: <?php echo (int) $ps['subscribers']; ?> · Pending reminders: <?php echo (int) $ps['pending']; ?> · Sent: <?php echo (int) $ps['sent']; ?><br>
                        Needs HTTPS. Reminders go out from WP-Cron once a minute, which only runs when the site gets traffic — for exact timing add a server cron hitting <code>wp-cron.php</code> every minute.</p>
                    </td>
                </tr>
                <tr>
                    <th>App Download URL</th>
                    <td><input type="url" name="z82_app_download_url" value="<?php echo esc_attr(get_option('z82_app_download_url', 'https://zhibo82.com/app')); ?>" style="width:400px" /></td>
                </tr>
                <tr>
                    <th>Fixtures API</th>
                    <td><input type="url" name="z82_feed_fixtures" value="<?php echo esc_attr(z82_feed_url('fixtures')); ?>" style="width:520px" />
                        <p class="description">Scheduled matches. Server-side only — visitors never see this address.</p></td>
                </tr>
                <tr>
                    <th>Live API</th>
                    <td><input type="url" name="z82_feed_live" value="<?php echo esc_attr(z82_feed_url('live')); ?>" style="width:520px" />
                        <p class="description">Matches live right now (overrides the same match from the fixtures feed).<?php if (z82_hub_feed('fixtures')): ?> <strong>Connected to the hub: its feeds are used instead of these two.</strong><?php endif; ?></p></td>
                </tr>
                <?php z82_hub_admin_rows(); ?>
            </table>

            <h2>Photo Bank</h2>
            <p class="description">Shown on source cards that have no screenshot. Up to <?php echo Z82_PHOTO_BANK_MAX; ?> images per sport; each card gets one of them (the same one every time, so cards don't flicker on refresh). “Default” is used for sports without their own images.</p>
            <table class="form-table z82-bank-table">
                <?php $bank = z82_photo_bank(); ?>
                <?php foreach (array_merge(['default' => 'Default'], z82_sport_names()) as $sport => $label): ?>
                <?php $ids = $bank[$sport] ?? []; ?>
                <tr class="z82-bank">
                    <th><?php echo esc_html($sport === 'default' ? 'Default' : $sport . ' · ' . $label); ?></th>
                    <td>
                        <input type="hidden" name="z82_photo_bank[<?php echo esc_attr($sport); ?>]" value="<?php echo esc_attr(implode(',', $ids)); ?>" />
                        <div class="z82-bank-thumbs"><?php foreach ($ids as $id) echo wp_get_attachment_image($id, 'thumbnail'); ?></div>
                        <button type="button" class="button z82-bank-pick">Choose images</button>
                        <button type="button" class="button-link z82-bank-clear"<?php echo $ids ? '' : ' hidden'; ?>>Clear</button>
                    </td>
                </tr>
                <?php endforeach; ?>
            </table>
            <?php submit_button(); ?>
        </form>
        <h2>Cache</h2>
        <form method="post">
            <?php wp_nonce_field('z82_flush_cache_nonce'); ?>
            <input type="hidden" name="z82_flush_cache" value="1">
            <button type="submit" class="button button-secondary">Flush Cache Now</button>
        </form>
        <h2>Shortcode</h2>
        <code>[zhibo82_streaming]</code><br><br>
        <code>[zhibo82_streaming type_filter="Football" league_keywords="World Cup, 世界杯"]</code>
    </div>
    <?php
}

// ── Fetch JSON from API ──────────────────────────────────────
function z82_fetch_json($url) {
    $response = wp_remote_get($url, [
        'timeout'    => 15,
        'user-agent' => 'Mozilla/5.0',
        'sslverify'  => false,
    ]);
    if (is_wp_error($response)) return null;
    if (wp_remote_retrieve_response_code($response) !== 200) return null;
    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);
    // A list of matches only — the feed answers {"error": "..."} while it has no data yet
    if (!is_array($data) || ($data && !isset($data[0]))) return null;
    return array_values(array_filter($data, function ($m) { return is_array($m) && !empty($m['eventId']); }));
}

// ── Fetch + merge both feeds (cached) ───────────────────────
function z82_fetch_matches() {
    $dur = intval(get_option('z82_cache_duration', 5));

    if ($dur > 0) {
        // Clock-aligned cache slot
        $tz       = wp_timezone();
        $now      = new DateTime('now', $tz);
        $slot_min = intval($now->format('i')) - (intval($now->format('i')) % max(1, $dur));
        $slot_str = $now->format('Y-m-d H') . ':' . str_pad($slot_min, 2, '0', STR_PAD_LEFT);
        $cache_key = 'z82_v4_' . md5($slot_str);

        $cached = get_transient($cache_key);
        if ($cached !== false) return $cached;
    }

    $fixtures = z82_fetch_json(z82_feed_url('fixtures'));
    $live     = z82_fetch_json(z82_feed_url('live')) ?? [];

    if ($fixtures === null) {
        // Feed down or still empty after a restart (it answers 404 until its first run ends):
        // keep showing the last good copy, and try again in a minute — same as zhibo882
        $last = get_option('z82_feed_last');
        $matches = is_array($last) ? $last : [];
        if ($dur > 0) set_transient($cache_key, $matches, MINUTE_IN_SECONDS);
        return $matches;
    }

    // Merge: live overrides fixture for same eventId, mark feed type
    $byId = [];
    foreach ($fixtures as $m) {
        $m['_feed'] = 'fixture';
        $byId[$m['eventId']] = $m;
    }
    foreach ($live as $m) {
        $m['_feed'] = 'live';
        $byId[$m['eventId']] = $m;
    }

    $matches = array_values($byId);

    // Cache this feed's screenshots/GIFs locally before the feed host drops them
    if ($matches) z82_media_remember($matches);
    update_option('z82_feed_last', $matches, false);

    if ($dur > 0) {
        $tz  = wp_timezone();
        $now = new DateTime('now', $tz);
        $slot_min  = intval($now->format('i')) - (intval($now->format('i')) % max(1, $dur));
        $next_min  = $slot_min + $dur;
        $next      = clone $now;
        $next->setTime(intval($now->format('H')), $next_min >= 60 ? $next_min - 60 : $next_min, 0);
        if ($next_min >= 60) $next->modify('+1 hour');
        $ttl = max(60, $next->getTimestamp() - time());
        set_transient($cache_key, $matches, $ttl);
    }

    return $matches;
}

// ── Parse a match entry into normalised array ────────────────
function z82_parse_match($m) {
    // Build display name (prefer Chinese)
    $home     = !empty($m['homeTeamZH']) ? $m['homeTeamZH'] : ($m['homeTeam'] ?? '');
    $away     = !empty($m['awayTeamZH']) ? $m['awayTeamZH'] : ($m['awayTeam'] ?? '');
    $matchName = $away ? $home . ' vs ' . $away : $home;

    $homeLogo = !empty($m['homeLogo']) ? $m['homeLogo'] : '';
    $awayLogo = !empty($m['awayLogo']) ? $m['awayLogo'] : '';

    $league   = !empty($m['leagueZH'])   ? $m['leagueZH']   : ($m['league'] ?? '');
    $type     = $m['sportType'] ?? '';
    $feed     = $m['_feed'] ?? 'fixture';

    // Convert UTC → CST+8
    $rawDate = '';
    $rawTime = '';
    $dateObj = null;
    if (!empty($m['matchDateUTC'])) {
        try {
            $dateObj = new DateTime($m['matchDateUTC']);
            $dateObj->setTimezone(new DateTimeZone('Asia/Shanghai'));
            $rawDate = $dateObj->format('Y年m月d日');
            $rawTime = $dateObj->format('H:i');
        } catch (Exception $e) {}
    }

    // Build sources array
    $sources = [];
    foreach ($m['channels'] ?? [] as $ch) {
        $label = $ch['name'] ?? '源';
        $label = preg_replace('/\s*\(.*?\)\s*/', '', $label);
        $label = trim($label) ?: '直播';

        $urls        = $ch['sources']         ?? [];
        $screenshots = $ch['sourceScreenshot'] ?? [];
        $gifs        = $ch['sourceGif']        ?? [];   // short animated preview, same index as sources
        $workingArr  = $ch['sourceWorking']   ?? [];
        $corsArr     = $ch['sourceCors']      ?? [];
        $ranks       = $ch['sourceRank']      ?? [];   // working / medium / unverified / unauthorized
        $resolvedArr = $ch['sourceResolved']  ?? [];

        foreach ($urls as $i => $url) {
            if (empty($url)) continue;
            // The feed's check says dead: its /go link answers 502, so no button for it. A match left
            // with no source isn't listed (see $hasRealSource below).
            if (($workingArr[$i] ?? null) === false) continue;
            // Played through the feed's redirect (/go?u=…): it re-resolves the link at click
            // time and sends most sources through its relay (fixes geo-blocks and missing CORS).
            // Everything else — YouTube detection, cached media keys, "soon" checks — uses the real link.
            $feedUrl     = $url;
            $url         = z82_unwrap_source($url);
            $resolved    = $resolvedArr[$i] ?? '';
            $isM3U8      = (bool) preg_match('/\.(m3u8|mpd)/i', $url . ' ' . $resolved);
            // Screenshots / GIFs are served from this site, not the feed host
            // Missing from this feed? fall back to the last cached one for this stream
            $screenshot  = z82_media_url($screenshots[$i] ?? null) ?: z82_media_fallback($url, 's');
            $gif         = z82_media_url($gifs[$i] ?? null)        ?: z82_media_fallback($url, 'g');
            $working     = $workingArr[$i]  ?? null;  // true/false/null
            $cors        = $corsArr[$i]     ?? null;  // true/false/null

            // Status badge: ✅ works + CORS ok, ⚠️ works but no CORS, ❌ broken, ⏳ unknown
            if ($working === true && $cors === true)  $badge = '✅';
            elseif ($working === true)                $badge = '⚠️';  // works but CORS blocked
            elseif ($working === false)               $badge = '❌';
            else                                      $badge = '⏳';

            $youtube     = z82_youtube_info($url);   // null unless it's an embeddable YouTube link

            $sources[] = [
                'url'        => $url,
                'play'       => $youtube ? $url : $feedUrl,   // what the popup plays (raw link is the fallback)
                'label'      => $label,
                'isM3U8'     => $isM3U8,
                'isLive'     => ($feed === 'live'),
                'screenshot' => $screenshot,
                'gif'        => $gif,
                'working'    => $working,
                'cors'       => $cors,
                'badge'      => $badge,
                'rank'       => $ranks[$i] ?? null,
                'youtube'    => $youtube,
            ];
        }
    }

    // Status from matchDateUTC
    $tz          = new DateTimeZone('Asia/Shanghai');
    $now         = new DateTime('now', $tz);
    $isLive      = false;
    $isOver      = false;
    $diffMinutes = null;

    if ($dateObj) {
        $diffMinutes = ($now->getTimestamp() - $dateObj->getTimestamp()) / 60;
        $durations   = [
            'Football' => 120, 'Basketball' => 180, 'Tennis' => 240,
            'Cricket' => 360, 'default' => 150
        ];
        $duration = $durations[$type] ?? $durations['default'];

        if (($m['status'] ?? '') === 'live') {
            $isLive = true;   // the live feed says so
        } elseif ($diffMinutes >= -15 && $diffMinutes <= $duration) {
            $isLive = true;
        } elseif ($diffMinutes > $duration) {
            $isOver = true;
        }
    }

    // No playable source (none in the feed, all dead, or only a "soon" placeholder) → not listed
    // at all, upcoming included. zhibo882 still lists these as 即将上线 (user's choice, 2026-10-19).
    $hasRealSource = !empty($sources) && stripos($sources[0]['url'], 'soon') === false;
    if (!$hasRealSource) return null;

    return [
        'eventId'     => $m['eventId'] ?? '',
        'match'       => $matchName,
        'homeLogo'    => $homeLogo,
        'awayLogo'    => $awayLogo,
        'league'      => $league,
        'type'        => $type,
        'rawDate'     => $rawDate,
        'rawTime'     => $rawTime,
        'dateObj'     => $dateObj,
        'sources'     => $sources,
        'isLive'      => $isLive,
        'isOver'      => $isOver,
        'endedAgo'    => $isOver ? $diffMinutes - $duration : null,   // minutes since its estimated end
        'diffMinutes' => $diffMinutes,
        'feed'        => $feed,
    ];
}

// ── Main shortcode ───────────────────────────────────────────
add_shortcode('zhibo82_streaming', 'z82_streaming_shortcode');
function z82_streaming_shortcode($atts) {
    $atts = shortcode_atts([
        'type_filter'      => '',
        'show_type_filter' => 'true',
        'league_keywords'  => '',
        'cache_duration'   => get_option('z82_cache_duration', 5),
    ], $atts);

    return z82_generate_table($atts);
}

// ── Auto refresh ─────────────────────────────────────────────
function z82_refresh_interval() {
    return absint(get_option('z82_refresh_interval', 180));
}

// Only the attributes that shape the table, sanitised — they round-trip through the browser
function z82_public_atts($atts) {
    $limits = [];
    if (!empty($atts['limits']) && is_array($atts['limits'])) {
        foreach (array_slice($atts['limits'], 0, 50, true) as $sport => $n) {
            $limits[sanitize_text_field((string) $sport)] = min(absint($n), 5000);
        }
    }
    $include = (string) ($atts['include'] ?? '');

    return [
        'type_filter'      => sanitize_text_field($atts['type_filter'] ?? ''),
        'show_type_filter' => ($atts['show_type_filter'] ?? 'true') === 'false' ? 'false' : 'true',
        'league_keywords'  => sanitize_text_field($atts['league_keywords'] ?? ''),
        'limits'           => (object) $limits,   // upcoming rows loaded via 加载更多, per sport ('' = all)
        'include'          => preg_match('/^match-[a-f0-9]{32}$/', $include) ? $include : '',   // deep-linked match
    ];
}

function z82_upcoming_page_size() {
    return absint(get_option('z82_upcoming_page', 30));
}

// Hash of the rendered table, ignoring parts that change on every render
// (random table id, countdown text — the browser ticks countdowns itself)
function z82_table_fingerprint($html) {
    $html = preg_replace('/z82-table-[a-f0-9]+/', 'z82-table', $html);
    $html = preg_replace('#<span class="z82-countdown"[^>]*>.*?</span>#s', '', $html);
    return md5($html);
}

// Returns the table only when it differs from what the browser already shows
function z82_ajax_refresh() {
    $atts = json_decode(wp_unslash($_POST['atts'] ?? '{}'), true);
    $atts = z82_public_atts(is_array($atts) ? $atts : []);

    $html = z82_generate_table($atts, false);
    if (!preg_match('/data-z82-v="([a-f0-9]{32})"/', $html, $m)) {
        wp_send_json_success(['changed' => false]);   // feed empty/failed — keep what's on screen
    }
    if (isset($_POST['v']) && $_POST['v'] === $m[1]) {
        wp_send_json_success(['changed' => false]);
    }
    wp_send_json_success(['changed' => true, 'v' => $m[1], 'html' => $html]);
}
add_action('wp_ajax_z82_refresh', 'z82_ajax_refresh');
add_action('wp_ajax_nopriv_z82_refresh', 'z82_ajax_refresh');

// Ended matches: only those that ended in the last Z82_ENDED_KEEP_MINUTES, at most
// Z82_ENDED_MAX of the most recent, big competitions first, then latest first.
// zhibo882-streaming-table (z882_recent_ended) uses the same rule, so both list the same matches.
const Z82_ENDED_KEEP_MINUTES = 120;
const Z82_ENDED_MAX          = 20;

function z82_recent_ended(array $ended, callable $priority) {
    $ended = array_values(array_filter($ended, function ($p) {
        return $p['endedAgo'] !== null && $p['endedAgo'] <= Z82_ENDED_KEEP_MINUTES;
    }));
    $byRecent = function ($a, $b) { return $a['endedAgo'] <=> $b['endedAgo']; };
    usort($ended, $byRecent);
    $ended = array_slice($ended, 0, Z82_ENDED_MAX);
    usort($ended, function ($a, $b) use ($priority, $byRecent) {
        return ($priority($a) - $priority($b)) ?: $byRecent($a, $b);
    });
    return $ended;
}

function z82_generate_table($atts, $withAdminBar = true) {
    $rawMatches = z82_fetch_matches();

    // Parse + normalise
    $parsed = [];
    foreach ($rawMatches as $m) {
        $p = z82_parse_match($m);
        if (!$p) continue;
        if (!empty($atts['type_filter']) && $p['type'] !== $atts['type_filter']) continue;
        $parsed[] = $p;
    }

    if (empty($parsed)) {
        return '<div class="z82-error">暂无比赛数据</div>';
    }

    // Keyword filter (client-side data attribute approach)
    $leagueKw = $atts['league_keywords'];

    // Collect sport types
    $sportTypes = [];
    foreach ($parsed as $p) {
        if (!empty($p['type']) && !in_array($p['type'], $sportTypes)) {
            $sportTypes[] = $p['type'];
        }
    }
    sort($sportTypes);

    // Sort: live → upcoming → ended
    $live    = [];
    $upcoming = [];
    $ended   = [];

    // Priority sort helper
    $priority = function($p) {
        $text = strtolower($p['league'] . ' ' . $p['match']);
        $wc  = ['world cup','世界杯','wc 2026','wc2026','concacaf/uefa','afc/uefa','concacaf/conmebol','caf/afc','caf/uefa'];
        $ucl = ['champions league','欧冠','冠军联赛','ucl'];
        $pl  = ['premier league','英超'];
        foreach ($wc  as $kw) { if (strpos($text,$kw)!==false) return 0; }
        foreach ($ucl as $kw) { if (strpos($text,$kw)!==false) return 1; }
        foreach ($pl  as $kw) { if (strpos($text,$kw)!==false) return 2; }
        return 3;
    };

    foreach ($parsed as $p) {
        if ($p['isLive'])      $live[]     = $p;
        elseif ($p['isOver'])  $ended[]    = $p;
        else                    $upcoming[] = $p;
    }

    $sortFn = function($a, $b) use ($priority) {
        $pa = $priority($a); $pb = $priority($b);
        if ($pa !== $pb) return $pa - $pb;
        // Within same priority: sort by time
        $ta = $a['dateObj'] ? $a['dateObj']->getTimestamp() : 0;
        $tb = $b['dateObj'] ? $b['dateObj']->getTimestamp() : 0;
        return $ta - $tb;
    };
    // Upcoming: soonest day first (Beijing time), big competitions first within a day — so a
    // World Cup match next month never jumps ahead of today's and tomorrow's matches
    $upcomingSortFn = function($a, $b) use ($sortFn) {
        $da = $a['dateObj'] ? $a['dateObj']->format('Ymd') : '99999999';
        $db = $b['dateObj'] ? $b['dateObj']->format('Ymd') : '99999999';
        if ($da !== $db) return strcmp($da, $db);
        return $sortFn($a, $b);
    };
    usort($live,     $sortFn);
    usort($upcoming, $upcomingSortFn);
    $ended = z82_recent_ended($ended, $priority);

    // Page the upcoming list. A row is rendered when it's within the first N overall, within
    // the count loaded for its sport, or it's a deep-linked match. Because every sport's rows
    // keep the overall sort order, each of these is a prefix of that sport's list.
    $pageSize  = z82_upcoming_page_size();
    $limits    = (array) ($atts['limits'] ?? []);
    $overall   = max($pageSize, (int) ($limits[''] ?? 0));
    $include   = $atts['include'] ?? '';
    $remaining = ['' => 0];
    if ($pageSize > 0) {
        $shown = [];
        $sportIdx = [];
        foreach ($upcoming as $i => $p) {
            $t = $p['type'];
            $sportIdx[$t] = isset($sportIdx[$t]) ? $sportIdx[$t] + 1 : 0;
            if ($i < $overall || $sportIdx[$t] < (int) ($limits[$t] ?? 0)
                || ($include && 'match-' . md5($p['eventId']) === $include)) {
                $shown[] = $p;
            } else {
                $remaining['']++;
                $remaining[$t] = ($remaining[$t] ?? 0) + 1;
            }
        }
        $upcoming = $shown;
    }

    $tableId  = 'z82-table-' . uniqid();
    $is_admin = current_user_can('manage_options');

    // Cache hit bar
    $cacheBar = '';
    if ($is_admin) {
        $flush_nonce = wp_create_nonce('z82_flush_cache_ajax_nonce');
        $ajax_url    = admin_url('admin-ajax.php');
        $cacheBar = '<div class="z82-admin-bar">
            <span class="z82-admin-bar-title">Feed</span>
            <span class="z82-admin-bar-stats">Live ' . count($live) . ' · Upcoming ' . count($upcoming) . ' · Ended ' . count($ended) . '</span>
            <span class="z82-admin-bar-note">admin only</span>
            <button type="button" class="z82-admin-bar-btn" onclick="z82FlushCache(this,\'' . esc_js($flush_nonce) . '\',\'' . esc_js($ajax_url) . '\')">Flush cache</button>
        </div>';
    }

    ob_start();
    ?>
    <div class="z82-wrapper">

        <?php if (!empty($leagueKw)): ?>
        <div class="z82-kw-reset-bar">
            <span class="z82-kw-reset-label">当前为筛选视图</span>
            <button type="button" class="z82-kw-reset-btn" onclick="z82ResetKeywords('<?php echo esc_js($tableId); ?>')">查看所有比赛</button>
        </div>
        <?php endif; ?>

        <?php if ($atts['show_type_filter'] === 'true' && !empty($sportTypes)): ?>
        <div class="z82-filters-wrap">
            <div class="z82-filters" role="tablist" aria-label="运动类型">
                <button type="button" class="z82-filter-btn active" role="tab" aria-selected="true" data-sport="" onclick="z82FilterType('<?php echo $tableId; ?>', '', this)">
                    <span>全部</span>
                </button>
                <?php foreach ($sportTypes as $type): ?>
                <button type="button" class="z82-filter-btn" role="tab" aria-selected="false" data-sport="<?php echo esc_attr($type); ?>" onclick="z82FilterType('<?php echo $tableId; ?>', '<?php echo esc_attr($type); ?>', this)">
                    <?php echo z82_get_sport_icon($type); ?>
                    <span><?php echo esc_html(z82_get_sport_name_cn($type)); ?></span>
                </button>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

        <div class="z82-tz-note">时间均为北京时间（UTC+8）</div>

        <div class="z82-table-container" id="<?php echo $tableId; ?>">
            <?php
            // Render: live → upcoming → ended (top 3 visible)
            $allRendered = array_merge($live, $upcoming);
            $endedVisible = array_slice($ended, 0, 3);
            $endedHidden  = array_slice($ended, 3);

            if (count($endedHidden) > 0): ?>
            <button type="button" class="z82-ended-info" id="z82-show-ended-again" aria-expanded="false" onclick="z82ShowAllEnded()">
                <span class="z82-ended-info-label" data-show="显示全部 <?php echo count($ended); ?> 场已结束的比赛" data-hide="收起已结束的比赛">显示全部 <?php echo count($ended); ?> 场已结束的比赛</span>
                <svg class="z82-icon z82-ended-info-chevron" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>
            </button>
            <?php endif;

            foreach ($endedVisible as $p) {
                echo z82_render_match_row($p, true);
            }
            foreach ($endedHidden as $p) {
                echo z82_render_match_row($p, true, true);
            }
            foreach ($allRendered as $p) {
                // Skip soon/empty if live
                $src1url = $p['sources'][0]['url'] ?? '';
                $isSoon  = empty($src1url) || stripos($src1url, 'soon') !== false;
                if ($p['isLive'] && $isSoon) continue;

                $kwHidden = false;
                if (!empty($leagueKw)) {
                    $kws  = array_map('strtolower', array_filter(array_map('trim', explode(',', $leagueKw))));
                    $text = strtolower($p['league'] . ' ' . $p['match']);
                    $hit  = false;
                    foreach ($kws as $kw) { if (strpos($text, $kw) !== false) { $hit = true; break; } }
                    if (!$hit) $kwHidden = true;
                }
                echo z82_render_match_row($p, false, false, $kwHidden);
            }
            ?>
            <?php if ($remaining[''] > 0): ?>
            <button type="button" class="z82-load-more" data-remaining="<?php echo esc_attr(wp_json_encode($remaining)); ?>" onclick="z82LoadMore(this)">
                <span class="z82-load-more-label">加载更多比赛</span>
                <span class="z82-load-more-count"></span>
            </button>
            <?php endif; ?>
        </div>
    </div>
    <?php
    $html = ob_get_clean();

    // Fingerprint + settings for the in-page auto refresh (see z82_ajax_refresh)
    $html = preg_replace('/<div class="z82-wrapper"/', sprintf(
        '<div class="z82-wrapper" data-z82-v="%s" data-z82-refresh="%d" data-z82-page="%d" data-z82-atts="%s"',
        esc_attr(z82_table_fingerprint($html)),
        z82_refresh_interval(),
        z82_upcoming_page_size(),
        esc_attr(wp_json_encode(z82_public_atts($atts)))
    ), $html, 1);

    return ($withAdminBar ? $cacheBar : '') . $html;
}

// ── Render single match row ──────────────────────────────────
function z82_render_match_row($p, $isEnded = false, $isHidden = false, $kwHidden = false) {
    $matchId   = 'match-' . md5($p['eventId']);
    $statusCls = $p['isLive'] ? 'live' : ($isEnded ? 'finished' : 'upcoming');
    $classes   = 'z82-match-row ' . $statusCls;
    if ($isHidden) $classes .= ' z82-match-hidden';
    if ($kwHidden) $classes .= ' z82-kw-hidden';

    $hasSources = !empty($p['sources']);
    $src1       = $p['sources'][0] ?? null;
    $isSoon     = !$hasSources || (!empty($src1['url']) && stripos($src1['url'], 'soon') !== false);
    $isFixture  = ($p['feed'] === 'fixture');

    // Countdown for upcoming
    $countdown = '';
    if (!$p['isLive'] && !$isEnded && $p['diffMinutes'] !== null) {
        $minsUntil = abs($p['diffMinutes']);
        $h   = floor($minsUntil / 60);
        $min = (int) $minsUntil % 60;
        $countdown = $h > 0 ? $h . '小时' . $min . '分后' : $min . '分钟后';
    }

    // Date display
    $tz       = new DateTimeZone('Asia/Shanghai');
    $today    = (new DateTime('now', $tz))->format('Y年m月d日');
    $tomorrow = (new DateTime('tomorrow', $tz))->format('Y年m月d日');
    $dateLabel = $p['rawDate'];
    if ($p['rawDate'] === $today)    $dateLabel = '今天';
    elseif ($p['rawDate'] === $tomorrow) $dateLabel = '明天';
    elseif ($p['dateObj'])               $dateLabel = $p['dateObj']->format('m月d日');  // year dropped to fit the time column
    // 今天 / 明天 still get the date itself, small under the time
    $dayDate = ($p['dateObj'] && $dateLabel !== $p['dateObj']->format('m月d日')) ? $p['dateObj']->format('m月d日') : '';

    $icon = z82_get_sport_icon($p['type']);

    // YouTube sources play embedded in the row (tabs); everything else opens in the popup
    $ytSources    = array_values(array_filter($p['sources'], function ($s) { return !empty($s['youtube']); }));
    $otherSources = array_values(array_filter($p['sources'], function ($s) { return empty($s['youtube']); }));
    if ($ytSources) $classes .= ' z82-has-yt';
    // YouTube-only: hidden until the browser shows YouTube works here (and, when live, that the stream is really live)
    if ($ytSources && !$otherSources) $classes .= ' z82-yt-pending';

    ob_start();
    ?>
    <div class="<?php echo $classes; ?>"
         data-type="<?php echo esc_attr($p['type']); ?>"
         data-match-id="<?php echo esc_attr($matchId); ?>"
         data-search="<?php echo esc_attr(strtolower($p['league'] . ' ' . $p['match'])); ?>"
         data-is-finished="<?php echo $isEnded ? '1' : '0'; ?>"
         data-other-count="<?php echo count($otherSources); ?>">

        <div class="z82-row-header" role="button" tabindex="0" aria-expanded="false" aria-controls="content-<?php echo $matchId; ?>" onclick="z82ToggleRow('<?php echo $matchId; ?>')">
            <div class="z82-row-time">
                <div class="z82-date"><?php echo esc_html($dateLabel); ?></div>
                <div class="z82-time"><?php echo esc_html($p['rawTime']); ?></div>
                <?php if ($dayDate): ?><div class="z82-day"><?php echo esc_html($dayDate); ?></div><?php endif; ?>
            </div>
            <div class="z82-row-info">
                <?php if (!empty($p['homeLogo']) || !empty($p['awayLogo'])): ?>
                <div class="z82-team-logos">
                    <?php if (!empty($p['homeLogo'])): ?>
                    <img src="<?php echo esc_url($p['homeLogo']); ?>"
                         class="z82-team-badge"
                         onerror="this.style.display='none'"
                         alt="" />
                    <?php endif; ?>
                    <?php if (!empty($p['awayLogo'])): ?>
                    <span class="z82-vs-sep">vs</span>
                    <img src="<?php echo esc_url($p['awayLogo']); ?>"
                         class="z82-team-badge"
                         onerror="this.style.display='none'"
                         alt="" />
                    <?php endif; ?>
                </div>
                <?php endif; ?>
                <div class="z82-teams"><?php echo esc_html($p['match']); ?></div>
                <div class="z82-league">
                    <?php echo $icon; ?>
                    <?php echo esc_html($p['league']); ?>
                </div>
            </div>
            <div class="z82-row-right">
                <?php if ($p['isLive']): ?>
                <span class="z82-live-badge"><span class="z82-live-dot" aria-hidden="true"></span>直播中</span>
                <?php elseif ($isEnded): ?>
                <span class="z82-ended-badge">已结束</span>
                <?php elseif ($countdown): ?>
                <span class="z82-countdown" data-start="<?php echo esc_attr($p['dateObj']->getTimestamp()); ?>"><?php echo esc_html($countdown); ?></span>
                <?php endif; ?>
                <?php if (z82_push_enabled() && !$p['isLive'] && !$isEnded && $p['dateObj']): ?>
                <button type="button" class="z82-remind" aria-pressed="false" aria-label="开播提醒"
                        data-remind="<?php echo esc_attr($matchId); ?>"
                        data-start="<?php echo esc_attr($p['dateObj']->getTimestamp()); ?>"
                        data-title="<?php echo esc_attr($p['match']); ?>"
                        data-league="<?php echo esc_attr($p['league']); ?>"
                        onclick="event.stopPropagation(); z82ToggleReminder(this)"><svg class="z82-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/></svg></button>
                <?php endif; ?>
                <?php if ($hasSources && !$isSoon): ?>
                <span class="z82-sources-count"><?php echo count($p['sources']); ?>个直播</span>
                <?php elseif ($isSoon && !$isEnded): ?>
                <span class="z82-soon-badge">即将上线</span>
                <?php endif; ?>
                <svg class="z82-icon z82-chevron" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>
            </div>
        </div>

        <div class="z82-row-content" id="content-<?php echo $matchId; ?>" style="display:none">
            <?php if ($isSoon && !$isEnded): ?>
            <div class="z82-soon-message">
                <div class="z82-soon-icon"><svg class="z82-icon" viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg></div>
                <div class="z82-soon-text">
                    <strong>直播即将上线</strong>
                    <p>请在比赛开始前30分钟访问本页面，直播链接将提前更新</p>
                </div>
            </div>
            <?php elseif ($hasSources): ?>
            <?php if ($ytSources): ?>
            <?php // Hidden until the browser confirms youtube.com is reachable (script.js) ?>
            <div class="z82-yt" data-yt-block hidden>
                <?php if (count($ytSources) > 1): ?>
                <div class="z82-yt-tabs" role="tablist">
                    <?php foreach ($ytSources as $k => $src): ?>
                    <button type="button" role="tab" class="z82-yt-tab<?php echo $k === 0 ? ' is-active' : ''; ?>" aria-selected="<?php echo $k === 0 ? 'true' : 'false'; ?>"
                            data-embed="<?php echo esc_url($src['youtube']['embed']); ?>"
                            data-thumb="<?php echo esc_url($src['youtube']['thumb']); ?>"
                            data-watch="<?php echo esc_url($src['youtube']['watch']); ?>">
                        <span class="z82-yt-tab-num">直播<?php echo $k + 1; ?></span>
                        <span class="z82-yt-tab-label"><?php echo esc_html($src['label'] ?: 'YouTube'); ?></span>
                    </button>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
                <div class="z82-yt-player" data-embed="<?php echo esc_url($ytSources[0]['youtube']['embed']); ?>" data-watch="<?php echo esc_url($ytSources[0]['youtube']['watch']); ?>">
                    <img class="z82-yt-poster" data-src="<?php echo esc_url($ytSources[0]['youtube']['thumb']); ?>" alt="" loading="lazy" />
                    <span class="z82-play" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M8 5.5v13a1 1 0 0 0 1.5.86l10.5-6.5a1 1 0 0 0 0-1.72L9.5 4.64A1 1 0 0 0 8 5.5z"/></svg></span>
                </div>
                <?php // If YouTube won't play it here (it can ask some viewers to sign in), the video still opens on YouTube ?>
                <a class="z82-yt-out" href="<?php echo esc_url($ytSources[0]['youtube']['watch']); ?>" target="_blank" rel="noopener noreferrer">无法播放？在 YouTube 观看 ↗</a>
            </div>
            <?php endif; ?>
            <?php if ($otherSources): ?>
            <?php
            $sourceGroups = $otherSources;
            $playerUrl    = home_url('/');
            ?>
            <div class="z82-popup-sources<?php echo count($sourceGroups) <= 2 ? ' z82-popup-sources--' . count($sourceGroups) : ''; ?>" id="sources-<?php echo $matchId; ?>">
                <?php foreach ($sourceGroups as $i => $src): ?>
                <?php
                $popupArgs = [
                    'z82_stream' => '1',
                    'url'        => urlencode($src['play']),
                    'title'      => urlencode($p['match']),
                    'src'        => $i,
                    'total'      => count($sourceGroups),
                ];
                // Fallback for the player page when the feed's relay can't play it
                if ($src['play'] !== $src['url']) $popupArgs['raw'] = urlencode($src['url']);
                $popupUrl = add_query_arg($popupArgs, $playerUrl);

                // Never call a source broken: high → label, medium → nothing, anything else → unknown
                $rank = $src['rank'];
                if ($rank === 'working' || $rank === 'high' || ($rank === null && $src['working'] === true && $src['cors'] === true)) {
                    $health = 'high';    $healthText = '高速连接'; $healthTitle = '连接质量高';
                } elseif ($rank === 'medium' || ($rank === null && $src['working'] === true)) {
                    $health = 'medium';  $healthText = '';        $healthTitle = '';
                } else {
                    $health = 'unknown'; $healthText = '连接未知'; $healthTitle = '暂无此直播源的连接数据，可直接尝试播放';
                }
                ?>
                <button type="button" class="z82-popup-btn"
                        id="srcbtn-<?php echo $matchId; ?>-<?php echo $i; ?>"
                        data-url="<?php echo esc_attr($src['play']); ?>"
                        data-status="<?php echo esc_attr($health); ?>"
                        onclick="z82OpenStream(<?php echo esc_attr(json_encode($popupUrl)); ?>, <?php echo esc_attr(json_encode(array_map(function($s){ return ['url'=>$s['play'],'raw'=>$s['url'],'label'=>$s['label'],'hls'=>$s['isM3U8']]; }, $sourceGroups))); ?>, <?php echo $i; ?>)">
                    <span class="z82-thumb-wrap" id="thumb-<?php echo $matchId; ?>-<?php echo $i; ?>"<?php if (!empty($src['gif'])): ?> data-gif="<?php echo esc_url($src['gif']); ?>"<?php endif; ?>>
                        <?php if (!empty($src['screenshot'])): ?>
                        <img class="z82-thumb-img" src="<?php echo esc_url($src['screenshot']); ?>" loading="lazy" alt=""
                             onerror="this.style.display='none';this.nextElementSibling.style.display='flex';" />
                        <span class="z82-thumb-placeholder" style="display:none"><?php echo z82_get_sport_icon($p['type']); ?></span>
                        <?php elseif ($photo = z82_photo_for($p['type'], $matchId . '-' . $i)): ?>
                        <img class="z82-thumb-img" src="<?php echo esc_url($photo); ?>" loading="lazy" alt=""
                             onerror="this.style.display='none';this.nextElementSibling.style.display='flex';" />
                        <span class="z82-thumb-placeholder" style="display:none"><?php echo z82_get_sport_icon($p['type']); ?></span>
                        <?php elseif (!empty($p['homeLogo'])): ?>
                        <img class="z82-thumb-logo" src="<?php echo esc_url($p['homeLogo']); ?>" loading="lazy" alt=""
                             onerror="this.style.display='none';this.nextElementSibling.style.display='flex';" />
                        <span class="z82-thumb-placeholder" style="display:none"><?php echo z82_get_sport_icon($p['type']); ?></span>
                        <?php else: ?>
                        <span class="z82-thumb-placeholder"><?php echo z82_get_sport_icon($p['type']); ?></span>
                        <?php endif; ?>
                        <?php if ($p['isLive']): ?>
                        <span class="z82-thumb-live"><span class="z82-live-dot" aria-hidden="true"></span>LIVE</span>
                        <?php endif; ?>
                        <span class="z82-play" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M8 5.5v13a1 1 0 0 0 1.5.86l10.5-6.5a1 1 0 0 0 0-1.72L9.5 4.64A1 1 0 0 0 8 5.5z"/></svg></span>
                    </span>
                    <span class="z82-popup-btn-info">
                        <span class="z82-popup-btn-num">直播<?php echo $i + 1; ?></span>
                        <span class="z82-popup-btn-label"><?php echo esc_html($src['label'] ?: '直播源'); ?></span>
                    </span>
                    <?php if ($healthText !== ''): ?>
                    <span class="z82-stream-badge z82-health-<?php echo $health; ?>" title="<?php echo esc_attr($healthTitle); ?>"><?php echo esc_html($healthText); ?></span>
                    <?php endif; ?>
                </button>
                <?php endforeach; ?>
            </div>
            <div class="z82-popup-hint">点击直播源按钮，将在弹出窗口中播放</div>
            <?php endif; ?>
            <?php else: ?>
            <div class="z82-no-source">暂无直播链接</div>
            <?php endif; ?>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

// ── Sport icon helper ────────────────────────────────────────
// Stroke-based 24×24 SVG icons; colour comes from currentColor via .z82-icon
function z82_get_sport_icon($type) {
    $paths = [
        'football'   => '<circle cx="12" cy="12" r="9"/><path d="M12 7.5l4.3 3.1-1.6 5H9.3l-1.6-5z"/><path d="M12 7.5V3.2M16.3 10.6l4.2-1.4M14.7 15.6l2.6 3.6M9.3 15.6l-2.6 3.6M7.7 10.6L3.5 9.2"/>',
        'basketball' => '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3v18"/><path d="M5.6 5.6a9 9 0 0 1 2.6 6.4 9 9 0 0 1-2.6 6.4M18.4 5.6a9 9 0 0 0-2.6 6.4 9 9 0 0 0 2.6 6.4"/>',
        'ball'       => '<circle cx="12" cy="12" r="9"/><path d="M5.2 5.9a9.5 9.5 0 0 1 0 12.2M18.8 5.9a9.5 9.5 0 0 0 0 12.2"/>',
        'oval'       => '<ellipse cx="12" cy="12" rx="10" ry="6" transform="rotate(-45 12 12)"/><path d="M9 15l6-6M9.6 12.6l1.8 1.8M11.1 11.1l1.8 1.8M12.6 9.6l1.8 1.8"/>',
        'hockey'     => '<path d="M5 3l6.5 13.5H19a1.5 1.5 0 0 1 0 3h-8.5a1.5 1.5 0 0 1-1.3-.8L2.5 4.2"/><ellipse cx="5" cy="19" rx="2.8" ry="1.4"/>',
        'cricket'    => '<path d="M17 4.5l2.5 2.5-10 10-3.5 1 1-3.5z"/><path d="M18.5 5.5L21 3"/><circle cx="6" cy="6" r="2.2"/>',
        'golf'       => '<path d="M12 18V3l7 3.5-7 3.5"/><ellipse cx="12" cy="18.5" rx="7" ry="2.5"/>',
        'racing'     => '<path d="M5 21V4"/><path d="M5 4h13.5l-2.5 4.5 2.5 4.5H5"/>',
        'pingpong'   => '<circle cx="10" cy="10" r="6.5"/><path d="M14.6 14.6l5 5"/><circle cx="19" cy="5.5" r="1.8"/>',
        'fight'      => '<path d="M7 12V8a5 5 0 0 1 10 0v5a4 4 0 0 1-4 4H9.5A2.5 2.5 0 0 1 7 14.5z"/><path d="M7 11H5.5a2 2 0 0 0 0 4H7"/><path d="M9 17v4h6.5v-4.3"/>',
        'volleyball' => '<circle cx="12" cy="12" r="9"/><path d="M12 3c-1 3.5-.5 6.5 0 9M12 12c2.8 1.8 5.8 2.5 8.6 1.8M12 12c-2.3 2.5-3.5 5.3-3.6 8.3"/>',
        'darts'      => '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
        'cue'        => '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="3.5"/>',
        'cycling'    => '<circle cx="6" cy="16" r="3.5"/><circle cx="18" cy="16" r="3.5"/><path d="M6 16l3.5-7h6L18 16M9.5 9l2.5 7H6M15.5 9l-1-3h-2"/>',
        'horse'      => '<path d="M7 20H4.5L4 12a8 8 0 0 1 16 0l-.5 8H17l.4-8a5.4 5.4 0 0 0-10.8 0z"/>',
        'timer'      => '<circle cx="12" cy="13" r="8"/><path d="M12 13V9M10 2h4M12 2v3"/>',
        'trophy'     => '<path d="M8 21h8M12 17v4M7 4h10v5a5 5 0 0 1-10 0z"/><path d="M17 5h3v2a3 3 0 0 1-3 3M7 5H4v2a3 3 0 0 0 3 3"/>',
    ];
    $map = [
        'Football' => 'football', 'Soccer' => 'football',
        'Basketball' => 'basketball', 'Netball' => 'basketball',
        'Tennis' => 'ball', 'Baseball' => 'ball',
        'American Football' => 'oval', 'Rugby' => 'oval', 'Australian Rules' => 'oval',
        'Ice Hockey' => 'hockey', 'Cricket' => 'cricket', 'Golf' => 'golf',
        'Motorsport' => 'racing', 'MotoGP' => 'racing',
        'Table Tennis' => 'pingpong',
        'Boxing' => 'fight', 'UFC/MMA' => 'fight',
        'Volleyball' => 'volleyball', 'Handball' => 'volleyball', 'Water Polo' => 'volleyball',
        'Darts' => 'darts', 'Snooker' => 'cue', 'Billiard' => 'cue',
        'Cycling' => 'cycling', 'Horse Racing' => 'horse',
        'Athletics' => 'timer', 'Swimming' => 'timer', 'Weightlifting' => 'timer', 'Gymnastics' => 'timer',
    ];
    $key = $map[$type] ?? 'trophy';
    return '<svg class="z82-icon z82-sport-icon" viewBox="0 0 24 24" aria-hidden="true">' . $paths[$key] . '</svg>';
}

// ── Sport name CN helper ─────────────────────────────────────
function z82_sport_names() {
    return [
        'Football' => '足球', 'Soccer' => '足球',
        'Basketball' => '篮球', 'American Football' => '美式橄榄球',
        'Tennis' => '网球', 'Table Tennis' => '乒乓球',
        'Cricket' => '板球', 'Rugby' => '橄榄球',
        'Ice Hockey' => '冰球', 'Baseball' => '棒球',
        'Golf' => '高尔夫', 'Boxing' => '拳击',
        'Volleyball' => '排球', 'Cycling' => '自行车',
        'Motorsport' => '赛车', 'MotoGP' => '摩托车',
        'Darts' => '飞镖', 'Snooker' => '斯诺克',
        'Billiard' => '台球', 'UFC/MMA' => '综合格斗',
        'Horse Racing' => '赛马', 'Handball' => '手球',
        'Australian Rules' => '澳式橄榄球', 'Netball' => '无板篮球',
        'Water Polo' => '水球', 'Athletics' => '田径',
        'Gymnastics' => '体操', 'Weightlifting' => '举重',
        'Other' => '其他',
    ];
}

// ── YouTube ──────────────────────────────────────────────────
// Embed + thumbnail for a YouTube source, or null if it isn't one we can embed
function z82_youtube_info($url) {
    if (!preg_match('~(?:youtube\.com|youtu\.be)~i', $url)) return null;
    if (preg_match('~(?:youtu\.be/|[?&]v=|/embed/|/live/|/shorts/|/v/)([A-Za-z0-9_-]{11})~', $url, $m)) {
        return [
            // Privacy-enhanced player: it never tries to sign the viewer in inside the frame. On
            // youtube.com a sign-in check (e.g. "confirm you're not a bot") loops when the browser
            // blocks Google's cookies there: "accounts.google.com redirected you too many times".
            'embed' => 'https://www.youtube-nocookie.com/embed/' . $m[1],
            'thumb' => 'https://i.ytimg.com/vi/' . $m[1] . '/hq720.jpg',   // 16:9 1280×720; script.js falls back to hqdefault
            'watch' => 'https://www.youtube.com/watch?v=' . $m[1],
        ];
    }
    // Channel's current live stream
    if (preg_match('~/channel/(UC[A-Za-z0-9_-]{22})~', $url, $m)) {
        return [
            'embed' => 'https://www.youtube-nocookie.com/embed/live_stream?channel=' . $m[1],
            'thumb' => '',
            'watch' => 'https://www.youtube.com/channel/' . $m[1] . '/live',
        ];
    }
    return null;
}

// ── Photo bank ───────────────────────────────────────────────
const Z82_PHOTO_BANK_MAX = 10;

function z82_photo_bank() {
    $bank = get_option('z82_photo_bank', []);
    return is_array($bank) ? $bank : [];
}

function z82_sanitize_photo_bank($input) {
    $out = [];
    if (!is_array($input)) return $out;
    foreach ($input as $sport => $ids) {
        $ids = array_slice(array_values(array_filter(array_map('absint', explode(',', (string) $ids)))), 0, Z82_PHOTO_BANK_MAX);
        if ($ids) $out[sanitize_text_field((string) $sport)] = $ids;
    }
    return $out;
}

// Image for a card without a screenshot: one of the sport's photos, chosen from the seed
// so each card keeps the same picture across renders (random-looking, but stable)
function z82_photo_for($type, $seed) {
    static $urls = [];
    $bank = z82_photo_bank();
    $key  = !empty($bank[$type]) ? $type : 'default';
    if (empty($bank[$key])) return null;

    if (!isset($urls[$key])) {
        $urls[$key] = array_values(array_filter(array_map(function ($id) {
            return wp_get_attachment_image_url($id, 'medium_large');
        }, $bank[$key])));
    }
    if (!$urls[$key]) return null;
    return $urls[$key][crc32($seed) % count($urls[$key])];
}

// Media picker on the settings page
add_action('admin_enqueue_scripts', function ($hook) {
    if ($hook !== 'settings_page_zhibo82-settings') return;
    wp_enqueue_media();
    wp_add_inline_style('common', '.z82-bank-thumbs{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:8px}.z82-bank-thumbs img{width:64px;height:64px;object-fit:cover;border-radius:4px}.z82-bank-table th{width:220px}');
    wp_add_inline_script('media-editor', "jQuery(function($){
        $('.z82-bank-pick').on('click', function (e) {
            e.preventDefault();
            var row = $(this).closest('.z82-bank'), input = row.find('input'), max = " . Z82_PHOTO_BANK_MAX . ";
            var frame = wp.media({ title: 'Choose up to ' + max + ' images', multiple: true, library: { type: 'image' } });
            frame.on('open', function () {
                var sel = frame.state().get('selection');
                (input.val() || '').split(',').filter(Boolean).forEach(function (id) {
                    var a = wp.media.attachment(id); a.fetch(); sel.add(a);
                });
            });
            frame.on('select', function () {
                var items = frame.state().get('selection').toJSON().slice(0, max);
                input.val(items.map(function (i) { return i.id; }).join(','));
                row.find('.z82-bank-thumbs').html(items.map(function (i) {
                    var u = (i.sizes && i.sizes.thumbnail ? i.sizes.thumbnail.url : i.url);
                    return $('<img alt=\"\">').attr('src', u).prop('outerHTML');
                }).join(''));
                row.find('.z82-bank-clear').prop('hidden', !items.length);
            });
            frame.open();
        });
        $('.z82-bank-clear').on('click', function (e) {
            e.preventDefault();
            var row = $(this).closest('.z82-bank');
            row.find('input').val(''); row.find('.z82-bank-thumbs').empty(); $(this).prop('hidden', true);
        });
    });");
});

function z82_get_sport_name_cn($type) {
    $names = z82_sport_names();
    return $names[$type] ?? $type;
}

// ── Debug shortcode ──────────────────────────────────────────
add_shortcode('zhibo82_debug', function() {
    if (!current_user_can('manage_options')) return '';
    $fixtures = z82_fetch_json(z82_feed_url('fixtures'));
    $live     = z82_fetch_json(z82_feed_url('live'));
    $out = '<div style="background:#f5f5f5;padding:20px;border-radius:8px;font-family:monospace">';
    $out .= '<h3>API Debug</h3>';
    $out .= '<p>Fixtures feed: ' . ($fixtures ? count($fixtures) . ' entries' : 'FAILED') . '</p>';
    $out .= '<p>Live feed: '     . ($live     ? count($live)     . ' entries' : 'FAILED') . '</p>';
    if ($fixtures) {
        $withSrc = array_filter($fixtures, fn($m) => !empty(array_merge(...array_map(fn($ch)=>$ch['sources'], $m['channels']??[[]]))));
        $out .= '<p>fixtures with sources: ' . count($withSrc) . '</p>';
    }
    $out .= '</div>';
    return $out;
});
