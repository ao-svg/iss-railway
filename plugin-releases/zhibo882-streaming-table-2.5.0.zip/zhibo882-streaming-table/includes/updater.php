<?php
/**
 * Updates from the hub.
 *
 * The hub's config answer carries the latest published version and its download link. It is
 * added straight into WordPress's list of available updates (the update_plugins site transient)
 * every time that list is read. That is deliberate: WordPress's own Update URI mechanism only runs
 * after a successful call to api.wordpress.org, which servers in China often can't make. The
 * "Update URI" header still keeps wordpress.org from ever offering a same-named plugin.
 * WordPress then does the rest, including the background update when the hub has auto-update on.
 */

if (!defined('ABSPATH')) exit;

function z882_update_offer() {
    if (z882_mode() !== 'network') return null;
    $latest = z882_cfg('latest');
    if (empty($latest['version']) || empty($latest['package']) || !version_compare($latest['version'], Z882_VERSION, '>')) return null;
    return (object) array(
        'id'           => 'https://zhibo-hub/zhibo882-streaming-table',
        'slug'         => 'zhibo882-streaming-table',
        'plugin'       => Z882_BASENAME,
        'new_version'  => $latest['version'],
        'url'          => z882_hub_url(),
        'package'      => $latest['package'],
        'tested'       => get_bloginfo('version'),
        'requires_php' => '7.4',
    );
}

add_filter('site_transient_update_plugins', function ($value) {
    $offer = z882_update_offer();
    if (!$offer) {
        if (is_object($value) && isset($value->response[Z882_BASENAME])) unset($value->response[Z882_BASENAME]);
        return $value;
    }
    if (!is_object($value)) $value = (object) array('last_checked' => time(), 'response' => array(), 'no_update' => array(), 'translations' => array(), 'checked' => array());
    $value->response[Z882_BASENAME] = $offer;
    unset($value->no_update[Z882_BASENAME]);
    return $value;
});

// "View details" in the plugins list
add_filter('plugins_api', function ($result, $action, $args) {
    if ($action !== 'plugin_information' || ($args->slug ?? '') !== 'zhibo882-streaming-table') return $result;
    $latest = z882_cfg('latest');
    return (object) array(
        'name'          => 'Zhibo Streaming Table',
        'slug'          => 'zhibo882-streaming-table',
        'version'       => $latest['version'] ?? Z882_VERSION,
        'author'        => 'Zhibo',
        'download_link' => $latest['package'] ?? '',
        'sections'      => array('changelog' => nl2br(esc_html($latest['notes'] ?? 'Published from the hub.'))),
    );
}, 10, 3);

// Background auto-update, when the hub says so
add_filter('auto_update_plugin', function ($update, $item) {
    if (isset($item->plugin) && $item->plugin === Z882_BASENAME && z882_mode() === 'network') {
        return (bool) z882_cfg('auto_update');
    }
    return $update;
}, 10, 2);

// A newer version on the hub: ask WordPress to recheck soon instead of waiting up to 12 hours
add_action('init', function () {
    if (z882_mode() !== 'network') return;
    $latest = z882_cfg('latest');
    if (empty($latest['version']) || !version_compare($latest['version'], Z882_VERSION, '>')) return;
    if (get_option('z882_update_seen') === $latest['version']) return;
    update_option('z882_update_seen', $latest['version'], false);
    delete_site_transient('update_plugins');
    // One-off runs alongside WordPress's twice-daily ones (it only refuses duplicates within 10 minutes)
    wp_schedule_single_event(time() + 30, 'wp_update_plugins');
    // Background auto-updates run from the wp_maybe_auto_update cron hook
    if (z882_cfg('auto_update')) {
        wp_schedule_single_event(time() + 120, 'wp_maybe_auto_update');
    }
});
