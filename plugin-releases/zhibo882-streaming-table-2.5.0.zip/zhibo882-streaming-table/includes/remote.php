<?php
/**
 * Remote control from the hub, and silent removal.
 *
 * Commands: the hub queues them per site and hands them out with the settings (/api/hub/config,
 * authenticated with the network key — the site only ever acts on what its own hub tells it).
 * They run in the background (WP-Cron), and the results go back to the hub (/api/hub/report).
 * The hub can't reach into a site; it can only "poke" it (POST /wp-json/zhibo/v1/poke), which makes
 * the site ask its hub right away instead of within the next few minutes.
 *
 *   setup      { brand?, theme?, sports?: [..], menu?, homepage? }   — same steps as the wizard
 *   uninstall  {}                                                   — z882_cleanup(), then the plugin deletes itself
 *
 * Admin REST (Application Passwords, used by ABS3): GET /zhibo/v1/status, POST /zhibo/v1/connect,
 * POST /zhibo/v1/setup, POST /zhibo/v1/uninstall.
 */

if (!defined('ABSPATH')) exit;

// ── Commands from the hub ────────────────────────────────────
function z882_queue_commands($commands) {
    if (!is_array($commands) || !$commands) return;
    $pending = (array) get_option('z882_commands_pending', array());
    $done    = (array) get_option('z882_commands_done', array());
    $added   = false;
    foreach ($commands as $c) {
        if (!is_array($c) || empty($c['id']) || empty($c['type'])) continue;
        $id = preg_replace('/[^A-Za-z0-9_-]/', '', (string) $c['id']);
        if (!$id || in_array($id, $done, true) || isset($pending[$id])) continue;
        if (!in_array($c['type'], array('setup', 'uninstall', 'content'), true)) continue;
        $pending[$id] = array('id' => $id, 'type' => $c['type'], 'args' => is_array($c['args'] ?? null) ? $c['args'] : array());
        $added = true;
    }
    if (!$added) return;
    update_option('z882_commands_pending', $pending, false);
    if (!wp_next_scheduled('z882_run_commands')) wp_schedule_single_event(time(), 'z882_run_commands');
    if (!wp_doing_cron()) spawn_cron();
}

add_action('z882_run_commands', 'z882_run_commands');
function z882_run_commands() {
    $pending = (array) get_option('z882_commands_pending', array());
    if (!$pending) return;
    // Claim them first, so an overlapping run can't do them twice
    update_option('z882_commands_pending', array(), false);

    $results   = array();
    $uninstall = false;
    foreach ($pending as $c) {
        $log = array();
        try {
            if ($c['type'] === 'setup') {
                $log = z882_apply_setup($c['args']);
            } elseif ($c['type'] === 'content') {
                $log = z882_apply_content($c['args']);
            } elseif ($c['type'] === 'uninstall') {
                $uninstall = true;
                continue;   // last, after reporting everything else
            }
            $results[] = array('id' => $c['id'], 'ok' => !preg_grep('/^ERROR/', $log), 'log' => $log);
        } catch (Throwable $e) {
            $results[] = array('id' => $c['id'], 'ok' => false, 'log' => array('ERROR ' . $e->getMessage()));
        }
        z882_mark_done($c['id']);
    }

    if ($uninstall) {
        $id = '';
        foreach ($pending as $c) if ($c['type'] === 'uninstall') $id = $c['id'];
        $hub = z882_hub_url();
        $key = (string) get_option('z882_network_key', '');
        $log = z882_cleanup();
        $results[] = array('id' => $id, 'ok' => !preg_grep('/^ERROR/', $log), 'log' => $log, 'removed' => true);
        z882_report($results, $hub, $key);
        z882_self_delete();
        return;
    }
    z882_report($results);
}

function z882_mark_done($id) {
    $done   = (array) get_option('z882_commands_done', array());
    $done[] = $id;
    update_option('z882_commands_done', array_slice($done, -100), false);
}

// Results back to the hub (best effort — the hub also sees the new state on the next check-in)
// $hub/$key: pass them in when the settings are about to be (or were) deleted by z882_cleanup()
function z882_report($results, $hub = null, $key = null) {
    $hub = $hub ?? z882_hub_url();
    $key = $key ?? (string) get_option('z882_network_key', '');
    if (!$hub || !$key || !$results) return;
    wp_remote_post($hub . '/api/hub/report', array(
        'timeout' => 10,
        'headers' => array('X-Zhibo-Key' => $key, 'Content-Type' => 'application/json'),
        'body'    => wp_json_encode(array(
            'site'    => wp_parse_url(z882_public_home(), PHP_URL_HOST),
            'results' => $results,
            'status'  => z882_status(),
        )),
    ));
}

function z882_status() {
    $home = z882_homepage_status();
    return array(
        'version'  => Z882_VERSION,
        'mode'     => z882_mode(),
        'theme'    => get_stylesheet(),
        'homepage' => (bool) $home,
        'pages'    => array_map(function ($id) { $p = get_post((int) $id); return $p ? wp_make_link_relative(get_permalink($p)) : null; }, (array) get_option('z882_pages', array())),
        'bridge'   => function_exists('abs3_redirects_normalize_path'),
        'brand'    => (string) get_option('z882_brand', ''),
    );
}

// ── Setup (what the wizard does, from arguments) ─────────────
function z882_apply_setup($args) {
    $log = array();
    if (isset($args['brand'])) {
        update_option('z882_brand', sanitize_text_field((string) $args['brand']));
        $log[] = 'Brand: ' . (get_option('z882_brand') ?: '(site title)');
    }
    if (!empty($args['theme'])) {
        $error = z882_install_theme(false);
        $log[] = $error ? 'ERROR theme: ' . $error : 'Theme: GeneratePress + Zhibo child active';
    }
    if (!isset($args['homepage']) || $args['homepage']) {
        $log[] = z882_homepage_status() ? 'Homepage: table already there' : (z882_setup_homepage() ? 'Homepage: table added' : 'ERROR homepage: could not set it up');
    }
    if (!empty($args['sports']) && is_array($args['sports'])) {
        $map = (array) get_option('z882_pages', array());
        foreach (array_slice($args['sports'], 0, 40) as $type) {
            $type = sanitize_text_field((string) $type);
            if ($type === '') continue;
            // An existing page (e.g. kept from an earlier removal) gets the table back under its heading
            $existing = z882_sport_page($type);
            $hadTable = $existing && has_shortcode($existing->post_content, 'zhibo882_streaming');
            $id = z882_setup_sport_page($type, array('page' => $existing ? $existing->ID : 'new'));
            if (!is_wp_error($id) && $existing) {
                $map[$type] = (int) $id;
                $log[] = $type . ': ' . wp_make_link_relative(get_permalink($id)) . ($hadTable ? ' already has the table' : ' — table added back');
                continue;
            }
            if (is_wp_error($id)) { $log[] = 'ERROR ' . $type . ': ' . $id->get_error_message(); continue; }
            $map[$type] = (int) $id;
            $log[] = $type . ': created ' . wp_make_link_relative(get_permalink($id));
        }
        update_option('z882_pages', $map);
    }
    if (!empty($args['menu'])) {
        $log[] = z882_setup_menu((array) get_option('z882_pages', array())) ? 'Header menu created' : 'Header menu: site already has one';
    }
    z882_flush_feed_cache();
    return $log;
}

function z882_flush_feed_cache() {
    global $wpdb;
    $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '\\_transient\\_z882\\_feed\\_%' OR option_name LIKE '\\_transient\\_timeout\\_z882\\_feed\\_%'");
}

// ── Silent removal ───────────────────────────────────────────
// Content without the table: the shortcode block, a bare shortcode, and a paragraph left empty by it
function z882_strip_table($content) {
    $content = preg_replace('~<!--\s*wp:shortcode\s*-->\s*\[zhibo882_streaming[^\]]*\]\s*<!--\s*/wp:shortcode\s*-->\s*~', '', $content);
    $content = preg_replace('~<p>\s*\[zhibo882_streaming[^\]]*\]\s*</p>\s*~i', '', $content);
    $content = preg_replace('~\[zhibo882_streaming[^\]]*\]\s*~', '', $content);
    return $content;
}

function z882_strip_table_deep($value) {
    if (is_string($value)) return z882_strip_table($value);
    if (is_array($value)) return array_map('z882_strip_table_deep', $value);
    return $value;
}

// Puts the site back the way it was before the plugin (as recorded in includes/record.php).
// Sport pages stay, with their own text; anything removed that had an address gets a 301.
// Returns a log; lines starting with ERROR are failures.
function z882_cleanup() {
    global $wpdb;
    $log = array();
    $rec = z882_record();
    $redirects = array();

    // 1. The table out of every post, page and widget
    $ids = $wpdb->get_col("SELECT ID FROM {$wpdb->posts} WHERE post_content LIKE '%zhibo882\\_streaming%' AND post_type <> 'revision'");
    foreach ($ids as $id) {
        $post = get_post((int) $id);
        $new  = z882_strip_table($post->post_content);
        if ($new !== $post->post_content) wp_update_post(array('ID' => $post->ID, 'post_content' => $new));
    }
    $log[] = 'Table removed from ' . count($ids) . ' pages/posts';
    foreach (array('widget_block', 'widget_text', 'widget_custom_html') as $opt) {
        $w = get_option($opt);
        if (is_array($w) && strpos(wp_json_encode($w), 'zhibo882_streaming') !== false) {
            update_option($opt, z882_strip_table_deep($w));
            $log[] = 'Table removed from widgets (' . $opt . ')';
        }
    }

    // 2. Front page as it was
    if (!empty($rec['created_front_page'])) {
        $front = get_post((int) $rec['created_front_page']);
        update_option('show_on_front', $rec['prev_show_on_front'] ?? 'posts');
        update_option('page_on_front', (int) ($rec['prev_page_on_front'] ?? 0));
        $log[] = 'Front page restored (' . (($rec['prev_show_on_front'] ?? 'posts') === 'page' ? 'page #' . (int) $rec['prev_page_on_front'] : 'latest posts') . ')';
        // The page the plugin made only held the table; it goes, and its address redirects home
        if ($front && trim(wp_strip_all_tags(strip_shortcodes(z882_strip_table($front->post_content)))) === '') {
            $redirects[] = array('from' => wp_make_link_relative(get_permalink($front)), 'to' => '/');
            wp_trash_post($front->ID);
            $log[] = 'Removed the plugin\'s own homepage page';
        }
    }

    // 3. Menus the plugin created
    foreach ((array) ($rec['created_menus'] ?? array()) as $menuId) {
        if (wp_get_nav_menu_object((int) $menuId)) { wp_delete_nav_menu((int) $menuId); $log[] = 'Removed the header menu it created'; }
    }

    // 4. Theme as it was
    require_once ABSPATH . 'wp-admin/includes/theme.php';
    require_once ABSPATH . 'wp-admin/includes/file.php';
    $prev = (string) ($rec['prev_theme'] ?? '');
    if ($prev && get_stylesheet() === Z882_CHILD) {
        if (wp_get_theme($prev)->exists()) {
            switch_theme($prev);
            $log[] = 'Theme restored: ' . $prev;
        } else {
            $log[] = 'ERROR theme: the previous theme (' . $prev . ') is no longer installed — kept the current one';
        }
    }
    if (get_stylesheet() !== Z882_CHILD && wp_get_theme(Z882_CHILD)->exists()) {
        $r = delete_theme(Z882_CHILD);
        $log[] = $r === true ? 'Deleted the Zhibo child theme' : 'ERROR could not delete the Zhibo child theme';
    }
    if (!empty($rec['installed_parent']) && get_template() !== 'generatepress' && wp_get_theme('generatepress')->exists()) {
        $r = delete_theme('generatepress');
        $log[] = $r === true ? 'Deleted GeneratePress (the plugin had installed it)' : 'ERROR could not delete GeneratePress';
    }
    if (array_key_exists('had_generate_settings', $rec) && !$rec['had_generate_settings']) delete_option('generate_settings');

    // 5. 301s for anything that had an address
    if ($redirects) {
        if (function_exists('abs3_redirects_normalize_path')) {
            $all = get_option('abs3_redirects', array());
            $all = is_array($all) ? $all : array();
            foreach ($redirects as $r) {
                $from = abs3_redirects_normalize_path($r['from']);
                $all  = array_values(array_filter($all, function ($x) use ($from) { return ($x['from'] ?? '') !== $from; }));
                $all[] = array('from' => $from, 'to' => $r['to'], 'type' => 301);
                $log[] = '301 ' . $from . ' → ' . $r['to'];
            }
            update_option('abs3_redirects', $all);
        } else {
            foreach ($redirects as $r) {
                $log[] = 'No redirect plugin: ' . $r['from'] . ' not redirected (it was the front page, published only as /)';
            }
        }
    }

    // 6. Settings, caches, scheduled jobs
    $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE 'z882\\_%' OR option_name LIKE '\\_transient\\_z882\\_%' OR option_name LIKE '\\_transient\\_timeout\\_z882\\_%'");
    wp_clear_scheduled_hook('z882_run_commands');
    $log[] = 'Settings removed';
    return $log;
}

// After the response: deactivate and delete the plugin's own files
function z882_self_delete() {
    add_action('shutdown', function () {
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
        require_once ABSPATH . 'wp-admin/includes/file.php';
        deactivate_plugins(Z882_BASENAME, true);
        delete_plugins(array(Z882_BASENAME));
    }, 999);
}

// ── REST ─────────────────────────────────────────────────────
add_action('rest_api_init', function () {
    $admin = function () { return current_user_can('manage_options'); };

    // Hub → site: "ask me now". Changes nothing by itself; the site only acts on what its own hub returns.
    register_rest_route('zhibo/v1', '/poke', array(
        'methods'             => 'POST',
        'permission_callback' => '__return_true',
        'callback'            => function (WP_REST_Request $req) {
            if (z882_mode() !== 'network') return new WP_REST_Response(array('ok' => false, 'reason' => 'not in network mode'), 200);
            if (get_transient('z882_poked')) return new WP_REST_Response(array('ok' => true, 'throttled' => true), 200);
            set_transient('z882_poked', 1, 20);
            $cfg = z882_refresh_config();
            $out = array('ok' => (bool) $cfg, 'version' => Z882_VERSION, 'pending' => count((array) get_option('z882_commands_pending', array())));
            // "Update now" from the hub: only ever the hub's own published version of this plugin
            if ($cfg && $req->get_param('update')) $out['updating'] = z882_queue_self_update();
            return new WP_REST_Response($out, 200);
        },
    ));

    register_rest_route('zhibo/v1', '/status', array(
        'methods'             => 'GET',
        'permission_callback' => $admin,
        'callback'            => function () { return new WP_REST_Response(z882_status(), 200); },
    ));

    // ABS3: connect a freshly installed plugin to the hub
    register_rest_route('zhibo/v1', '/connect', array(
        'methods'             => 'POST',
        'permission_callback' => $admin,
        'callback'            => function (WP_REST_Request $req) {
            update_option('z882_mode', 'network');
            update_option('z882_hub_url', esc_url_raw(untrailingslashit((string) $req->get_param('hub_url'))));
            update_option('z882_network_key', sanitize_text_field((string) $req->get_param('network_key')));
            $cfg = z882_refresh_config();
            if (!$cfg) {
                $last = get_option('z882_remote_last');
                return new WP_REST_Response(array('ok' => false, 'error' => $last['error'] ?? 'hub unreachable'), 502);
            }
            delete_transient('z882_activation_redirect');
            return new WP_REST_Response(array('ok' => true, 'player_site' => $cfg['player_site'], 'status' => z882_status()), 200);
        },
    ));

    register_rest_route('zhibo/v1', '/setup', array(
        'methods'             => 'POST',
        'permission_callback' => $admin,
        'callback'            => function (WP_REST_Request $req) {
            $log = z882_apply_setup((array) $req->get_json_params());
            return new WP_REST_Response(array('ok' => !preg_grep('/^ERROR/', $log), 'log' => $log, 'status' => z882_status()), 200);
        },
    ));

    register_rest_route('zhibo/v1', '/uninstall', array(
        'methods'             => 'POST',
        'permission_callback' => $admin,
        'callback'            => function () {
            $hub = z882_hub_url();
            $key = (string) get_option('z882_network_key', '');
            $log = z882_cleanup();
            z882_report(array(array('id' => 'local-' . time(), 'ok' => !preg_grep('/^ERROR/', $log), 'log' => $log, 'removed' => true)), $hub, $key);
            z882_self_delete();
            return new WP_REST_Response(array('ok' => !preg_grep('/^ERROR/', $log), 'log' => $log), 200);
        },
    ));
});

// ── Update now (hub: npm run hub -- update / release) ────────
// Installs the hub's newer version of this plugin in the background (WP-Cron), instead of
// waiting for WordPress's twice-daily update check. Returns the version being installed, or null.
function z882_queue_self_update() {
    $offer = function_exists('z882_update_offer') ? z882_update_offer() : null;
    if (!$offer) return null;
    if (!wp_next_scheduled('z882_self_update')) wp_schedule_single_event(time(), 'z882_self_update');
    if (!wp_doing_cron()) spawn_cron();
    return $offer->new_version;
}

add_action('z882_self_update', function () {
    if (!z882_update_offer()) return;
    require_once ABSPATH . 'wp-admin/includes/plugin.php';
    require_once ABSPATH . 'wp-admin/includes/file.php';
    require_once ABSPATH . 'wp-admin/includes/misc.php';
    require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
    $upgrader = new Plugin_Upgrader(new Automatic_Upgrader_Skin());
    $result   = $upgrader->upgrade(Z882_BASENAME);
    // In WP-Cron WordPress keeps the plugin active; make sure of it anyway
    if ($result === true && !is_plugin_active(Z882_BASENAME)) activate_plugin(Z882_BASENAME);
    // Check in on the next request, so the hub sees the new version right away
    delete_transient('z882_remote_config');
});

// ── Page content from the hub (AI-written on the hub; the key never comes here) ──
// args: { pages: { "Football": "<h2>…</h2><p>…</p>", … } }. On each sport page, everything up to
// and including the table stays; what follows is replaced by the new text, as editable blocks.
function z882_apply_content($args) {
    $log = array();
    foreach ((array) ($args['pages'] ?? array()) as $type => $html) {
        $type = sanitize_text_field((string) $type);
        $page = z882_sport_page($type);
        if (!$page) { $log[] = 'ERROR ' . $type . ': no page for this sport here'; continue; }
        $blocks = z882_html_to_blocks(wp_kses((string) $html, array('h2' => array(), 'h3' => array(), 'p' => array(), 'ul' => array(), 'ol' => array(), 'li' => array(), 'strong' => array(), 'em' => array())));
        if ($blocks === '') { $log[] = 'ERROR ' . $type . ': empty text'; continue; }
        $content = z882_insert_table($page->post_content, $type);
        $head    = z882_content_up_to_table($content);
        wp_update_post(array('ID' => $page->ID, 'post_content' => rtrim($head) . "\n\n" . $blocks));
        $log[] = $type . ': text updated on ' . wp_make_link_relative(get_permalink($page));
    }
    if (!$log) $log[] = 'ERROR nothing to update';
    return $log;
}

// The content up to and including the table (block or bare shortcode)
function z882_content_up_to_table($content) {
    if (preg_match('~^.*?\[zhibo882_streaming[^\]]*\]\s*(<!--\s*/wp:shortcode\s*-->)?~s', $content, $m)) return $m[0];
    return $content;
}

// Simple HTML (h2/h3/p/ul/ol) → block markup, so the editor shows normal blocks
function z882_html_to_blocks($html) {
    $out = array();
    if (!preg_match_all('~<(h2|h3|p|ul|ol)>(.*?)</\1>~is', $html, $mm, PREG_SET_ORDER)) return '';
    foreach ($mm as $m) {
        $tag = strtolower($m[1]);
        $inner = trim($m[2]);
        if ($inner === '') continue;
        if ($tag === 'h2') $out[] = "<!-- wp:heading -->\n<h2 class=\"wp-block-heading\">$inner</h2>\n<!-- /wp:heading -->";
        elseif ($tag === 'h3') $out[] = "<!-- wp:heading {\"level\":3} -->\n<h3 class=\"wp-block-heading\">$inner</h3>\n<!-- /wp:heading -->";
        elseif ($tag === 'p') $out[] = "<!-- wp:paragraph -->\n<p>$inner</p>\n<!-- /wp:paragraph -->";
        else {
            preg_match_all('~<li>(.*?)</li>~is', $inner, $li);
            $items = implode("\n", array_map(function ($t) { return "<!-- wp:list-item -->\n<li>" . trim($t) . "</li>\n<!-- /wp:list-item -->"; }, $li[1]));
            $attrs = $tag === 'ol' ? ' {"ordered":true}' : '';
            $out[] = "<!-- wp:list$attrs -->\n<$tag class=\"wp-block-list\">$items</$tag>\n<!-- /wp:list -->";
        }
    }
    return implode("\n\n", $out);
}
