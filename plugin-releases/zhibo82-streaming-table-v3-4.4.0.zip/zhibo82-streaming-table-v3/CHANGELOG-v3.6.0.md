# v3.6.0 - MAJOR UPDATE

## 🎯 ALL FIXES:

### 1. Mobile Popup Prompt Height ✅
- Increased button height on mobile
- Better visibility for "在新窗口中观看" prompt
- Min-height: 60px on mobile

### 2. Sport Icons on Featured Videos ✅
- Each thumbnail shows sport type icon
- Icons positioned top-left
- Better visual context

### 3. Better Sport Type Icons ✅
- Replaced emoji with HTML SVG icons
- Custom icons for each sport
- Professional appearance
- All sports covered (Football, Basketball, Tennis, etc.)

### 4. Improved Minimize Player ✅
- Resizable (drag corners/edges)
- No orange bar
- Chrome-style PiP
- Smooth dragging
- Position memory

### 5. Admin Panel for App Control ✅
- Settings modal for platform control
- Toggle app bar per platform:
  - Android
  - iOS  
  - Windows + Linux
  - Desktop browsers
- Saves to localStorage

### 6. YouTube Accessibility Check ✅
- Checks if YouTube is accessible (China)
- Hides featured section if blocked
- Graceful fallback
- No broken thumbnails

## Technical Details:

- Version: 3.6.0
- Major refactor of minimize player
- New SVG icon system
- Admin settings panel
- YouTube connectivity detection
