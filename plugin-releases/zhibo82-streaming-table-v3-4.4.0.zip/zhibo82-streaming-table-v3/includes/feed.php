<?php
/**
 * Data feeds — configurable URLs, and keeping the feed host out of the page.
 *
 * - Stream links the feed wraps in its redirect (https://<feed>/go?u=<real link>) are played
 *   as-is (the feed relays them); z82_unwrap_source() gives the real link for everything else
 *   (YouTube detection, cached media keys) and the player's fallback.
 * - Screenshots / GIFs hosted on the feed are fetched by this server, cached in
 *   uploads/z82-media/ and served from this site. Cached copies also survive the feed
 *   host losing its files.
 * Both work off whatever feed URLs are configured, so a custom domain later needs no code change.
 */

if (!defined('ABSPATH')) exit;

const Z82_MEDIA_TTL = 2 * DAY_IN_SECONDS;

function z82_feed_url($which) {
    // Connected to the hub: its feeds (the same every schedule site reads)
    $hub = function_exists('z82_hub_feed') ? z82_hub_feed($which) : null;
    if ($hub) return $hub;
    $default = $which === 'live' ? Z82_DEFAULT_FEED_LIVE : Z82_DEFAULT_FEED_FIXTURES;
    $url = get_option($which === 'live' ? 'z82_feed_live' : 'z82_feed_fixtures', '');
    return $url ?: $default;
}

// Scheme + host of every configured feed, e.g. https://iss-railway-production.up.railway.app
function z82_feed_origins() {
    static $origins = null;
    if ($origins !== null) return $origins;
    $origins = [];
    foreach (['fixtures', 'live'] as $which) {
        $u = wp_parse_url(z82_feed_url($which));
        if (!empty($u['host'])) {
            $origins[] = strtolower(($u['scheme'] ?? 'https') . '://' . $u['host'] . (isset($u['port']) ? ':' . $u['port'] : ''));
        }
    }
    return $origins = array_values(array_unique($origins));
}

function z82_is_feed_url($url) {
    $u = wp_parse_url((string) $url);
    if (empty($u['host'])) return false;
    $origin = strtolower(($u['scheme'] ?? 'https') . '://' . $u['host'] . (isset($u['port']) ? ':' . $u['port'] : ''));
    return in_array($origin, z82_feed_origins(), true);
}

// https://<feed>/go?u=<encoded link> → <link>
function z82_unwrap_source($url) {
    if (!z82_is_feed_url($url)) return $url;
    $query = wp_parse_url($url, PHP_URL_QUERY);
    if (!$query) return $url;
    parse_str($query, $params);
    $inner = isset($params['u']) ? (string) $params['u'] : '';
    return preg_match('~^https?://~i', $inner) ? $inner : $url;
}

// ── Media served from this site ──────────────────────────────
function z82_media_dir() {
    $up = wp_upload_dir();
    return ['path' => trailingslashit($up['basedir']) . 'z82-media/', 'url' => trailingslashit($up['baseurl']) . 'z82-media/'];
}

// Only simple image paths, e.g. "screenshots/7a9d….gif"
function z82_media_path_ok($path) {
    return (bool) preg_match('~^[A-Za-z0-9_\-/]+\.(png|jpe?g|gif|webp)$~i', $path) && strpos($path, '..') === false;
}

function z82_media_file($path) {
    return md5($path) . '.' . strtolower(pathinfo($path, PATHINFO_EXTENSION));
}

// Page URL for a feed image: the cached copy if we have it, otherwise our proxy endpoint
function z82_media_url($url) {
    if (empty($url)) return null;
    if (!z82_is_feed_url($url)) return $url;            // hosted elsewhere: nothing to hide

    $path = ltrim((string) wp_parse_url($url, PHP_URL_PATH), '/');
    if (!z82_media_path_ok($path)) return null;          // unexpected shape → don't expose it

    $dir  = z82_media_dir();
    $file = z82_media_file($path);
    if (file_exists($dir['path'] . $file)) return $dir['url'] . $file;
    return add_query_arg('z82_media', rawurlencode($path), home_url('/'));
}

// /?z82_media=screenshots/x.gif → fetch from the feed once, cache, serve
add_action('init', function () {
    if (!isset($_GET['z82_media'])) return;
    $path = rawurldecode((string) wp_unslash($_GET['z82_media']));
    if (!z82_media_path_ok($path)) { status_header(404); exit; }

    $dir  = z82_media_dir();
    $file = $dir['path'] . z82_media_file($path);

    if (!file_exists($file)) {
        $body = null;
        foreach (z82_feed_origins() as $origin) {
            $res = wp_remote_get($origin . '/' . $path, ['timeout' => 15]);
            if (!is_wp_error($res) && wp_remote_retrieve_response_code($res) === 200) {
                $type = (string) wp_remote_retrieve_header($res, 'content-type');
                if (strpos($type, 'image/') === 0) { $body = wp_remote_retrieve_body($res); break; }
            }
        }
        if ($body === null) { status_header(404); exit; }
        wp_mkdir_p($dir['path']);
        file_put_contents($file, $body);
    }

    $types = ['png' => 'image/png', 'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'gif' => 'image/gif', 'webp' => 'image/webp'];
    header('Content-Type: ' . ($types[strtolower(pathinfo($file, PATHINFO_EXTENSION))] ?? 'application/octet-stream'));
    header('Content-Length: ' . filesize($file));
    header('Cache-Control: public, max-age=21600');
    readfile($file);
    exit;
}, 0);

// ── Keeping thumbnails through feed resets ───────────────────
// The feed host wipes its screenshots/GIFs whenever it restarts. So every fresh feed:
//  1. remember each stream's latest screenshot/GIF (by stream link), for up to Z82_MEDIA_TTL
//  2. download them in the background right away, while they still exist
// When a stream later arrives without media, its last cached screenshot/GIF is used.

function z82_media_memory() {
    $m = get_option('z82_media_memory', []);
    return is_array($m) ? $m : [];
}

function z82_media_path_of($url) {
    if (empty($url) || !z82_is_feed_url($url)) return null;
    $path = ltrim((string) wp_parse_url($url, PHP_URL_PATH), '/');
    return z82_media_path_ok($path) ? $path : null;
}

// Called from z82_fetch_matches() with every freshly fetched feed
function z82_media_remember(array $matches) {
    $memory = z82_media_memory();
    $now    = time();
    $new    = false;

    foreach ($matches as $m) {
        foreach ($m['channels'] ?? [] as $ch) {
            foreach ($ch['sources'] ?? [] as $i => $url) {
                if (empty($url)) continue;
                $shot = z82_media_path_of($ch['sourceScreenshot'][$i] ?? null);
                $gif  = z82_media_path_of($ch['sourceGif'][$i] ?? null);
                if (!$shot && !$gif) continue;
                $key = md5(z82_unwrap_source($url));
                $old = $memory[$key] ?? [];
                $memory[$key] = ['s' => $shot ?: ($old['s'] ?? null), 'g' => $gif ?: ($old['g'] ?? null), 't' => $now];
                if ($old != $memory[$key]) $new = true;
            }
        }
    }

    // Forget streams not seen for a while
    foreach ($memory as $k => $v) {
        if (($v['t'] ?? 0) < $now - Z82_MEDIA_TTL) unset($memory[$k]);
    }
    update_option('z82_media_memory', $memory, false);

    if ($new && !wp_next_scheduled('z82_media_prefetch')) wp_schedule_single_event($now, 'z82_media_prefetch');
}

// Background: download whatever isn't cached yet
add_action('z82_media_prefetch', function () {
    $dir = z82_media_dir();
    wp_mkdir_p($dir['path']);
    $deadline = time() + 100;
    foreach (z82_media_memory() as $v) {
        foreach ([$v['s'] ?? null, $v['g'] ?? null] as $path) {
            if (!$path || time() > $deadline) continue;
            $file = $dir['path'] . z82_media_file($path);
            if (file_exists($file)) { @touch($file); continue; }   // still in use → keep it
            foreach (z82_feed_origins() as $origin) {
                $res = wp_remote_get($origin . '/' . $path, ['timeout' => 8]);
                if (!is_wp_error($res) && wp_remote_retrieve_response_code($res) === 200
                    && strpos((string) wp_remote_retrieve_header($res, 'content-type'), 'image/') === 0) {
                    file_put_contents($file, wp_remote_retrieve_body($res));
                    break;
                }
            }
        }
    }
});

// Last cached screenshot ('s') or GIF ('g') for a stream link, as a page URL — or null
function z82_media_fallback($streamUrl, $kind) {
    static $memory = null;
    if ($memory === null) $memory = z82_media_memory();
    $path = $memory[md5($streamUrl)][$kind] ?? null;
    if (!$path) return null;
    $dir  = z82_media_dir();
    $file = z82_media_file($path);
    return file_exists($dir['path'] . $file) ? $dir['url'] . $file : null;
}

// Daily: drop cached media nobody has needed for a while
add_action('init', function () {
    if (!wp_next_scheduled('z82_media_cleanup')) wp_schedule_event(time() + HOUR_IN_SECONDS, 'daily', 'z82_media_cleanup');
});

add_action('z82_media_cleanup', function () {
    $dir = z82_media_dir()['path'];
    foreach ((array) glob($dir . '*') as $f) {
        if (is_file($f) && filemtime($f) < time() - Z82_MEDIA_TTL) @unlink($f);
    }
});
