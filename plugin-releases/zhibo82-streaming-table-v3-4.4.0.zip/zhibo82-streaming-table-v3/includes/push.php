<?php
/**
 * Match reminders — browser push notifications when an upcoming match is about to start.
 *
 * Plain Web Push (RFC 8030 / 8291 aes128gcm / 8292 VAPID) using PHP's OpenSSL, no libraries
 * or third-party accounts. The visitor's browser vendor runs the push service (Google FCM,
 * Mozilla, Microsoft, Apple); we POST an encrypted message to the endpoint it gives us.
 *
 * Flow: bell on an upcoming row → browser subscribes → z82_push_remind stores the
 * subscription + match → WP-Cron (every minute) sends due reminders → assets/sw.js shows
 * the notification and opens #match-… on click.
 */

if (!defined('ABSPATH')) exit;

const Z82_PUSH_DB_VERSION = '1';

function z82_push_enabled() {
    return get_option('z82_push_enabled', '1') === '1';
}

// Minutes before kickoff the reminder goes out
function z82_push_lead() {
    return absint(get_option('z82_push_lead', 5));
}

function z82_push_tables() {
    global $wpdb;
    return [$wpdb->prefix . 'z82_push_subs', $wpdb->prefix . 'z82_push_reminders'];
}

// ── Tables ───────────────────────────────────────────────────
add_action('plugins_loaded', function () {
    if (get_option('z82_push_db') === Z82_PUSH_DB_VERSION) return;

    global $wpdb;
    [$subs, $rem] = z82_push_tables();
    $charset = $wpdb->get_charset_collate();
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';

    dbDelta("CREATE TABLE $subs (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  endpoint text NOT NULL,
  endpoint_hash char(32) NOT NULL,
  p256dh varchar(255) NOT NULL,
  auth varchar(64) NOT NULL,
  user_id bigint(20) unsigned NOT NULL DEFAULT 0,
  created_at datetime NOT NULL,
  PRIMARY KEY  (id),
  UNIQUE KEY endpoint_hash (endpoint_hash)
) $charset;");

    dbDelta("CREATE TABLE $rem (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  sub_id bigint(20) unsigned NOT NULL,
  match_id varchar(40) NOT NULL,
  title varchar(255) NOT NULL,
  league varchar(255) NOT NULL DEFAULT '',
  start_ts int(10) unsigned NOT NULL,
  sent tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY  (id),
  UNIQUE KEY sub_match (sub_id,match_id),
  KEY due (sent,start_ts)
) $charset;");

    update_option('z82_push_db', Z82_PUSH_DB_VERSION);
});

// ── Crypto helpers ───────────────────────────────────────────
function z82_b64u_encode($bin) {
    return rtrim(strtr(base64_encode($bin), '+/', '-_'), '=');
}

function z82_b64u_decode($str) {
    return (string) base64_decode(strtr($str, '-_', '+/') . str_repeat('=', (4 - strlen($str) % 4) % 4));
}

function z82_ec_args() {
    $args = ['curve_name' => 'prime256v1', 'private_key_type' => OPENSSL_KEYTYPE_EC];
    // Windows PHP builds can't create keys without being pointed at openssl.cnf
    if (DIRECTORY_SEPARATOR === '\\' && !getenv('OPENSSL_CONF')) {
        $cnf = dirname(PHP_BINARY) . '/extras/ssl/openssl.cnf';
        if (file_exists($cnf)) $args['config'] = $cnf;
    }
    return $args;
}

// Uncompressed P-256 point: 0x04 || X || Y (65 bytes)
function z82_ec_public_raw($key) {
    $d = openssl_pkey_get_details($key);
    return "\x04" . str_pad($d['ec']['x'], 32, "\0", STR_PAD_LEFT) . str_pad($d['ec']['y'], 32, "\0", STR_PAD_LEFT);
}

function z82_ec_public_from_raw($raw) {
    // SubjectPublicKeyInfo header for an uncompressed prime256v1 key
    $der = hex2bin('3059301306072a8648ce3d020106082a8648ce3d030107034200') . $raw;
    $pem = "-----BEGIN PUBLIC KEY-----\n" . chunk_split(base64_encode($der), 64, "\n") . "-----END PUBLIC KEY-----\n";
    return openssl_pkey_get_public($pem);
}

// VAPID key pair, created once and kept in wp_options
function z82_vapid() {
    $v = get_option('z82_vapid');
    if (is_array($v) && !empty($v['private']) && !empty($v['public'])) return $v;

    $key = openssl_pkey_new(z82_ec_args());
    if (!$key || !openssl_pkey_export($key, $pem, null, z82_ec_args())) return null;

    $v = ['private' => $pem, 'public' => z82_b64u_encode(z82_ec_public_raw($key))];
    update_option('z82_vapid', $v, false);
    return $v;
}

// OpenSSL returns ECDSA signatures as DER; JWT ES256 wants raw r || s (64 bytes)
function z82_der_to_raw_sig($der) {
    $pos = 2;
    if (ord($der[1]) & 0x80) $pos += ord($der[1]) & 0x7f;
    $raw = '';
    for ($i = 0; $i < 2; $i++) {
        $pos++;                                   // INTEGER tag
        $len = ord($der[$pos++]);
        $int = ltrim(substr($der, $pos, $len), "\0");
        $pos += $len;
        $raw .= str_pad($int, 32, "\0", STR_PAD_LEFT);
    }
    return $raw;
}

function z82_vapid_jwt($endpoint, $vapid) {
    $u   = wp_parse_url($endpoint);
    $aud = $u['scheme'] . '://' . $u['host'] . (isset($u['port']) ? ':' . $u['port'] : '');
    $input = z82_b64u_encode(wp_json_encode(['typ' => 'JWT', 'alg' => 'ES256'])) . '.' .
             z82_b64u_encode(wp_json_encode(['aud' => $aud, 'exp' => time() + 12 * HOUR_IN_SECONDS, 'sub' => 'mailto:' . get_option('admin_email')]));

    $key = openssl_pkey_get_private($vapid['private']);
    if (!$key || !openssl_sign($input, $der, $key, OPENSSL_ALGO_SHA256)) return null;
    return $input . '.' . z82_b64u_encode(z82_der_to_raw_sig($der));
}

// RFC 8291 message encryption, single aes128gcm record
function z82_push_encrypt($payload, $p256dh, $auth) {
    $uaPublic   = z82_b64u_decode($p256dh);
    $authSecret = z82_b64u_decode($auth);
    if (strlen($uaPublic) !== 65 || strlen($authSecret) < 16) return null;

    $uaKey = z82_ec_public_from_raw($uaPublic);
    $local = openssl_pkey_new(z82_ec_args());
    if (!$uaKey || !$local) return null;

    $asPublic = z82_ec_public_raw($local);
    $shared   = openssl_pkey_derive($uaKey, $local, 32);
    if ($shared === false) return null;

    $ikm   = hash_hkdf('sha256', $shared, 32, "WebPush: info\0" . $uaPublic . $asPublic, $authSecret);
    $salt  = random_bytes(16);
    $cek   = hash_hkdf('sha256', $ikm, 16, "Content-Encoding: aes128gcm\0", $salt);
    $nonce = hash_hkdf('sha256', $ikm, 12, "Content-Encoding: nonce\0", $salt);

    // 0x02 = padding delimiter for the last (only) record
    $cipher = openssl_encrypt($payload . "\x02", 'aes-128-gcm', $cek, OPENSSL_RAW_DATA, $nonce, $tag, '', 16);
    if ($cipher === false) return null;

    // Header: salt | record size | key id length | key id (our ephemeral public key)
    return $salt . pack('N', 4096) . chr(65) . $asPublic . $cipher . $tag;
}

// Only the browser vendors' push services — never an arbitrary URL (SSRF)
function z82_push_endpoint_allowed($url) {
    $u = wp_parse_url($url);
    if (empty($u['scheme']) || $u['scheme'] !== 'https' || empty($u['host'])) return false;
    return (bool) preg_match(
        '/(^|\.)(fcm\.googleapis\.com|android\.googleapis\.com|push\.services\.mozilla\.com|notify\.windows\.com|push\.apple\.com)$/i',
        $u['host']
    );
}

// Returns the push service's HTTP status (201 = accepted), 0 on local failure
function z82_push_send($sub, array $message) {
    $vapid = z82_vapid();
    if (!$vapid || !z82_push_endpoint_allowed($sub->endpoint)) return 0;

    $body = z82_push_encrypt(wp_json_encode($message), $sub->p256dh, $sub->auth);
    $jwt  = z82_vapid_jwt($sub->endpoint, $vapid);
    if (!$body || !$jwt) return 0;

    $res = wp_remote_post($sub->endpoint, [
        'timeout' => 8,
        'headers' => [
            'Content-Type'     => 'application/octet-stream',
            'Content-Encoding' => 'aes128gcm',
            'TTL'              => '1800',
            'Urgency'          => 'high',
            'Authorization'    => 'vapid t=' . $jwt . ', k=' . $vapid['public'],
        ],
        'body'    => $body,
    ]);
    return is_wp_error($res) ? 0 : (int) wp_remote_retrieve_response_code($res);
}

function z82_push_message($r, $now = null) {
    $now  = $now ?: time();
    $mins = (int) max(0, round(($r->start_ts - $now) / 60));
    return [
        'title' => $r->title,
        'body'  => ($mins > 0 ? $mins . ' 分钟后开赛' : '比赛已开始') . ($r->league ? ' · ' . $r->league : '') . ' — 点击观看直播',
        'url'   => home_url('/#' . $r->match_id),
        'tag'   => $r->match_id,
        'icon'  => apply_filters('z82_push_icon', get_site_icon_url(192)),
    ];
}

// ── Sending (WP-Cron, every minute) ──────────────────────────
add_filter('cron_schedules', function ($schedules) {
    $schedules['z82_minute'] = ['interval' => 60, 'display' => 'Every minute (Zhibo82 reminders)'];
    return $schedules;
});

add_action('init', function () {
    if (z82_push_enabled() && !wp_next_scheduled('z82_push_cron')) {
        wp_schedule_event(time() + 60, 'z82_minute', 'z82_push_cron');
    }
});

add_action('z82_push_cron', 'z82_push_run');
function z82_push_run() {
    if (!z82_push_enabled()) return;
    global $wpdb;
    [$subs, $rem] = z82_push_tables();
    $now = time();

    // Due = inside the lead window; anything more than 2h past kickoff is dropped
    $due = $wpdb->get_results($wpdb->prepare(
        "SELECT r.*, s.endpoint, s.p256dh, s.auth FROM $rem r JOIN $subs s ON s.id = r.sub_id
         WHERE r.sent = 0 AND r.start_ts <= %d AND r.start_ts > %d ORDER BY r.start_ts LIMIT 100",
        $now + z82_push_lead() * MINUTE_IN_SECONDS, $now - 2 * HOUR_IN_SECONDS
    ));

    foreach ($due as $r) {
        // Claim before sending so an overlapping run can't send twice
        if (!$wpdb->update($rem, ['sent' => 1], ['id' => $r->id, 'sent' => 0])) continue;

        $code = z82_push_send($r, z82_push_message($r, $now));
        if ($code === 404 || $code === 410) {
            // Subscription expired or revoked by the browser
            $wpdb->delete($rem, ['sub_id' => $r->sub_id]);
            $wpdb->delete($subs, ['id' => $r->sub_id]);
        }
    }

    $wpdb->query($wpdb->prepare("DELETE FROM $rem WHERE start_ts < %d", $now - DAY_IN_SECONDS));
}

// ── Subscribe / unsubscribe a match ──────────────────────────
function z82_push_find_upcoming($matchId) {
    foreach (z82_fetch_matches() as $m) {
        if (empty($m['eventId']) || 'match-' . md5($m['eventId']) !== $matchId) continue;
        $p = z82_parse_match($m);
        if (!$p || !$p['dateObj'] || $p['dateObj']->getTimestamp() <= time()) return null;
        return ['title' => $p['match'], 'league' => $p['league'], 'start' => $p['dateObj']->getTimestamp()];
    }
    return null;
}

function z82_ajax_push_remind() {
    if (!z82_push_enabled()) wp_send_json_error(['message' => '开播提醒暂未开放'], 403);

    $sub     = json_decode(wp_unslash($_POST['subscription'] ?? ''), true);
    $matchId = sanitize_text_field(wp_unslash($_POST['match_id'] ?? ''));
    $on      = ($_POST['on'] ?? '1') === '1';

    $endpoint = is_array($sub) ? (string) ($sub['endpoint'] ?? '') : '';
    $p256dh   = is_array($sub) ? (string) ($sub['keys']['p256dh'] ?? '') : '';
    $auth     = is_array($sub) ? (string) ($sub['keys']['auth'] ?? '') : '';

    if (!preg_match('/^match-[a-f0-9]{32}$/', $matchId)
        || !z82_push_endpoint_allowed($endpoint) || strlen($endpoint) > 1000
        || !preg_match('/^[A-Za-z0-9_-]{80,100}$/', $p256dh)
        || !preg_match('/^[A-Za-z0-9_-]{16,30}$/', $auth)) {
        wp_send_json_error(['message' => '无效的通知订阅'], 400);
    }

    global $wpdb;
    [$subs, $rem] = z82_push_tables();
    $hash  = md5($endpoint);
    $subId = (int) $wpdb->get_var($wpdb->prepare("SELECT id FROM $subs WHERE endpoint_hash = %s", $hash));

    if (!$on) {
        if ($subId) $wpdb->delete($rem, ['sub_id' => $subId, 'match_id' => $matchId]);
        wp_send_json_success(['on' => false]);
    }

    $match = z82_push_find_upcoming($matchId);
    if (!$match) wp_send_json_error(['message' => '比赛已开始或不存在'], 404);

    if ($subId) {
        $wpdb->update($subs, ['p256dh' => $p256dh, 'auth' => $auth], ['id' => $subId]);
    } else {
        $wpdb->insert($subs, [
            'endpoint'      => $endpoint,
            'endpoint_hash' => $hash,
            'p256dh'        => $p256dh,
            'auth'          => $auth,
            'user_id'       => get_current_user_id(),
            'created_at'    => current_time('mysql', true),
        ]);
        $subId = (int) $wpdb->insert_id;
    }

    if ((int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $rem WHERE sub_id = %d AND sent = 0", $subId)) >= 100) {
        wp_send_json_error(['message' => '提醒数量已达上限'], 429);
    }

    $wpdb->query($wpdb->prepare(
        "INSERT INTO $rem (sub_id, match_id, title, league, start_ts, sent) VALUES (%d, %s, %s, %s, %d, 0)
         ON DUPLICATE KEY UPDATE title = VALUES(title), league = VALUES(league), start_ts = VALUES(start_ts), sent = 0",
        $subId, $matchId, mb_substr($match['title'], 0, 250), mb_substr($match['league'], 0, 250), $match['start']
    ));

    wp_send_json_success(['on' => true, 'start' => $match['start']]);
}
add_action('wp_ajax_z82_push_remind', 'z82_ajax_push_remind');
add_action('wp_ajax_nopriv_z82_push_remind', 'z82_ajax_push_remind');

// ── Service worker ───────────────────────────────────────────
// Served from the site root (/?z82_sw=1) so it can control every page.
add_action('init', function () {
    if (!isset($_GET['z82_sw']) || $_GET['z82_sw'] !== '1') return;
    header('Content-Type: application/javascript; charset=utf-8');
    header('Service-Worker-Allowed: /');
    header('Cache-Control: no-cache');
    readfile(Z82_PLUGIN_PATH . 'assets/sw.js');
    exit;
}, 0);

// Front-end config (merged into z82Config)
function z82_push_client_config() {
    $vapid = z82_push_enabled() ? z82_vapid() : null;
    return [
        'enabled' => (bool) $vapid,
        'key'     => $vapid ? $vapid['public'] : '',
        'sw'      => add_query_arg('z82_sw', '1', home_url('/')),
        'scope'   => wp_parse_url(home_url('/'), PHP_URL_PATH) ?: '/',
        'lead'    => z82_push_lead(),
        'icon'    => apply_filters('z82_push_icon', get_site_icon_url(192)),
    ];
}

function z82_push_stats() {
    global $wpdb;
    [$subs, $rem] = z82_push_tables();
    return [
        'subscribers' => (int) $wpdb->get_var("SELECT COUNT(*) FROM $subs"),
        'pending'     => (int) $wpdb->get_var("SELECT COUNT(*) FROM $rem WHERE sent = 0"),
        'sent'        => (int) $wpdb->get_var("SELECT COUNT(*) FROM $rem WHERE sent = 1"),
    ];
}
