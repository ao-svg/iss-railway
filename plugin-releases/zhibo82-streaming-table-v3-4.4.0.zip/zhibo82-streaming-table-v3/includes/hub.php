<?php
/**
 * Hub connection — this site as a player site of the network (the iss-railway service,
 * "WordPress sites" page).
 *
 * - Checks in every few minutes (plugin version, WordPress, PHP, theme) while asking for its settings.
 * - While connected, the feeds come from the hub — the same ones every schedule site reads, so
 *   their match links always find the match here.
 * - Plugin updates published on the hub show up in WordPress (and install in the background
 *   when the hub has auto-update on).
 * The last good answer is kept, so a hub outage changes nothing here.
 */

if (!defined('ABSPATH')) exit;

const Z82_HUB_SLUG = 'zhibo82-streaming-table-v3';
const Z82_HUB_TTL  = 5 * MINUTE_IN_SECONDS;

function z82_hub_url() {
    return untrailingslashit((string) get_option('z82_hub_url', ''));
}

function z82_hub_connected() {
    return z82_hub_url() !== '' && (string) get_option('z82_network_key', '') !== '';
}

// The hub's settings for this site (cached), or null when not connected / never reached
// (Remembered for the rest of the request in $GLOBALS['z82_hub_memo']; z82_hub_refresh() resets it.)
function z82_hub_config() {
    if (array_key_exists('z82_hub_memo', $GLOBALS)) return $GLOBALS['z82_hub_memo'];
    if (!z82_hub_connected()) return $GLOBALS['z82_hub_memo'] = null;

    $cached = get_transient('z82_hub_config');
    if (is_array($cached)) return $GLOBALS['z82_hub_memo'] = $cached;

    $fresh = z82_hub_fetch();
    if ($fresh) return $GLOBALS['z82_hub_memo'] = $fresh;

    $last = get_option('z82_hub_last');
    if (is_array($last) && !empty($last['config'])) {
        set_transient('z82_hub_config', $last['config'], MINUTE_IN_SECONDS);   // hub unreachable: retry in a minute
        return $GLOBALS['z82_hub_memo'] = $last['config'];
    }
    return $GLOBALS['z82_hub_memo'] = null;
}

// This site's public address, as the hub should list it. zhibo82.com's server runs WP-cron with
// home_url() = https://127.0.0.1, so a check-in from a background job would register "127.0.0.1":
// an IP or localhost is replaced by the last public address seen.
function z82_public_home() {
    $public = function ($host) {
        return $host && strpos($host, '.') !== false && $host !== 'localhost' && !filter_var($host, FILTER_VALIDATE_IP);
    };
    $home = home_url('/');
    $host = strtolower((string) wp_parse_url($home, PHP_URL_HOST));
    if (!$public($host)) {
        // A visitor's request knows the real name even when home_url() doesn't
        $req = strtolower(preg_replace('/:\d+$/', '', (string) ($_SERVER['HTTP_HOST'] ?? '')));
        if (wp_doing_cron() || !$public($req)) return (string) get_option('z82_public_home', '') ?: $home;
        $home = (wp_parse_url($home, PHP_URL_SCHEME) ?: 'https') . '://' . $req . '/';
    }
    if (get_option('z82_public_home') !== $home) update_option('z82_public_home', $home, false);
    return $home;
}

function z82_hub_fetch() {
    $last = get_option('z82_hub_last');
    $last = is_array($last) ? $last : array();
    $home = z82_public_home();

    $url = add_query_arg(array(
        'site'   => rawurlencode(wp_parse_url($home, PHP_URL_HOST)),
        'home'   => rawurlencode($home),
        'plugin' => Z82_HUB_SLUG,
        'v'      => Z82_VERSION,
        'wp'     => rawurlencode(get_bloginfo('version')),
        'php'    => PHP_VERSION,
        'theme'  => rawurlencode(get_stylesheet()),
    ), z82_hub_url() . '/api/hub/config');

    $res  = wp_remote_get($url, array('timeout' => 6, 'headers' => array('X-Zhibo-Key' => (string) get_option('z82_network_key', ''))));
    $code = is_wp_error($res) ? 0 : wp_remote_retrieve_response_code($res);
    $data = $code === 200 ? json_decode(wp_remote_retrieve_body($res), true) : null;
    $cfg  = is_array($data) ? z82_hub_sanitize($data) : null;

    if (!$cfg) {
        $last['error']    = is_wp_error($res) ? $res->get_error_message() : ($code === 401 ? 'Wrong network key' : 'Hub answered HTTP ' . $code);
        $last['error_at'] = time();
        update_option('z82_hub_last', $last, false);
        return null;
    }
    update_option('z82_hub_last', array('config' => $cfg, 'at' => time()), false);
    set_transient('z82_hub_config', $cfg, Z82_HUB_TTL);
    return $cfg;
}

// Only known keys, only http(s) URLs
function z82_hub_sanitize($d) {
    $url = function ($u) { $u = esc_url_raw((string) $u, array('http', 'https')); return $u ?: null; };
    $cfg = array('role' => (string) ($d['role'] ?? ''));
    if (!empty($d['feeds']['fixtures']) && $url($d['feeds']['fixtures'])) {
        $cfg['feeds'] = array('fixtures' => $url($d['feeds']['fixtures']), 'live' => $url($d['feeds']['live'] ?? '') ?: null);
    }
    $cfg['auto_update'] = !empty($d['auto_update']);
    if (!empty($d['latest']['version']) && !empty($d['latest']['package']) && $url($d['latest']['package'])) {
        $cfg['latest'] = array(
            'version' => preg_replace('/[^0-9A-Za-z.\-]/', '', (string) $d['latest']['version']),
            'package' => $url($d['latest']['package']),
            'notes'   => sanitize_textarea_field((string) ($d['latest']['notes'] ?? '')),
        );
    }
    return $cfg;
}

function z82_hub_refresh() {
    delete_transient('z82_hub_config');
    unset($GLOBALS['z82_hub_memo']);
    $cfg = z82_hub_fetch();
    if ($cfg) $GLOBALS['z82_hub_memo'] = $cfg;
    return $cfg;
}

// Feeds from the hub while connected (includes/feed.php → z82_feed_url)
function z82_hub_feed($which) {
    $cfg = z82_hub_config();
    if (empty($cfg['feeds'])) return null;
    return $which === 'live' ? ($cfg['feeds']['live'] ?? null) : $cfg['feeds']['fixtures'];
}

// Changing the hub settings takes effect right away
add_action('update_option_z82_hub_url', 'z82_hub_settings_changed');
add_action('update_option_z82_network_key', 'z82_hub_settings_changed');
add_action('add_option_z82_hub_url', 'z82_hub_settings_changed');
add_action('add_option_z82_network_key', 'z82_hub_settings_changed');
function z82_hub_settings_changed() {
    delete_transient('z82_hub_config');
    unset($GLOBALS['z82_hub_memo']);
    delete_option('z82_hub_last');
}

// ── Updates from the hub ─────────────────────────────────────
// Added straight into WordPress's list of available updates: WordPress's own Update URI
// mechanism only runs after a successful call to api.wordpress.org, which servers in China
// often can't make. The "Update URI" header keeps wordpress.org out of it.
function z82_hub_update_offer() {
    $cfg    = z82_hub_config();
    $latest = $cfg['latest'] ?? null;
    if (empty($latest['version']) || !version_compare($latest['version'], Z82_VERSION, '>')) return null;
    return (object) array(
        'id'           => 'https://zhibo-hub/' . Z82_HUB_SLUG,
        'slug'         => Z82_HUB_SLUG,
        'plugin'       => plugin_basename(Z82_PLUGIN_FILE),
        'new_version'  => $latest['version'],
        'url'          => z82_hub_url(),
        'package'      => $latest['package'],
        'tested'       => get_bloginfo('version'),
        'requires_php' => '7.4',
    );
}

add_filter('site_transient_update_plugins', function ($value) {
    $base  = plugin_basename(Z82_PLUGIN_FILE);
    $offer = z82_hub_update_offer();
    if (!$offer) return $value;
    if (!is_object($value)) $value = (object) array('last_checked' => time(), 'response' => array(), 'no_update' => array(), 'translations' => array(), 'checked' => array());
    $value->response[$base] = $offer;
    unset($value->no_update[$base]);
    return $value;
});

add_filter('auto_update_plugin', function ($update, $item) {
    if (isset($item->plugin) && $item->plugin === plugin_basename(Z82_PLUGIN_FILE) && z82_hub_connected()) {
        $cfg = z82_hub_config();
        return !empty($cfg['auto_update']);
    }
    return $update;
}, 10, 2);

// A newer version on the hub: have WordPress recheck soon instead of within 12 hours
add_action('init', function () {
    $offer = z82_hub_connected() ? z82_hub_update_offer() : null;
    if (!$offer || get_option('z82_hub_update_seen') === $offer->new_version) return;
    update_option('z82_hub_update_seen', $offer->new_version, false);
    wp_schedule_single_event(time() + 30, 'wp_update_plugins');
    $cfg = z82_hub_config();
    if (!empty($cfg['auto_update'])) wp_schedule_single_event(time() + 120, 'wp_maybe_auto_update');
});

// ── Settings page section ────────────────────────────────────
function z82_hub_admin_rows() {
    $last  = get_option('z82_hub_last');
    $ok    = !empty($last['at']) && (empty($last['error_at']) || $last['at'] >= $last['error_at']);
    ?>
    <tr>
        <th>Hub URL</th>
        <td><input type="url" name="z82_hub_url" value="<?php echo esc_attr(z82_hub_url()); ?>" placeholder="https://iss-railway-production.up.railway.app" style="width:520px" /></td>
    </tr>
    <tr>
        <th>Network key</th>
        <td><input type="text" name="z82_network_key" value="<?php echo esc_attr(get_option('z82_network_key', '')); ?>" autocomplete="off" style="width:520px" class="code" />
            <p class="description">Both are shown on the hub's “WordPress sites” page. Connected, this site checks in as a player site, reads the hub's feeds (the same ones every schedule site uses) and takes plugin updates from it. Empty = not connected.</p>
            <?php if (z82_hub_connected()): ?>
            <p><?php if ($ok): ?><span style="color:#008a20">✓ Connected</span> — last check-in <?php echo esc_html(human_time_diff($last['at'])); ?> ago<?php else: ?><span style="color:#b32d2e">Not reaching the hub</span><?php echo !empty($last['error']) ? ' — ' . esc_html($last['error']) : ''; ?><?php endif; ?></p>
            <?php endif; ?>
        </td>
    </tr>
    <?php
}

// ── REST: connecting from the hub ("Add a site") ─────────────
// The hub sends an administrator to WordPress's "Authorize Application" page, then uses the
// one-time Application Password it gets back to call /connect (and deletes it again).
// Same routes as the schedule plugin's zhibo/v1/*, under this plugin's own namespace.
add_action('rest_api_init', function () {
    $admin = function () { return current_user_can('manage_options'); };

    register_rest_route('zhibo82/v1', '/connect', array(
        'methods'             => 'POST',
        'permission_callback' => $admin,
        'callback'            => function (WP_REST_Request $req) {
            update_option('z82_hub_url', untrailingslashit(esc_url_raw(trim((string) $req->get_param('hub_url')))));
            update_option('z82_network_key', sanitize_text_field((string) $req->get_param('network_key')));
            $cfg = z82_hub_refresh();   // checks in
            if (!$cfg) {
                $last = get_option('z82_hub_last');
                return new WP_REST_Response(array('ok' => false, 'error' => $last['error'] ?? 'hub unreachable'), 502);
            }
            return new WP_REST_Response(array('ok' => true, 'home' => z82_public_home(), 'version' => Z82_VERSION), 200);
        },
    ));

    register_rest_route('zhibo82/v1', '/status', array(
        'methods'             => 'GET',
        'permission_callback' => $admin,
        'callback'            => function () {
            $last = get_option('z82_hub_last');
            return new WP_REST_Response(array(
                'version'   => Z82_VERSION,
                'connected' => z82_hub_connected(),
                'hub'       => z82_hub_url(),
                'last'      => is_array($last) ? array_intersect_key($last, array_flip(array('at', 'error', 'error_at'))) : null,
            ), 200);
        },
    ));

    // Hub → site: "ask me now". Changes nothing by itself; the site only acts on what its own hub returns.
    register_rest_route('zhibo82/v1', '/poke', array(
        'methods'             => 'POST',
        'permission_callback' => '__return_true',
        'callback'            => function (WP_REST_Request $req) {
            if (!z82_hub_connected()) return new WP_REST_Response(array('ok' => false, 'reason' => 'not connected'), 200);
            if (get_transient('z82_poked')) return new WP_REST_Response(array('ok' => true, 'throttled' => true), 200);
            set_transient('z82_poked', 1, 20);
            $cfg = z82_hub_refresh();
            $out = array('ok' => (bool) $cfg, 'version' => Z82_VERSION);
            // "Update now" from the hub: only ever the hub's own published version of this plugin
            if ($cfg && $req->get_param('update')) $out['updating'] = z82_queue_self_update();
            return new WP_REST_Response($out, 200);
        },
    ));
});

// ── Update now (hub: npm run hub -- update / release) ────────
// Installs the hub's newer version of this plugin in the background (WP-Cron), instead of
// waiting for WordPress's twice-daily update check. Returns the version being installed, or null.
function z82_queue_self_update() {
    $offer = z82_hub_update_offer();
    if (!$offer) return null;
    if (!wp_next_scheduled('z82_self_update')) wp_schedule_single_event(time(), 'z82_self_update');
    if (!wp_doing_cron()) spawn_cron();
    return $offer->new_version;
}

add_action('z82_self_update', function () {
    if (!z82_hub_update_offer()) return;
    require_once ABSPATH . 'wp-admin/includes/plugin.php';
    require_once ABSPATH . 'wp-admin/includes/file.php';
    require_once ABSPATH . 'wp-admin/includes/misc.php';
    require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
    $base     = plugin_basename(Z82_PLUGIN_FILE);
    $upgrader = new Plugin_Upgrader(new Automatic_Upgrader_Skin());
    $result   = $upgrader->upgrade($base);
    // In WP-Cron WordPress keeps the plugin active; make sure of it anyway
    if ($result === true && !is_plugin_active($base)) activate_plugin($base);
    // Check in on the next request, so the hub sees the new version right away
    delete_transient('z82_hub_config');
});
