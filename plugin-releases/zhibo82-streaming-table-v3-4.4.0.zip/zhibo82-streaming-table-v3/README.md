# Zhibo82 Streaming Table v3.0.0

Sports streaming WordPress plugin with ROW-BASED layout, expandable players, and locked app promotion.

## 🆕 Version 3.0.0 - MAJOR UPDATE

**COMPLETE REDESIGN** - Row layout instead of card grid!

### New Features

✅ **ROW-BASED LAYOUT** - List view like a table, not cards  
✅ **EXPAND/COLLAPSE** - Click row to expand player below  
✅ **URL ROUTING** - Deep linking support (#match-123)  
✅ **LOCKED PLAYER UI** - Beautiful app promo for non-YouTube streams  
✅ **IFRAME LIFECYCLE** - Stops playback when closing row  
✅ **MULTIPLE SOURCES** - Switch between sources with buttons  
✅ **LIVE INDICATORS** - Sport-specific timing + countdown  
✅ **VERSION COMPATIBLE** - Won't conflict with v2.x

## Key Differences from v2.x

| Feature | v2.x (Old) | v3.0 (New) |
|---------|------------|------------|
| Layout | Card grid (3 cols) | Row list (1 col) |
| Expansion | Inline below card | Below row header |
| URL | Static | Dynamic (#match-X) |
| App Promo | Simple gradient box | Locked player UI |
| Sources | Tabs inside card | Buttons above player |
| Close behavior | Hide div | Remove iframe |

## Installation

1. Upload `zhibo82-streaming-table` folder to `/wp-content/plugins/`
2. Activate plugin
3. Settings → Zhibo82 Streaming → Set app URL
4. Add shortcode: `[zhibo82_streaming]`

## Shortcode

```
[zhibo82_streaming]
[zhibo82_streaming type_filter="Football"]
[zhibo82_streaming show_type_filter="false"]
[zhibo82_debug]  // Debug mode
```

## Features

### 1. ROW Layout
- Each match is a clickable row
- Click to expand player below
- Only one row open at a time
- Smooth animations

### 2. URL Routing
- Opening match changes URL: `yoursite.com/page#match-5`
- Shareable links work (opens correct match)
- Browser back/forward supported
- URL clears when closing match

### 3. Locked Player (Non-YouTube)
Matches the screenshot design:
- Black background with gradient
- Lock icon 🔒
- "登录以观看直播"
- Features: "支持电视端 · 1080p · 无需信用卡"
- Orange "免费注册" button
- Google login button
- "已有账号？登录" link

### 4. YouTube Players
- Auto-load first source
- Switch sources with buttons
- Autoplay + minimal branding
- Stop playback when closing

### 5. Live Indicators
- Football: 100 minutes live window
- Basketball: 150 minutes
- Tennis: 180 minutes
- Shows countdown for upcoming matches

## Technical Details

- **Plugin Version**: 3.0.0
- **WordPress**: 5.0+
- **PHP**: 7.0+
- **Data Source**: Google Sheets CSV
- **CSS Variables**: Theme-friendly
- **JavaScript**: Vanilla JS (no jQuery dependency)

## CSS Variables

```css
--z82-primary: #f59e0b     /* Orange */
--z82-danger: #ef4444      /* Red for live */
--z82-success: #10b981     /* Green for upcoming */
--z82-bg: #000000         /* Black background */
--z82-surface: #1a1a1a    /* Row background */
--z82-border: #333333     /* Borders */
--z82-text: #ffffff       /* White text */
--z82-text-muted: #999999 /* Gray text */
```

## File Structure

```
zhibo82-streaming-table/
├── zhibo82-streaming-table.php  (Main plugin)
├── assets/
│   ├── style.css               (Row layout CSS)
│   ├── script.js               (Expand/collapse + routing)
│   └── index.php              (Security)
├── index.php                   (Security)
└── README.md                   (This file)
```

## Compatibility

- ✅ Won't conflict with v2.x (different CSS classes)
- ✅ Can run both versions simultaneously
- ✅ Different shortcode prefix (z82_ vs old sst_)
- ✅ Separate cache keys

## Support

For issues or questions:
- Check [zhibo82_debug] output
- Verify Google Sheets CSV URL
- Clear WordPress cache
- Check browser console for errors

## Changelog

### 3.0.0 (2024-05-06)
- MAJOR: Row-based layout (replacing card grid)
- NEW: URL routing with hash navigation
- NEW: Locked player UI for app streams
- NEW: Iframe lifecycle management
- IMPROVED: Expand/collapse animation
- IMPROVED: Mobile responsiveness
- FIXED: Multiple sources handling

### 2.0.0 (Previous)
- Card grid layout
- Basic expand/collapse
- Simple app promotion

## License

GPL v2 or later
