# 🚀 QUICKSTART GUIDE

## Version 3.0.0 - ROW Layout Edition

### 1️⃣ Upload Plugin

**WordPress Admin:**
1. Plugins → Add New → Upload Plugin
2. Choose `zhibo82-streaming-table-v3.zip`
3. Click "Install Now"
4. Click "Activate Plugin"

✅ Done!

### 2️⃣ Configure Settings

**Settings → Zhibo82 Streaming:**
- Cache Duration: `30` (minutes) or `0` to disable
- App Download URL: `https://yoursite.com/app`
- Click "Save Changes"

### 3️⃣ Add to Page

**Edit any page:**
1. Add shortcode: `[zhibo82_streaming]`
2. Save page
3. View page

**Result:** You'll see a list of match ROWS!

### 4️⃣ Test Functionality

**Click a row:**
- Row expands
- URL changes to `#match-123`
- YouTube player loads (if available)
- OR locked player shows (if app stream)

**Click row again:**
- Row collapses
- Player stops
- URL clears

**Multiple sources:**
- Buttons appear above player
- Click to switch between sources

### 5️⃣ Customize (Optional)

**Filter by sport:**
```
[zhibo82_streaming type_filter="Football"]
```

**Hide filters:**
```
[zhibo82_streaming show_type_filter="false"]
```

**Debug mode:**
```
[zhibo82_debug]
```

## 🎯 What to Expect

### YouTube Streams
1. Click row
2. Row expands
3. YouTube player loads with autoplay
4. Multiple sources? Buttons appear
5. Click other source → switches video

### App Streams (cdn.livetv882.com, etc.)
1. Click row
2. Row expands
3. **Locked player appears:**
   - 🔒 Lock icon
   - "登录以观看直播"
   - "支持电视端 · 1080p · 无需信用卡"
   - Orange "免费注册 →" button
   - "使用 Google 登录" button
   - "已有账号？登录" link

### Live Matches
- 🔴 Red "直播中" badge
- Left border turns red
- Shows "进行中" text

### Upcoming Matches
- 🟢 Green "即将开始" badge
- Shows countdown "2小时30分后"

### Finished Matches
- Gray "已结束" badge
- Row slightly faded

## 🐛 Troubleshooting

### No matches showing?
```
[zhibo82_debug]
```
Check if CSV columns are correct.

### Player not loading?
- Check browser console (F12)
- Verify YouTube URLs
- Clear cache

### Wrong data?
- Verify Google Sheets URL has `?gid=XXXXX`
- Should show "日期, 北京时间, 比赛..." columns
- NOT "Main name, Alternative 1..."

### URL not changing?
- Check if browser supports History API
- Try different browser
- Check for JavaScript errors

## 📱 Mobile Experience

- Rows stack vertically
- Expand icons clear
- Status badges move to top
- Player maintains 16:9 ratio
- Locked player scales properly

## 🔑 Keyboard Shortcuts

- `ESC` - Close open row

## 🎨 Styling Tips

Override CSS variables in your theme:
```css
.z82-wrapper {
    --z82-primary: #your-color;
    --z82-bg: #your-bg;
}
```

## ✅ Success Checklist

- [x] Plugin activated
- [x] Settings saved
- [x] Shortcode added to page
- [x] Rows visible on page
- [x] Click row → expands
- [x] URL changes
- [x] Player loads
- [x] Close row → player stops
- [x] Multiple sources work
- [x] Live indicators showing

## 🆘 Need Help?

1. Use `[zhibo82_debug]` first
2. Check browser console (F12)
3. Verify CSV structure
4. Clear WordPress cache
5. Try different browser

---

**You're all set!** 🎉

The plugin is working if you can:
1. See match rows
2. Click to expand
3. URL changes
4. Player appears
5. Close to stop
