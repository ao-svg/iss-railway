/**
 * Zhibo82 service worker — match reminder notifications.
 * Served from the site root via /?z82_sw=1 (see includes/push.php).
 */

self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', (event) => event.waitUntil(self.clients.claim()));

self.addEventListener('push', (event) => {
    let data = {};
    try { data = event.data ? event.data.json() : {}; } catch (e) {}

    const title = data.title || '比赛即将开始';
    event.waitUntil(Promise.all([
        self.registration.showNotification(title, {
            body: data.body || '',
            icon: data.icon || undefined,
            tag: data.tag || 'z82-reminder',
            renotify: true,
            requireInteraction: true,
            data: { url: data.url || self.registration.scope }
        }),
        // Let open pages know (they update the bell state)
        self.clients.matchAll({ type: 'window', includeUncontrolled: true })
            .then((list) => list.forEach((c) => c.postMessage({ type: 'z82_push', data: data })))
    ]));
});

self.addEventListener('notificationclick', (event) => {
    event.notification.close();
    const url = (event.notification.data && event.notification.data.url) || self.registration.scope;

    event.waitUntil(
        self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((list) => {
            // Reuse an open tab of the site: it switches to the match itself
            for (const client of list) {
                if (new URL(client.url).origin === new URL(url).origin && 'focus' in client) {
                    client.postMessage({ type: 'z82_open', url: url });
                    return client.focus();
                }
            }
            return self.clients.openWindow(url);
        })
    );
});
