# Changelog

## 4.4.0 (2026-10-28)
- YouTube rows: embedded from youtube-nocookie.com (YouTube’s privacy-enhanced player). On youtube.com a
  sign-in check YouTube asks some viewers for loops inside the frame when the browser blocks Google’s
  cookies there (“accounts.google.com redirected you too many times”).
- A video the visitor opened that YouTube won’t start here now shows “此视频无法在本页播放” with a
  “在 YouTube 观看” button instead of YouTube’s error page; every YouTube block also has a small
  “无法播放？在 YouTube 观看” link under the player.
- YouTube posters use the sharp 16:9 thumbnail (hq720, 1280×720) instead of the blurry 480×360 one,
  falling back to it when a video has none.
- Feed down (e.g. while iss-railway restarts and answers 404 until its first run): the table keeps
  showing the last good copy and retries every minute, instead of “暂无比赛数据”. Same as zhibo882.
- Update now from the hub: zhibo82/v1/poke accepts {"update": true}. When the hub has a newer
  published version of this plugin, the site installs it right away in the background (WP-Cron)
  instead of at WordPress's next update check, and checks in with the new version. It only ever
  installs the hub's own published release. Used by the hub's POST /api/hub/update and
  `npm run hub -- update | release` in iss-railway.

## 4.3.5 (2026-10-25)
- Can be connected from the hub (“Add a site” on the hub’s WordPress sites page): new REST routes
  zhibo82/v1/connect and zhibo82/v1/status (administrators only — the hub calls them with a one-time
  Application Password from WordPress’s “Authorize Application” page, then deletes it) and
  zhibo82/v1/poke (public; only makes the site ask its own hub now). Same as the schedule plugin’s zhibo/v1/*.

## 4.3.4 (2026-10-19)
- Rows labelled 今天 / 明天 also show the date itself (m月d日), small under the time.
- A small note above the table: 时间均为北京时间（UTC+8）. zhibo882-streaming-table 2.3.3 shows both the same way.

## 4.3.3 (2026-10-19)
- Matches with no playable source (none in the feed, all dead, or only a "soon" placeholder) are no
  longer listed at all — upcoming ones included (they used to show as 即将上线). A match appears once
  the feed has a source for it. zhibo882-streaming-table keeps listing them as 即将上线, so zhibo882
  can show matches zhibo82 doesn't; its links to those land on zhibo82's page without that row.

## 4.3.2 (2026-10-19)
- Sources the feed marks dead (sourceWorking false) get no button: the feed’s /go answers 502 for them, so they
  could never play. Unknown (null) sources stay. A match left with no source is shown like one whose sources
  aren’t in yet: upcoming → 即将上线, live → not listed, ended → dropped. zhibo882-streaming-table 2.3.2 counts
  sources the same way, so both list the same matches. (On 2026-10-19: 342 of 608 feed sources dead.)

## 4.3.1 (2026-10-19, not released — included in 4.3.2)
- Ended matches: only those that ended in the last 2 hours, at most the 20 most recent, newest first
  (was every ended match still in the feed, oldest first — 87 on 2026-10-18). Still 3 visible, the rest
  behind “显示全部”. zhibo882-streaming-table 2.3.1+ uses the same rule, so both sites list the same matches.
- Live matches the page marks as ended (YouTube check) go to the top of the ended group and no longer
  push it past 3 visible rows; the “显示全部 N” count follows.
- Hub check-ins report the site’s public address. zhibo82.com’s server runs WP-cron with home_url() =
  https://127.0.0.1, so a check-in from a background job would have listed the site as “127.0.0.1”.
  An IP or localhost is now replaced by the last public address seen (option z82_public_home).

## 4.3.0 (2026-10-18)
- Streams play through the feed's own link (`https://<feed>/go?u=<link>`) instead of the raw CDN link.
  The feed re-resolves the link when it's opened and sends most sources through its relay, which
  fixes geo-blocked and no-CORS sources (measured from outside the US: 19 of 30 "working" sources
  play through it, 13 raw). Sources the feed never relays (doms9) are redirected to the raw link.
- Player page (`?z82_stream=1`, hls.js): if the feed link fails before playing, it tries the raw
  link once, then shows the usual error. Retry starts over from the feed link.
- The raw link is still used for YouTube detection, cached screenshot/GIF keys and the "soon" check.
- The player page no longer decodes an already-plain `url` a second time (it broke `/go?u=` links).
