# Per-Source Gap Customization

## Current Setup
All non-YouTube, non-cdn.livetv882.me iframes hide the top **150px** by default.

## How to Customize Gap Per Source

### Method 1: CSS Custom Properties (Recommended)

Add to your theme's custom CSS:

```css
/* Hide 100px for tv-shihab.xyz */
.z82-iframe-wrapper:has(iframe[src*="tv-shihab"]) .z82-iframe-inner {
    margin-top: -100px !important;
    height: 900px !important; /* visible 800px + hidden 100px */
}

/* Hide 200px for freestreams */  
.z82-iframe-wrapper:has(iframe[src*="freestreams"]) .z82-iframe-inner {
    margin-top: -200px !important;
    height: 1000px !important; /* visible 800px + hidden 200px */
}

/* Hide 50px for freetv */
.z82-iframe-wrapper:has(iframe[src*="freetv"]) .z82-iframe-inner {
    margin-top: -50px !important;
    height: 850px !important; /* visible 800px + hidden 50px */
}
```

### Method 2: Edit Plugin CSS Directly

Edit `/assets/style.css` and modify:

```css
/* Around line 1093 */
.z82-iframe-inner {
    position: relative;
    width: 100%;
    height: 950px;           /* Change this: 800 + YOUR_GAP */
    margin-top: -150px;      /* Change this: -YOUR_GAP */
}
```

## Formula

```
margin-top: -GAP_SIZE
height: 800 + GAP_SIZE
```

Examples:
- 100px gap: `margin-top: -100px; height: 900px;`
- 200px gap: `margin-top: -200px; height: 1000px;`
- 300px gap: `margin-top: -300px; height: 1100px;`

## No Gap for Specific Source

```css
/* Show full iframe for specific source */
.z82-iframe-wrapper:has(iframe[src*="example.com"]) .z82-iframe-inner {
    margin-top: 0 !important;
    height: 800px !important;
}
```
