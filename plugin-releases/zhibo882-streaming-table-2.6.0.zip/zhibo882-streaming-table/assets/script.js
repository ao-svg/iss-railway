/**
 * Zhibo882 Streaming Table — zhibo82.com's table, where every match links to it on zhibo82.com.
 * Sport filter (sports with a page are plain links), ended toggle, keyword view, “加载更多”,
 * filter bar edge fades and countdowns.
 */
(function() {
    'use strict';

    function $(sel, root) { return (root || document).querySelector(sel); }
    function $$(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

    function activeSport(container) {
        const btn = $('.z82-filter-btn.active', container.closest('.z882-wrapper'));
        return btn ? (btn.getAttribute('data-sport') || '') : '';
    }

    function applySport(container, sport) {
        $$('.z82-match-row', container).forEach(row => {
            row.classList.toggle('z82-filter-hidden', !!sport && row.getAttribute('data-type') !== sport);
        });
    }

    // ---- SPORT FILTER (in place, for sports without their own page) ----
    window.z882FilterType = function(tableId, sport, callerBtn) {
        const container = document.getElementById(tableId);
        if (!container) return;
        const wrapper = container.closest('.z882-wrapper');

        $$('.z82-filter-btn', wrapper).forEach(b => {
            const on = callerBtn ? b === callerBtn : (b.getAttribute('data-sport') || '') === sport;
            b.classList.toggle('active', on);
            b.setAttribute('aria-selected', on ? 'true' : 'false');
        });
        applySport(container, sport);
        updateLoadMore(container);

        // #football etc. — shareable, and where other pages send sports without a page
        if (window.history.replaceState) {
            const btn = $('.z82-filter-btn.active', wrapper);
            const slug = sport && btn ? btn.getAttribute('data-slug') : '';
            window.history.replaceState(null, '', window.location.pathname + window.location.search + (slug ? '#' + slug : ''));
        }
    };

    function applyHash() {
        const slug = (window.location.hash || '').replace(/^#/, '');
        if (!slug) return;
        $$('.z882-wrapper').forEach(wrapper => {
            const btn = $('button.z82-filter-btn[data-slug="' + slug.replace(/[^a-z0-9-]/g, '') + '"]', wrapper);
            const container = $('.z82-table-container', wrapper);
            if (btn && container) window.z882FilterType(container.id, btn.getAttribute('data-sport'), btn);
        });
    }

    // ---- ENDED MATCHES ----
    window.z882ToggleEnded = function(toggle) {
        const container = toggle.closest('.z82-table-container');
        const expanded = toggle.getAttribute('aria-expanded') !== 'true';
        // Only rows the server rendered collapsed collapse again; the first three always show
        $$('.z82-match-row.finished', container).forEach(row => {
            if (row.hasAttribute('data-ended-collapsible') || row.classList.contains('z82-match-hidden')) {
                row.setAttribute('data-ended-collapsible', '1');
                row.classList.toggle('z82-match-hidden', !expanded);
            }
        });
        toggle.setAttribute('aria-expanded', expanded ? 'true' : 'false');
        const label = $('.z82-ended-info-label', toggle);
        if (label) label.textContent = label.getAttribute(expanded ? 'data-hide' : 'data-show');
    };

    // ---- KEYWORD VIEW ([zhibo882_streaming league_keywords="..."]) ----
    window.z882ResetKeywords = function(tableId) {
        const container = (tableId && document.getElementById(tableId)) || $('.z882-wrapper .z82-table-container');
        if (!container) return;
        const wrapper = container.closest('.z882-wrapper');
        wrapper.setAttribute('data-kw-cleared', '1');   // rows loaded later come unfiltered
        $$('.z82-kw-hidden', container).forEach(row => row.classList.remove('z82-kw-hidden'));
        const msg = document.getElementById('z882-kw-nomatch-' + container.id);
        if (msg) msg.remove();
        const bar = $('.z82-kw-reset-bar', wrapper);
        if (bar) bar.style.display = 'none';
        const filters = $('#z882-filter-container-hidden', wrapper);
        if (filters) { filters.hidden = false; initFilterScroll(wrapper); }
    };

    // ---- LOAD MORE (upcoming matches, paged like zhibo82.com) ----
    // The button shows what's left for the sport being viewed
    function updateLoadMore(container) {
        const btn = $('.z82-load-more', container);
        if (!btn) return;
        let remaining = {};
        try { remaining = JSON.parse(btn.getAttribute('data-remaining') || '{}'); } catch (e) {}
        const left = remaining[activeSport(container)] || 0;
        btn.hidden = left <= 0;
        $('.z82-load-more-count', btn).textContent = left > 0 ? '(' + left + ')' : '';
    }

    window.z882LoadMore = function(btn) {
        const container = btn.closest('.z82-table-container');
        const wrapper   = container.closest('.z882-wrapper');
        const section   = $('.z882-upcoming', container);
        const ajaxUrl   = window.z882Config && window.z882Config.ajaxUrl;
        if (!section || !ajaxUrl || btn.classList.contains('is-loading')) return;

        const page  = parseInt(wrapper.getAttribute('data-page'), 10) || 30;
        const sport = activeSport(container);
        let limits = {};
        try { limits = JSON.parse(wrapper.getAttribute('data-limits') || '{}'); } catch (e) {}
        if (sport) {
            limits[sport] = $$('.z82-match-row', section).filter(r => r.getAttribute('data-type') === sport).length + page;
        } else {
            limits[''] = Math.max(page, limits[''] || 0) + page;
        }

        const kwActive = wrapper.hasAttribute('data-keywords') && !wrapper.hasAttribute('data-kw-cleared');
        const body = new FormData();
        body.append('action', 'z882_more');
        body.append('atts', wrapper.getAttribute('data-atts') || '{}');
        body.append('limits', JSON.stringify(limits));
        body.append('kw', kwActive ? '1' : '0');

        btn.classList.add('is-loading');
        $('.z82-load-more-label', btn).textContent = '加载中…';
        fetch(ajaxUrl, { method: 'POST', body: body, credentials: 'same-origin' })
            .then(r => r.json())
            .then(res => {
                if (!res || !res.success) throw new Error('load failed');
                wrapper.setAttribute('data-limits', JSON.stringify(limits));
                section.innerHTML = res.data.html;
                applySport(section, sport);
                updateLoadMore(container);
                updateCountdowns();
            })
            .catch(() => {
                btn.classList.remove('is-loading');
                $('.z82-load-more-label', btn).textContent = '加载更多比赛';
            });
    };

    // ---- FILTER BAR EDGE FADES ----
    function initFilterScroll(root) {
        $$('.z82-filters-wrap', root).forEach(wrap => {
            const bar = $('.z82-filters', wrap);
            if (!bar || wrap.hasAttribute('data-scroll-init') || wrap.hidden) return;
            wrap.setAttribute('data-scroll-init', '1');
            const update = () => {
                const max = bar.scrollWidth - bar.clientWidth;
                wrap.classList.toggle('can-scroll-left', bar.scrollLeft > 2);
                wrap.classList.toggle('can-scroll-right', max - bar.scrollLeft > 2);
            };
            bar.addEventListener('scroll', update, { passive: true });
            window.addEventListener('resize', update);
            update();
            // Keep the current sport's button in view on sport pages
            const active = $('.z82-filter-btn.active', bar);
            if (active && active.offsetLeft + active.offsetWidth > bar.clientWidth) {
                bar.scrollLeft = active.offsetLeft - 16;
                update();
            }
        });
    }

    // ---- COUNTDOWNS (same format as the server: "2小时5分后" / "35分钟后") ----
    function updateCountdowns() {
        const now = Date.now() / 1000;
        $$('.z882-wrapper .z82-countdown[data-start]').forEach(el => {
            const mins = (Number(el.getAttribute('data-start')) - now) / 60;
            if (!(mins > 15)) { el.textContent = '即将开始'; return; }
            const h = Math.floor(mins / 60);
            const m = Math.floor(mins) % 60;
            el.textContent = h > 0 ? h + '小时' + m + '分后' : m + '分钟后';
        });
    }

    // ---- ROTATION (optional, set on the hub) ----
    // The page always links to the main destination (what search engines and page caches see);
    // at the moment of a click the link is pointed at one of the destinations, at random.
    function initRotation() {
        const list = (window.z882Config && window.z882Config.rotation) || [];
        if (list.length < 2) return;
        const retarget = e => {
            const a = e.target.closest && e.target.closest('.z882-wrapper a.z82-row-header, .z882-wrapper a.z882-yt-thumb');
            if (!a || !a.hash) return;
            a.href = list[Math.floor(Math.random() * list.length)] + '/' + a.hash;
        };
        // click, middle click, and right click → "open in new tab"
        ['click', 'auxclick', 'contextmenu'].forEach(type => document.addEventListener(type, retarget, true));
    }

    // ---- YOUTUBE (only where the visitor can reach it, as on zhibo82.com) ----
    // Same check as zhibo82.com: does youtube.com answer within 3.5 s? Remembered for 5 minutes.
    function checkYouTube() {
        try {
            const cached = JSON.parse(sessionStorage.getItem('z882-yt') || 'null');
            if (cached && Date.now() - cached.t < 5 * 60 * 1000) return Promise.resolve(cached.ok);
        } catch (e) {}
        return new Promise(resolve => {
            let done = false;
            const finish = ok => {
                if (done) return;
                done = true;
                clearTimeout(timer);
                try { sessionStorage.setItem('z882-yt', JSON.stringify({ ok: ok, t: Date.now() })); } catch (e) {}
                resolve(ok);
            };
            const timer = setTimeout(() => finish(false), 3500);
            const img = new Image();
            img.onload = () => finish(true);
            img.onerror = () => finish(false);
            img.src = 'https://www.youtube.com/favicon.ico?z882=' + Date.now();
        });
    }

    // Thumbnails are requested only after the check passes; a card shows once its own image
    // loads (YouTube answers a missing video with a 120×90 placeholder), the strip once any does.
    function showStrip(wrap) {
        $$('.z882-yt-thumb', wrap).forEach(card => {
            const img = $('img[data-src]', card);
            if (!img) return;
            img.onload = () => {
                if (img.naturalWidth <= 120) return;
                card.hidden = false;
                wrap.hidden = false;
            };
            img.src = img.getAttribute('data-src');
            img.removeAttribute('data-src');
        });
    }

    function initYouTube() {
        const strips = $$('[data-yt-strip]');
        const ytOnly = $$('.z882-yt-only');
        if (!strips.length && !ytOnly.length) return;
        checkYouTube().then(ok => {
            if (!ok) return;
            // Matches with only YouTube streams appear (CSS hides them until then)
            $$('.z882-wrapper').forEach(w => w.classList.add('z882-yt-ok'));
            strips.forEach(showStrip);
        });
    }

    // ---- LIGHT / DARK THAT MATCHES ANY THEME ----
    // With the Zhibo child theme (html[data-theme]) or a theme that says its mode (html.dark,
    // body.dark-mode / light-mode) table.css follows that. On any other theme the table would
    // follow the visitor's OS setting — a dark table on a light site. So read the colour actually
    // behind the table and match it; again whenever the theme or the OS switches modes.
    function backgroundBehind(el) {
        for (let n = el.parentElement; n; n = n.parentElement) {
            const m = /rgba?\(([\d.]+),\s*([\d.]+),\s*([\d.]+)(?:,\s*([\d.]+))?\)/.exec(getComputedStyle(n).backgroundColor);
            if (m && (m[4] === undefined || Number(m[4]) > 0.5)) return [Number(m[1]), Number(m[2]), Number(m[3])];
        }
        return [255, 255, 255];   // nothing painted: browsers show white
    }

    function luminance(rgb) {
        const [r, g, b] = rgb.map(v => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); });
        return 0.2126 * r + 0.7152 * g + 0.0722 * b;
    }

    function matchHostTheme() {
        const root = document.documentElement, body = document.body;
        const themeSaysMode = root.hasAttribute('data-theme') || root.classList.contains('dark')
            || (body && (body.classList.contains('dark-mode') || body.classList.contains('light-mode')));
        $$('.z882-wrapper').forEach(w => {
            if (themeSaysMode) {
                if (w.hasAttribute('data-z882-auto')) { w.removeAttribute('data-theme'); w.removeAttribute('data-z882-auto'); }
                return;
            }
            w.setAttribute('data-theme', luminance(backgroundBehind(w)) < 0.2 ? 'dark' : 'light');
            w.setAttribute('data-z882-auto', '1');
        });
    }

    function initThemeMatch() {
        matchHostTheme();
        let queued = false;
        const again = () => { if (queued) return; queued = true; requestAnimationFrame(() => { queued = false; matchHostTheme(); }); };
        if (window.matchMedia) {
            const mq = window.matchMedia('(prefers-color-scheme: dark)');
            if (mq.addEventListener) mq.addEventListener('change', again); else if (mq.addListener) mq.addListener(again);
        }
        if (window.MutationObserver) {
            const mo = new MutationObserver(again);
            mo.observe(document.documentElement, { attributes: true, attributeFilter: ['class', 'data-theme', 'style'] });
            if (document.body) mo.observe(document.body, { attributes: true, attributeFilter: ['class', 'style'] });
        }
    }

    function init() {
        initThemeMatch();
        initRotation();
        initYouTube();
        initFilterScroll(document);
        $$('.z882-wrapper .z82-table-container').forEach(updateLoadMore);
        applyHash();
        window.addEventListener('hashchange', applyHash);
        updateCountdowns();
        setInterval(updateCountdowns, 30000);
    }

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
    else init();
})();
