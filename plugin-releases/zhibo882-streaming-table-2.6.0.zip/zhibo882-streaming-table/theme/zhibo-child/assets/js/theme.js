/**
 * Zhibo882 Child — light/dark mode (same behaviour as zhibo82.com).
 */
(function () {
    'use strict';

    var cfg = window.zbTheme || {};
    var root = document.documentElement;
    var STORAGE_KEY = 'zb-theme';

    function $$(sel, ctx) { return Array.prototype.slice.call((ctx || document).querySelectorAll(sel)); }

    // ── Light / dark mode ───────────────────────────────────
    // The boot script in <head> already set html[data-theme]; this keeps it in sync.
    function storedMode() {
        try { return localStorage.getItem(STORAGE_KEY); } catch (e) { return null; }
    }

    function systemMode() {
        return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    }

    function applyMode(mode) {
        root.setAttribute('data-theme', mode);
        root.style.colorScheme = mode;
        $$('meta[name="theme-color"]').forEach(function (m) {
            m.removeAttribute('media');
            m.setAttribute('content', mode === 'dark' ? '#0b0c0f' : '#ffffff');
        });
        $$('[data-zb-mode-toggle]').forEach(function (btn) {
            btn.setAttribute('aria-pressed', mode === 'dark' ? 'true' : 'false');
        });
    }

    function initMode() {
        applyMode(root.getAttribute('data-theme') === 'dark' ? 'dark' : 'light');

        document.addEventListener('click', function (e) {
            var btn = e.target.closest('[data-zb-mode-toggle]');
            if (!btn) return;
            var next = root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
            applyMode(next);
            try { localStorage.setItem(STORAGE_KEY, next); } catch (err) {}
        });

        // Follow the OS while the visitor hasn't picked a mode and the site default is "auto"
        if (window.matchMedia) {
            var mq = window.matchMedia('(prefers-color-scheme: dark)');
            var onChange = function () {
                var s = storedMode();
                if (s !== 'light' && s !== 'dark' && (cfg.defaultMode || 'auto') === 'auto') applyMode(systemMode());
            };
            if (mq.addEventListener) mq.addEventListener('change', onChange);
            else if (mq.addListener) mq.addListener(onChange);
        }
    }

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initMode);
    else initMode();
})();
