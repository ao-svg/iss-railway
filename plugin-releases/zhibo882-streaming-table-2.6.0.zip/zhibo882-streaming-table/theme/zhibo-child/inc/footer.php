<?php
/**
 * Site footer — replaces GeneratePress's copyright bar.
 * GP footer widgets (Customize → Layout → Footer) still render above it if enabled.
 */

if (!defined('ABSPATH')) exit;

add_action('after_setup_theme', function () {
    register_nav_menus(['zb-footer' => '页脚菜单']);
});

add_action('after_setup_theme', function () {
    remove_action('generate_footer', 'generate_construct_footer');
}, 20);

// Sport links go to the sport pages set up by the plugin; a sport without one goes to the front page
function zb_footer_sports() {
    return [
        'Football'          => '足球直播',
        'Basketball'        => '篮球直播',
        'Tennis'            => '网球直播',
        'American Football' => '美式橄榄球',
        'Ice Hockey'        => '冰球直播',
        'Cricket'           => '板球直播',
    ];
}

function zb_sport_url($type) {
    $page = function_exists('z882_sport_page') ? z882_sport_page($type) : null;
    return $page ? get_permalink($page) : home_url('/');
}

add_action('generate_footer', function () {
    $home      = home_url('/');
    $about     = zb_option('footer_about');
    $legal     = array_filter(array_map('trim', explode("\n", (string) zb_option('footer_legal'))));
    $copyright = str_replace(array('{year}', '{domain}'), array(date_i18n('Y'), wp_parse_url(home_url(), PHP_URL_HOST)), (string) zb_option('footer_copyright'));
    ?>
    <footer class="zb-footer" aria-label="网站页脚" itemtype="https://schema.org/WPFooter" itemscope>
        <div class="zb-footer-inner grid-container">
            <div class="zb-footer-grid">
                <div class="zb-footer-brand">
                    <a class="zb-brand-link" href="<?php echo esc_url($home); ?>" aria-label="<?php echo esc_attr(zb_brand_name()); ?> 首页">
                        <img class="zb-brand-mark" src="<?php echo esc_url(zb_brand_mark()); ?>" width="36" height="36" alt="" loading="lazy">
                        <span class="zb-brand-name"><?php echo esc_html(zb_brand_name()); ?></span>
                    </a>
                    <?php if ($about): ?>
                    <p class="zb-footer-about"><?php echo esc_html($about); ?></p>
                    <?php endif; ?>
                    <ul class="zb-footer-badges">
                        <li><?php echo zb_icon('bolt'); ?>实时更新</li>
                        <li><?php echo zb_icon('tv'); ?>多源直播</li>
                        <li><?php echo zb_icon('shield'); ?>免费观看</li>
                    </ul>
                </div>

                <nav class="zb-footer-col" aria-label="热门直播">
                    <h2 class="zb-footer-title">热门直播</h2>
                    <ul>
                        <?php foreach (zb_footer_sports() as $type => $label): ?>
                        <li><a href="<?php echo esc_url(zb_sport_url($type)); ?>"><?php echo esc_html($label); ?></a></li>
                        <?php endforeach; ?>
                    </ul>
                </nav>

                <nav class="zb-footer-col" aria-label="账户">
                    <h2 class="zb-footer-title">账户</h2>
                    <ul>
                        <?php // Accounts live on zhibo82.com ?>
                        <li><a href="<?php echo esc_url(zb_auth_page_url('login')); ?>" rel="nofollow">登录</a></li>
                        <li><a href="<?php echo esc_url(zb_auth_page_url('register')); ?>" rel="nofollow">免费注册</a></li>
                        <li><a href="<?php echo esc_url(zb_player_site() . '/wp-login.php?action=lostpassword'); ?>" rel="nofollow">忘记密码</a></li>
                    </ul>
                </nav>

                <nav class="zb-footer-col" aria-label="关于">
                    <h2 class="zb-footer-title">关于</h2>
                    <?php if (has_nav_menu('zb-footer')): ?>
                        <?php wp_nav_menu(['theme_location' => 'zb-footer', 'container' => false, 'depth' => 1, 'fallback_cb' => false]); ?>
                    <?php else: ?>
                    <ul>
                        <li><a href="<?php echo esc_url($home); ?>">直播首页</a></li>
                        <?php if (get_privacy_policy_url()): ?>
                        <li><a href="<?php echo esc_url(get_privacy_policy_url()); ?>">隐私政策</a></li>
                        <?php endif; ?>
                    </ul>
                    <?php endif; ?>
                </nav>
            </div>

            <?php $newsletter = zb_newsletter_form(); if ($newsletter): ?>
            <section class="zb-footer-newsletter" aria-label="<?php echo esc_attr(zb_option('newsletter_title')); ?>">
                <div class="zb-footer-newsletter-copy">
                    <h2 class="zb-footer-title"><?php echo zb_icon('mail'); ?> <?php echo esc_html(zb_option('newsletter_title')); ?></h2>
                    <p><?php echo esc_html(zb_option('newsletter_text')); ?></p>
                </div>
                <div class="zb-newsletter"><?php echo $newsletter; ?></div>
            </section>
            <?php endif; ?>

            <div class="zb-footer-bottom">
                <?php if ($legal): ?>
                <div class="zb-footer-legal">
                    <?php foreach ($legal as $line): ?>
                    <p><?php echo esc_html($line); ?></p>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
                <?php if ($copyright): ?>
                <p class="zb-footer-copy"><?php echo esc_html($copyright); ?></p>
                <?php endif; ?>
            </div>
        </div>
    </footer>
    <?php
});
