<?php
/**
 * Header: brand, theme toggle and sign-in buttons.
 * Everything hooks into GeneratePress — header.php is not overridden.
 */

if (!defined('ABSPATH')) exit;

// Brand = app icon + live-text wordmark, so it recolours with the theme
add_filter('generate_site_title_output', function () {
    return sprintf(
        '<p class="main-title zb-brand"><a href="%1$s" rel="home" aria-label="%2$s 首页">' .
        '<img class="zb-brand-mark" src="%3$s" width="40" height="40" alt="">' .
        '<span class="zb-brand-name">%2$s</span></a></p>',
        esc_url(home_url('/')),
        esc_html(zb_brand_name()),
        esc_url(zb_brand_mark())
    );
});

add_filter('generate_site_description_output', '__return_empty_string');
add_filter('generate_logo_output', '__return_empty_string');

// GP only prints the title when "Hide site title" is off — force it on for our brand
add_filter('option_generate_settings', function ($settings) {
    if (is_array($settings)) $settings['hide_title'] = '';
    return $settings;
});

// Accounts live on zhibo82.com — sign-in and register go there
function zb_auth_page_url($tab = 'login') {
    $url = zb_player_site() . '/login/';
    return $tab === 'register' ? add_query_arg('tab', 'register', $url) : $url;
}

add_action('generate_menu_bar_items', function () {
    ?>
    <button type="button" class="zb-mode-toggle" data-zb-mode-toggle aria-label="切换深色 / 浅色模式" title="切换深色 / 浅色模式">
        <?php echo zb_icon('sun', 'zb-mode-sun'); ?>
        <?php echo zb_icon('moon', 'zb-mode-moon'); ?>
    </button>
    <?php
    if (!zb_option('show_auth')) return;
    ?>
    <a class="zb-btn zb-btn-ghost zb-hide-mobile" href="<?php echo esc_url(zb_auth_page_url('login')); ?>" rel="nofollow">登录</a>
    <a class="zb-btn zb-btn-primary zb-hide-mobile" href="<?php echo esc_url(zb_auth_page_url('register')); ?>" rel="nofollow">免费注册</a>
    <a class="zb-icon-btn zb-show-mobile" href="<?php echo esc_url(zb_auth_page_url('register')); ?>" rel="nofollow" aria-label="注册 / 登录"><?php echo zb_icon('user'); ?></a>
    <?php
});
