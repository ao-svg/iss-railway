<?php
/**
 * Appearance → Customize → 站点外观
 */

if (!defined('ABSPATH')) exit;

function zb_defaults() {
    return [
        'default_mode'     => 'auto',
        'show_auth'        => true,   // buttons go to zhibo82.com
        'newsletter_title' => '订阅赛事资讯',
        'newsletter_text'  => '重要比赛开播提醒与最新直播资讯，直接发送到你的邮箱。',
        'footer_about'     => '免费在线体育直播，涵盖足球、篮球、网球、美式橄榄球、拳击、自行车赛、棒球等多项赛事，随时随地观看精彩直播。',
        'footer_legal'     => '',
        'footer_copyright' => '©{year} {domain} 版权所有',
    ];
}

function zb_option($key) {
    $defaults = zb_defaults();
    return get_theme_mod('zb_' . $key, $defaults[$key] ?? '');
}

add_action('customize_register', function (WP_Customize_Manager $wp_customize) {
    $d = zb_defaults();

    $wp_customize->add_section('zb_options', [
        'title'    => '站点外观',
        'priority' => 25,
    ]);

    $wp_customize->add_setting('zb_default_mode', [
        'default'           => $d['default_mode'],
        'sanitize_callback' => function ($v) { return in_array($v, ['auto', 'light', 'dark'], true) ? $v : 'auto'; },
    ]);
    $wp_customize->add_control('zb_default_mode', [
        'section'     => 'zb_options',
        'label'       => '默认主题模式',
        'description' => '访客未手动切换时使用。“跟随系统”会按设备的深色/浅色设置显示。',
        'type'        => 'radio',
        'choices'     => ['auto' => '跟随系统', 'light' => '浅色', 'dark' => '深色'],
    ]);

    $wp_customize->add_setting('zb_show_auth', [
        'default'           => $d['show_auth'],
        'sanitize_callback' => function ($v) { return (bool) $v; },
    ]);
    $wp_customize->add_control('zb_show_auth', [
        'section' => 'zb_options',
        'label'   => '在页头显示登录 / 注册按钮（前往 zhibo82.com）',
        'type'    => 'checkbox',
    ]);

    $wp_customize->add_setting('zb_newsletter_title', [
        'default'           => $d['newsletter_title'],
        'sanitize_callback' => 'sanitize_text_field',
    ]);
    $wp_customize->add_control('zb_newsletter_title', [
        'section'     => 'zb_options',
        'label'       => '订阅区标题',
        'description' => '页脚及注册成功后显示 [email_collector] 订阅表单（需已安装该短代码）。',
        'type'        => 'text',
    ]);

    $wp_customize->add_setting('zb_newsletter_text', [
        'default'           => $d['newsletter_text'],
        'sanitize_callback' => 'sanitize_text_field',
    ]);
    $wp_customize->add_control('zb_newsletter_text', [
        'section' => 'zb_options',
        'label'   => '订阅区说明',
        'type'    => 'text',
    ]);

    $wp_customize->add_setting('zb_footer_about', [
        'default'           => $d['footer_about'],
        'sanitize_callback' => 'sanitize_textarea_field',
    ]);
    $wp_customize->add_control('zb_footer_about', [
        'section' => 'zb_options',
        'label'   => '页脚简介',
        'type'    => 'textarea',
    ]);

    $wp_customize->add_setting('zb_footer_legal', [
        'default'           => $d['footer_legal'],
        'sanitize_callback' => 'sanitize_textarea_field',
    ]);
    $wp_customize->add_control('zb_footer_legal', [
        'section'     => 'zb_options',
        'label'       => '页脚备案 / 许可信息',
        'description' => '每行显示为一行。留空则不显示。',
        'type'        => 'textarea',
    ]);

    $wp_customize->add_setting('zb_footer_copyright', [
        'default'           => $d['footer_copyright'],
        'sanitize_callback' => 'sanitize_text_field',
    ]);
    $wp_customize->add_control('zb_footer_copyright', [
        'section'     => 'zb_options',
        'label'       => '版权文字',
        'description' => '{year} 会替换为当前年份。',
        'type'        => 'text',
    ]);
});
