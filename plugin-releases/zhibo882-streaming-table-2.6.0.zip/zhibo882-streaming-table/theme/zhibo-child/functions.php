<?php
/**
 * Zhibo Streaming Child — GeneratePress child theme with the zhibo82.com look.
 * Installed and kept up to date by the Zhibo Streaming Table plugin (theme/zhibo-child).
 *
 * inc/customizer.php  Appearance → Customize → 站点外观 options
 * inc/header.php      logo, theme toggle, sign-in buttons (to zhibo82.com) in the GP menu bar
 * inc/footer.php      site footer (replaces GP's copyright bar)
 */

if (!defined('ABSPATH')) exit;

define('ZB_CHILD_VERSION', '1.0.0');
define('ZB_CHILD_DIR', get_stylesheet_directory());
define('ZB_CHILD_URI', get_stylesheet_directory_uri());

// Where watching, signing in and registering happen
define('ZB_PLAYER_SITE', 'https://zhibo82.com');

require ZB_CHILD_DIR . '/inc/icons.php';
require ZB_CHILD_DIR . '/inc/customizer.php';
require ZB_CHILD_DIR . '/inc/header.php';
require ZB_CHILD_DIR . '/inc/footer.php';

function zb_player_site() {
    return function_exists('z882_player_site') ? z882_player_site() : ZB_PLAYER_SITE;
}

// Brand shown in the header/footer: set in the plugin's setup wizard, else the site title
function zb_brand_name() {
    $name = (string) get_option('z882_brand', '');
    return $name !== '' ? $name : get_bloginfo('name');
}

// Brand mark: the Site Icon when one is set (Customize → Site Identity), else the bundled mark
function zb_brand_mark($size = 192) {
    return has_site_icon() ? get_site_icon_url($size) : ZB_CHILD_URI . '/assets/img/mark-192x192.webp';
}

// [email_collector] comes from a separate plugin; render it only where it exists
function zb_newsletter_form() {
    return shortcode_exists('email_collector') ? do_shortcode('[email_collector]') : '';
}

// ── Assets ───────────────────────────────────────────────────
add_action('wp_enqueue_scripts', function () {
    $css = ZB_CHILD_DIR . '/assets/css/theme.css';
    $js  = ZB_CHILD_DIR . '/assets/js/theme.js';

    wp_enqueue_style('zb-theme', ZB_CHILD_URI . '/assets/css/theme.css', ['generate-style'], filemtime($css));
    wp_enqueue_script('zb-theme', ZB_CHILD_URI . '/assets/js/theme.js', [], filemtime($js), true);
    wp_localize_script('zb-theme', 'zbTheme', [
        'defaultMode' => zb_option('default_mode'),
    ]);
}, 20);

// ── Light/dark mode ──────────────────────────────────────────
// Runs before any stylesheet so the page never flashes the wrong theme.
// Sets html[data-theme] — the streaming table reads the same attribute.
add_action('wp_head', function () {
    $default = zb_option('default_mode');
    ?>
<script id="zb-theme-boot">
(function(){var d=document.documentElement,m=null;try{m=localStorage.getItem('zb-theme')}catch(e){}
if(m!=='light'&&m!=='dark'){m=<?php echo wp_json_encode($default); ?>;}
if(m!=='light'&&m!=='dark'){m=window.matchMedia&&window.matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light';}
d.setAttribute('data-theme',m);d.style.colorScheme=m;})();
</script>
<meta name="theme-color" content="#ffffff" media="(prefers-color-scheme: light)">
<meta name="theme-color" content="#0b0c0f" media="(prefers-color-scheme: dark)">
    <?php
}, 0);

// Browser tab / home-screen icon when no Site Icon is set in the Customizer
add_action('wp_head', function () {
    if (has_site_icon()) return;
    $img = ZB_CHILD_URI . '/assets/img/';
    echo '<link rel="icon" href="' . esc_url($img . 'mark-32x32.webp') . '" sizes="32x32">' . "\n";
    echo '<link rel="icon" href="' . esc_url($img . 'mark-192x192.webp') . '" sizes="192x192">' . "\n";
    echo '<link rel="apple-touch-icon" href="' . esc_url($img . 'mark-180x180.webp') . '">' . "\n";
}, 5);

// ── Layout ───────────────────────────────────────────────────
// Same GeneratePress layout as zhibo82.com on a fresh install (saved Customizer values still win)
add_filter('generate_option_defaults', function ($defaults) {
    return array_merge($defaults, [
        'container_width'       => 1280,
        'layout_setting'        => 'no-sidebar',
        'blog_layout_setting'   => 'no-sidebar',
        'single_layout_setting' => 'no-sidebar',
        'nav_position_setting'  => 'nav-float-right',
        'back_to_top'           => 'enable',
        'hide_tagline'          => '1',
    ]);
});

// Front page hosts the streaming table: no page title. Sport pages keep theirs (it's the H1).
add_filter('generate_show_title', function ($show) {
    return is_front_page() ? false : $show;
});

// Pages with the streaming table are full width, like zhibo82.com
add_filter('generate_sidebar_layout', function ($layout) {
    if (is_front_page()) return 'no-sidebar';
    $post = get_queried_object();
    if (is_page() && $post instanceof WP_Post && has_shortcode($post->post_content, 'zhibo882_streaming')) return 'no-sidebar';
    return $layout;
});

add_filter('body_class', function ($classes) {
    $classes[] = 'zb-site';
    return $classes;
});
