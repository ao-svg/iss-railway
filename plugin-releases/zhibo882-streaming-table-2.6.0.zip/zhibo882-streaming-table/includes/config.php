<?php
/**
 * Where settings come from.
 *
 * Network mode: the hub (the iss-railway service, “WordPress sites” page) decides the destination site, feeds, paging and updates for
 * every domain. Each site asks it every few minutes (and checks in while doing so); the last good
 * answer is kept, so a hub outage changes nothing on the sites.
 * Standalone mode: the same settings, kept on this site.
 */

if (!defined('ABSPATH')) exit;

const Z882_REMOTE_TTL = 5 * MINUTE_IN_SECONDS;

function z882_mode() {
    return get_option('z882_mode', 'standalone') === 'network' ? 'network' : 'standalone';
}

function z882_hub_url() {
    return untrailingslashit((string) get_option('z882_hub_url', ''));
}

function z882_defaults() {
    return array(
        'player_site' => Z882_PLAYER_SITE,
        'feeds'       => array('fixtures' => Z882_DEFAULT_FEED_FIXTURES, 'live' => Z882_DEFAULT_FEED_LIVE),
        'page_size'   => 30,
        'cache'       => 5,
        'auto_update' => true,
        'rotation'    => array(),   // optional: each click opens one of these at random (player_site among them)
        'latest'      => null,
    );
}

// Effective settings for this site
// Remembered for the rest of the request in $GLOBALS['z882_cfg_memo']; z882_refresh_config() resets it
function z882_config() {
    if (isset($GLOBALS['z882_cfg_memo'])) return $GLOBALS['z882_cfg_memo'];
    $cfg = &$GLOBALS['z882_cfg_memo'];

    $cfg = z882_defaults();
    if (z882_mode() === 'network') {
        $remote = z882_remote_config();
        if ($remote) $cfg = array_merge($cfg, $remote);
    } else {
        $cfg['player_site'] = get_option('z882_player_site', '') ?: $cfg['player_site'];
        $cfg['feeds']       = array(
            'fixtures' => get_option('z882_feed_fixtures', '') ?: $cfg['feeds']['fixtures'],
            'live'     => get_option('z882_feed_live', '') ?: $cfg['feeds']['live'],
        );
        $cfg['page_size'] = (int) get_option('z882_upcoming_page', 30);
        $cfg['cache']     = (int) get_option('z882_cache_duration', 5);
        $extra = array_filter(array_map('esc_url_raw', preg_split('/[\r\n,]+/', (string) get_option('z882_rotation', ''))));
        if ($extra) {
            $player = untrailingslashit($cfg['player_site']);
            $cfg['rotation'] = array_values(array_unique(array_merge(array($player), array_map('untrailingslashit', $extra))));
            if (count($cfg['rotation']) < 2) $cfg['rotation'] = array();
        }
    }
    $cfg['player_site'] = untrailingslashit($cfg['player_site']);
    return $cfg;
}

function z882_cfg($key) {
    $cfg = z882_config();
    return $cfg[$key] ?? null;
}

function z882_player_site() {
    return z882_cfg('player_site');
}

function z882_feed_url($which) {
    $feeds = z882_cfg('feeds');
    return $which === 'live' ? $feeds['live'] : $feeds['fixtures'];
}

function z882_upcoming_page_size() {
    return absint(z882_cfg('page_size'));
}

// ── Talking to the hub ───────────────────────────────────────
// Cached answer; refreshed when stale. Falls back to the last good answer.
function z882_remote_config() {
    $cached = get_transient('z882_remote_config');
    if (is_array($cached)) return $cached;
    $fresh = z882_fetch_remote_config();
    if ($fresh) return $fresh;
    // Hub unreachable: keep the last good settings, try again in a minute
    $last = get_option('z882_remote_last');
    if (is_array($last) && !empty($last['config'])) {
        set_transient('z882_remote_config', $last['config'], MINUTE_IN_SECONDS);
        return $last['config'];
    }
    return null;
}

// This site's public address, as the hub should list it. Some hosts run WP-cron with home_url()
// = https://127.0.0.1 (seen on zhibo82.com's server), so a check-in from a background job would
// register "127.0.0.1": an IP or localhost is replaced by the last public address seen.
function z882_public_home() {
    $public = function ($host) {
        return $host && strpos($host, '.') !== false && $host !== 'localhost' && !filter_var($host, FILTER_VALIDATE_IP);
    };
    $home = home_url('/');
    $host = strtolower((string) wp_parse_url($home, PHP_URL_HOST));
    if (!$public($host)) {
        // A visitor's request knows the real name even when home_url() doesn't
        $req = strtolower(preg_replace('/:\d+$/', '', (string) ($_SERVER['HTTP_HOST'] ?? '')));
        if (wp_doing_cron() || !$public($req)) return (string) get_option('z882_public_home', '') ?: $home;
        $home = (wp_parse_url($home, PHP_URL_SCHEME) ?: 'https') . '://' . $req . '/';
    }
    if (get_option('z882_public_home') !== $home) update_option('z882_public_home', $home, false);
    return $home;
}

// Ask the hub now. Returns the validated settings, or null (error kept in z882_remote_last).
function z882_fetch_remote_config() {
    $hub = z882_hub_url();
    $key = (string) get_option('z882_network_key', '');
    $last = get_option('z882_remote_last');
    $last = is_array($last) ? $last : array();
    if (!$hub || !$key) return null;

    $theme = wp_get_theme();
    $home  = z882_public_home();
    $url = add_query_arg(array(
        'site'   => rawurlencode(wp_parse_url($home, PHP_URL_HOST)),
        'home'   => rawurlencode($home),
        'v'      => Z882_VERSION,
        'wp'     => rawurlencode(get_bloginfo('version')),
        'php'    => PHP_VERSION,
        'theme'  => rawurlencode($theme->get_stylesheet()),
        'pages'  => count((array) get_option('z882_pages', array())),
        // Sport pages this site has: what the hub's "Write page content" writes for
        'sports' => rawurlencode(implode(',', array_keys(array_filter((array) get_option('z882_pages', array()), function ($id, $type) { return (bool) z882_sport_page($type); }, ARRAY_FILTER_USE_BOTH)))),
        'bridge' => rawurlencode(z882_bridge_version()),
        'upd'    => rawurlencode(function_exists('z882_update_status') ? z882_update_status() : ''),
    ), $hub . '/api/hub/config');

    $res  = wp_remote_get($url, array('timeout' => 6, 'headers' => array('X-Zhibo-Key' => $key)));
    $code = is_wp_error($res) ? 0 : wp_remote_retrieve_response_code($res);
    $data = $code === 200 ? json_decode(wp_remote_retrieve_body($res), true) : null;
    $cfg  = is_array($data) ? z882_sanitize_remote($data) : null;

    if (!$cfg) {
        $last['error'] = is_wp_error($res) ? $res->get_error_message() : ($code === 401 ? 'Wrong network key' : 'Hub answered HTTP ' . $code);
        $last['error_at'] = time();
        update_option('z882_remote_last', $last, false);
        return null;
    }

    update_option('z882_remote_last', array('config' => $cfg, 'at' => time()), false);
    // Commands the hub queued for this site (setup / uninstall) — run in the background, see remote.php
    if (!empty($data['commands']) && function_exists('z882_queue_commands')) z882_queue_commands($data['commands']);
    set_transient('z882_remote_config', $cfg, Z882_REMOTE_TTL);
    return $cfg;
}

// Only known keys, only http(s) URLs
function z882_sanitize_remote($d) {
    $url = function ($u) { $u = esc_url_raw((string) $u, array('http', 'https')); return $u ?: null; };
    $player = $url($d['player_site'] ?? '');
    if (!$player) return null;

    $cfg = array('player_site' => $player);
    if (!empty($d['feeds']['fixtures']) && $url($d['feeds']['fixtures'])) {
        $cfg['feeds'] = array(
            'fixtures' => $url($d['feeds']['fixtures']),
            'live'     => $url($d['feeds']['live'] ?? '') ?: Z882_DEFAULT_FEED_LIVE,
        );
    }
    if (isset($d['page_size']))   $cfg['page_size']   = min(500, absint($d['page_size']));
    if (isset($d['cache']))       $cfg['cache']       = min(60, absint($d['cache']));
    if (isset($d['auto_update'])) $cfg['auto_update'] = (bool) $d['auto_update'];
    $cfg['rotation'] = array();
    if (!empty($d['rotation']) && is_array($d['rotation'])) {
        $cfg['rotation'] = array_values(array_unique(array_filter(array_map($url, array_slice($d['rotation'], 0, 20)))));
        if (count($cfg['rotation']) < 2) $cfg['rotation'] = array();
    }
    if (!empty($d['latest']['version']) && !empty($d['latest']['package'])) {
        $cfg['latest'] = array(
            'version' => preg_replace('/[^0-9a-zA-Z.\-]/', '', (string) $d['latest']['version']),
            'package' => $url($d['latest']['package']),
            'notes'   => sanitize_textarea_field((string) ($d['latest']['notes'] ?? '')),
        );
    }
    return $cfg;
}

// Hub changes reach the site within Z882_REMOTE_TTL; this makes it immediate (wizard / settings)
function z882_refresh_config() {
    delete_transient('z882_remote_config');
    unset($GLOBALS['z882_cfg_memo']);
    return z882_fetch_remote_config();
}
