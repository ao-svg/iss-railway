<?php
/**
 * The site look: GeneratePress (from wordpress.org) + the bundled child theme (theme/zhibo-child).
 * The child theme ships inside the plugin, so every plugin update also updates it on every site.
 */

if (!defined('ABSPATH')) exit;

const Z882_CHILD = 'zhibo-child';

function z882_theme_status() {
    $parent = wp_get_theme('generatepress');
    $child  = wp_get_theme(Z882_CHILD);
    return array(
        'parent' => $parent->exists(),
        'child'  => $child->exists(),
        'active' => get_stylesheet() === Z882_CHILD,
    );
}

function z882_copy_dir($from, $to) {
    if (!wp_mkdir_p($to)) return false;
    foreach (new RecursiveIteratorIterator(new RecursiveDirectoryIterator($from, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::SELF_FIRST) as $item) {
        $target = $to . '/' . substr($item->getPathname(), strlen($from) + 1);
        if ($item->isDir()) { if (!wp_mkdir_p($target)) return false; }
        elseif (!copy($item->getPathname(), $target)) return false;
    }
    return true;
}

// Copy the bundled child theme into wp-content/themes (replaces the previous copy)
function z882_sync_child_theme() {
    $ok = z882_copy_dir(Z882_DIR . 'theme/' . Z882_CHILD, get_theme_root() . '/' . Z882_CHILD);
    if ($ok) update_option('z882_child_synced', Z882_VERSION, false);
    return $ok;
}

// After a plugin update the bundled theme may be newer than the installed copy
add_action('admin_init', 'z882_maybe_sync_child_theme');
function z882_maybe_sync_child_theme() {
    if (get_option('z882_child_synced') === Z882_VERSION) return;
    if (wp_get_theme(Z882_CHILD)->exists()) z882_sync_child_theme();
}

// Background auto-updates don't load admin_init: sync on the next request after an update
add_action('upgrader_process_complete', function ($upgrader, $extra) {
    if (($extra['type'] ?? '') === 'plugin' && in_array(Z882_BASENAME, (array) ($extra['plugins'] ?? array()), true)) {
        delete_option('z882_child_synced');
    }
}, 10, 2);
add_action('init', function () {
    if (!is_admin() && get_option('z882_child_synced') !== Z882_VERSION && wp_get_theme(Z882_CHILD)->exists()) {
        z882_sync_child_theme();
    }
});

// Install GeneratePress if missing, put the child theme in place, give GP zhibo82.com's settings
// (only when it has none yet) and switch to the child theme. Returns an error string or ''.
// $checkCaps = false for hub commands, which run in the background without a logged-in user
function z882_install_theme($checkCaps = true) {
    if ($checkCaps && (!current_user_can('install_themes') || !current_user_can('switch_themes'))) return 'You need permission to install and switch themes.';

    if (get_stylesheet() !== Z882_CHILD) z882_record_once('prev_theme', get_stylesheet());
    z882_record_once('installed_parent', !wp_get_theme('generatepress')->exists());
    z882_record_once('had_generate_settings', (bool) get_option('generate_settings'));

    if (!wp_get_theme('generatepress')->exists()) {
        require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
        require_once ABSPATH . 'wp-admin/includes/theme.php';
        require_once ABSPATH . 'wp-admin/includes/file.php';
        $api = themes_api('theme_information', array('slug' => 'generatepress', 'fields' => array('sections' => false)));
        if (is_wp_error($api)) return 'Could not reach wordpress.org: ' . $api->get_error_message();
        $upgrader = new Theme_Upgrader(new Automatic_Upgrader_Skin());
        $result   = $upgrader->install($api->download_link);
        if (is_wp_error($result) || !$result) {
            return 'GeneratePress could not be installed automatically' . (is_wp_error($result) ? ' (' . $result->get_error_message() . ')' : '')
                 . '. Install it from Appearance → Themes → Add New, then run this step again.';
        }
    }

    if (!z882_sync_child_theme()) return 'Could not copy the child theme into ' . get_theme_root() . ' — check folder permissions.';

    if (!get_option('generate_settings')) {
        $json = file_get_contents(Z882_DIR . 'theme/generate-settings.json');
        $settings = json_decode((string) $json, true);
        if (is_array($settings)) update_option('generate_settings', $settings);
    }

    wp_clean_themes_cache();
    switch_theme(Z882_CHILD);
    return '';
}

// ── After an update: rebuild optimisers' cached CSS/pages ────
// Sites often run a CSS/page optimiser (zhibo882.com: Autoptimize) that keeps serving the old,
// combined CSS after the plugin or its bundled theme changed. Once per new version, ask the
// common ones to rebuild. Each call only runs when that plugin is there.
add_action('init', 'z882_clear_optimizer_caches_once', 20);
function z882_clear_optimizer_caches_once() {
    if (get_option('z882_assets_version') === Z882_VERSION) return;
    update_option('z882_assets_version', Z882_VERSION, false);
    z882_clear_optimizer_caches();
}

function z882_clear_optimizer_caches() {
    if (class_exists('autoptimizeCache') && method_exists('autoptimizeCache', 'clearall')) autoptimizeCache::clearall();
    if (function_exists('rocket_clean_domain')) rocket_clean_domain();          // WP Rocket
    if (function_exists('w3tc_flush_all')) w3tc_flush_all();                    // W3 Total Cache
    if (function_exists('wp_cache_clear_cache')) wp_cache_clear_cache();        // WP Super Cache
    do_action('litespeed_purge_all');                                           // LiteSpeed Cache
    if (class_exists('WpeCommon') && method_exists('WpeCommon', 'purge_varnish_cache')) WpeCommon::purge_varnish_cache();
}
