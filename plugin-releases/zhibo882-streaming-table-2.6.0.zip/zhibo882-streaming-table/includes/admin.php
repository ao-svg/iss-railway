<?php
/**
 * Admin: 直播设置 menu — status box + setup wizard (connection → look → pages → done).
 */

if (!defined('ABSPATH')) exit;

add_action('admin_menu', function () {
    $hook = add_menu_page('Zhibo Streaming', '直播设置', 'manage_options', 'zhibo-streaming', 'z882_admin_page', 'dashicons-video-alt3', 59);
    add_action('load-' . $hook, 'z882_admin_handle_post');
});

// Old Settings → Zhibo882 bookmarks
add_action('admin_init', function () {
    if (($_GET['page'] ?? '') === 'zhibo882-settings') { wp_safe_redirect(admin_url('admin.php?page=zhibo-streaming')); exit; }
});

// First activation → wizard
add_action('admin_init', function () {
    if (get_transient('z882_activation_redirect') && current_user_can('manage_options') && !wp_doing_ajax() && !isset($_GET['activate-multi'])) {
        delete_transient('z882_activation_redirect');
        wp_safe_redirect(admin_url('admin.php?page=zhibo-streaming&step=connect'));
        exit;
    }
});

add_filter('plugin_action_links_' . Z882_BASENAME, function ($links) {
    array_unshift($links, '<a href="' . esc_url(admin_url('admin.php?page=zhibo-streaming')) . '">设置向导</a>');
    return $links;
});

function z882_admin_url($step = '', $args = array()) {
    return add_query_arg(array_merge(array('page' => 'zhibo-streaming'), $step ? array('step' => $step) : array(), $args), admin_url('admin.php'));
}

function z882_notice($type, $text) {
    set_transient('z882_notice_' . get_current_user_id(), array($type, $text), 60);
}

// ── Form handling (POST → redirect) ──────────────────────────
function z882_admin_handle_post() {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST' || empty($_POST['z882_action'])) return;
    if (!current_user_can('manage_options')) wp_die('Unauthorized');
    $action = sanitize_key($_POST['z882_action']);
    check_admin_referer('z882_' . $action);
    $next = '';

    switch ($action) {
        case 'connect':
            $mode = ($_POST['mode'] ?? '') === 'network' ? 'network' : 'standalone';
            update_option('z882_mode', $mode);
            if ($mode === 'network') {
                update_option('z882_hub_url', esc_url_raw(untrailingslashit(trim(wp_unslash($_POST['hub_url'] ?? '')))));
                update_option('z882_network_key', sanitize_text_field(wp_unslash($_POST['network_key'] ?? '')));
                $cfg = z882_refresh_config();
                if (!$cfg) {
                    $last = get_option('z882_remote_last');
                    z882_notice('error', 'Could not connect to the hub: ' . ($last['error'] ?? 'no answer'));
                    $next = 'connect';
                    break;
                }
                z882_notice('success', 'Connected to the hub. Matches open on ' . $cfg['player_site'] . '.');
            } else {
                update_option('z882_player_site', esc_url_raw(untrailingslashit(trim(wp_unslash($_POST['player_site'] ?? '')))));
                update_option('z882_feed_fixtures', esc_url_raw(trim(wp_unslash($_POST['feed_fixtures'] ?? ''))));
                update_option('z882_feed_live', esc_url_raw(trim(wp_unslash($_POST['feed_live'] ?? ''))));
                update_option('z882_upcoming_page', absint($_POST['page_size'] ?? 30));
                $rotation = array_filter(array_map(function ($u) { return esc_url_raw(trim($u), array('http', 'https')); }, preg_split('/[\r\n]+/', (string) wp_unslash($_POST['rotation'] ?? ''))));
                update_option('z882_rotation', implode("\n", array_slice($rotation, 0, 20)));
                update_option('z882_cache_duration', min(60, absint($_POST['cache'] ?? 5)));
                z882_notice('success', 'Saved.');
            }
            z882_flush_cache();
            $next = 'look';
            break;

        case 'look':
            update_option('z882_brand', sanitize_text_field(wp_unslash($_POST['brand'] ?? '')));
            if (!empty($_POST['install_theme'])) {
                $error = z882_install_theme();
                if ($error) { z882_notice('error', $error); $next = 'look'; break; }
                z882_notice('success', 'Theme installed and activated.');
            } else {
                z882_notice('success', 'Saved.');
            }
            $next = 'pages';
            break;

        case 'pages':
            $map    = (array) get_option('z882_pages', array());
            $made   = array();
            $errors = array();
            foreach ((array) ($_POST['sports'] ?? array()) as $type => $spec) {
                $type = sanitize_text_field(wp_unslash((string) $type));
                $spec = array_map(function ($v) { return sanitize_text_field(wp_unslash((string) $v)); }, (array) $spec);
                if (empty($spec['on'])) {
                    if (!empty($map[$type]) && !empty($spec['was'])) unset($map[$type]);   // unticked: forget, page stays
                    continue;
                }
                $id = z882_setup_sport_page($type, $spec);
                if (is_wp_error($id)) { $errors[] = z882_get_sport_name_cn($type) . ': ' . $id->get_error_message(); continue; }
                $map[$type] = (int) $id;
                if ((int) ($spec['page'] ?? 0) !== (int) $id) $made[] = z882_get_sport_name_cn($type);
            }
            update_option('z882_pages', $map);
            if (!z882_homepage_status()) z882_setup_homepage();
            $menu = !empty($_POST['menu']) && z882_setup_menu($map);

            if ($errors) {
                z882_notice('error', implode(' · ', $errors));
                $next = 'pages';
                break;
            }
            z882_notice('success', ($made ? 'Pages ready: ' . implode('、', $made) . '.' : 'No changes.') . ($menu ? ' Header menu created.' : ''));
            $next = 'done';
            break;

        case 'refresh':
            $cfg = z882_refresh_config();
            z882_flush_cache();
            z882_notice($cfg ? 'success' : 'error', $cfg ? 'Updated from the hub.' : 'Hub unreachable — keeping the last settings.');
            break;

        case 'flush':
            z882_flush_cache();
            z882_notice('success', 'Match cache cleared.');
            break;

        case 'remove':
            $hub = z882_hub_url();
            $key = (string) get_option('z882_network_key', '');
            $log = z882_cleanup();
            z882_report(array(array('id' => 'local-' . time(), 'ok' => !preg_grep('/^ERROR/', $log), 'log' => $log, 'removed' => true)), $hub, $key);
            z882_self_delete();
            wp_safe_redirect(admin_url('plugins.php'));
            exit;
    }

    wp_safe_redirect(z882_admin_url($next ?: sanitize_key($_GET['step'] ?? '')));
    exit;
}

function z882_flush_cache() {
    global $wpdb;
    $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '\\_transient\\_z882\\_feed\\_%' OR option_name LIKE '\\_transient\\_timeout\\_z882\\_feed\\_%'");
}

// ── Page ─────────────────────────────────────────────────────
function z882_admin_page() {
    $step  = sanitize_key($_GET['step'] ?? '');
    $steps = array('connect' => '1 · 连接', 'look' => '2 · 外观', 'pages' => '3 · 页面', 'done' => '完成');
    $notice = get_transient('z882_notice_' . get_current_user_id());
    delete_transient('z882_notice_' . get_current_user_id());
    ?>
    <div class="wrap z882-admin">
        <h1>直播设置 <span class="z882-ver">v<?php echo esc_html(Z882_VERSION); ?></span></h1>
        <?php if ($notice): ?>
        <div class="notice notice-<?php echo esc_attr($notice[0]); ?> is-dismissible"><p><?php echo esc_html($notice[1]); ?></p></div>
        <?php endif; ?>

        <?php z882_admin_status_box(); ?>

        <nav class="z882-steps">
            <?php foreach ($steps as $key => $label): ?>
            <a href="<?php echo esc_url(z882_admin_url($key)); ?>" class="<?php echo $step === $key ? 'is-current' : ''; ?>"><?php echo esc_html($label); ?></a>
            <?php endforeach; ?>
        </nav>

        <div class="z882-card">
        <?php
        switch ($step) {
            case 'look':  z882_step_look(); break;
            case 'pages': z882_step_pages(); break;
            case 'done':  z882_step_done(); break;
            case 'connect': z882_step_connect(); break;
            default:      z882_step_done(); break;
        }
        ?>
        </div>
    </div>
    <style>
        .z882-admin .z882-ver { font-size: 13px; color: #787c82; font-weight: 400; }
        .z882-steps { display: flex; gap: 4px; margin: 18px 0 0; }
        .z882-steps a { padding: 8px 16px; border: 1px solid #c3c4c7; border-bottom: 0; border-radius: 6px 6px 0 0; background: #f6f7f7; text-decoration: none; color: #50575e; }
        .z882-steps a.is-current { background: #fff; color: #1d2327; font-weight: 600; }
        .z882-card { background: #fff; border: 1px solid #c3c4c7; padding: 20px 24px; max-width: 980px; }
        .z882-card h2 { margin-top: 0; }
        .z882-status { display: flex; flex-wrap: wrap; gap: 8px 28px; align-items: center; background: #fff; border: 1px solid #c3c4c7; border-left: 4px solid #00a32a; padding: 12px 16px; max-width: 948px; margin-top: 12px; }
        .z882-status.is-warn { border-left-color: #dba617; }
        .z882-status form { display: inline; }
        .z882-mode { display: grid; gap: 12px; margin: 12px 0 20px; }
        .z882-mode label.z882-option { display: block; border: 1px solid #c3c4c7; border-radius: 6px; padding: 12px 14px; cursor: pointer; }
        .z882-mode label.z882-option:has(input:checked) { border-color: #2271b1; box-shadow: 0 0 0 1px #2271b1; }
        .z882-fields[hidden] { display: none; }
        .z882-sports td, .z882-sports th { vertical-align: middle; }
        .z882-sports input[type=text] { width: 100%; }
        .z882-ok { color: #00a32a; font-weight: 600; }
    </style>
    <script>
    document.addEventListener('change', function (e) {
        if (e.target.name === 'mode') document.querySelectorAll('[data-mode]').forEach(function (el) { el.hidden = el.getAttribute('data-mode') !== e.target.value; });
        var row = e.target.closest && e.target.closest('tr[data-sport]');
        if (row && e.target.matches('select')) row.querySelectorAll('[data-new]').forEach(function (el) { el.disabled = e.target.value !== 'new'; });
    });
    </script>
    <?php
}

function z882_admin_status_box() {
    $network = z882_mode() === 'network';
    $last    = get_option('z882_remote_last');
    $warn    = $network && (!empty($last['error_at']) && (empty($last['at']) || $last['error_at'] > $last['at']));
    $theme   = z882_theme_status();
    ?>
    <div class="z882-status<?php echo $warn ? ' is-warn' : ''; ?>">
        <span><strong>模式:</strong> <?php echo $network ? 'Network (hub)' : 'Standalone'; ?></span>
        <span><strong>比赛跳转到:</strong> <a href="<?php echo esc_url(z882_player_site()); ?>" target="_blank" rel="noopener"><?php echo esc_html(z882_player_site()); ?></a></span>
        <?php if ($network): ?>
        <span><strong>Hub:</strong> <?php echo !empty($last['at']) ? esc_html(human_time_diff($last['at']) . ' ago') : 'never'; ?>
            <?php if ($warn): ?> — <em><?php echo esc_html($last['error']); ?></em><?php endif; ?></span>
        <form method="post"><?php wp_nonce_field('z882_refresh'); ?><input type="hidden" name="z882_action" value="refresh"><button class="button button-small">Refresh now</button></form>
        <?php endif; ?>
        <span><strong>主题:</strong> <?php echo $theme['active'] ? '<span class="z882-ok">✓</span>' : 'not active'; ?></span>
        <span><strong>首页:</strong> <?php echo z882_homepage_status() ? '<span class="z882-ok">✓</span>' : 'no table yet'; ?></span>
        <form method="post"><?php wp_nonce_field('z882_flush'); ?><input type="hidden" name="z882_action" value="flush"><button class="button button-small">Clear match cache</button></form>
    </div>
    <?php
}

function z882_step_connect() {
    $mode = z882_mode();
    $cfg  = z882_config();
    ?>
    <h2>Where do matches open?</h2>
    <form method="post">
        <?php wp_nonce_field('z882_connect'); ?>
        <input type="hidden" name="z882_action" value="connect">
        <div class="z882-mode">
            <label class="z882-option"><input type="radio" name="mode" value="network" <?php checked($mode, 'network'); ?>>
                <strong>Network — controlled by the hub</strong><br><span class="description">Destination site, feeds and plugin updates come from the hub (the iss-railway service → WordPress sites). Change them there once for every domain.</span></label>
            <label class="z882-option"><input type="radio" name="mode" value="standalone" <?php checked($mode, 'standalone'); ?>>
                <strong>Standalone — set on this site</strong><br><span class="description">Everything is configured here; no hub, no automatic updates.</span></label>
        </div>

        <table class="form-table z882-fields" data-mode="network" <?php echo $mode === 'network' ? '' : 'hidden'; ?>>
            <tr><th>Hub URL</th><td><input type="url" name="hub_url" class="regular-text" placeholder="https://iss-railway-production.up.railway.app" value="<?php echo esc_attr(z882_hub_url()); ?>"></td></tr>
            <tr><th>Network key</th><td><input type="text" name="network_key" class="regular-text code" autocomplete="off" value="<?php echo esc_attr(get_option('z882_network_key', '')); ?>">
                <p class="description">Shown on the hub's “WordPress sites” page.</p></td></tr>
        </table>

        <table class="form-table z882-fields" data-mode="standalone" <?php echo $mode === 'standalone' ? '' : 'hidden'; ?>>
            <tr><th>Destination site</th><td><input type="url" name="player_site" class="regular-text" value="<?php echo esc_attr(get_option('z882_player_site', '') ?: Z882_PLAYER_SITE); ?>">
                <p class="description">Every match opens there: <code>&lt;site&gt;/#match-…</code>, or <code>/#football/match-…</code> from a sport page.</p></td></tr>
            <tr><th>Fixtures feed</th><td><input type="url" name="feed_fixtures" class="large-text" value="<?php echo esc_attr(get_option('z882_feed_fixtures', '') ?: Z882_DEFAULT_FEED_FIXTURES); ?>">
                <p class="description">Must be the feed the destination site uses, or links won't find their match.</p></td></tr>
            <tr><th>Live feed</th><td><input type="url" name="feed_live" class="large-text" value="<?php echo esc_attr(get_option('z882_feed_live', '') ?: Z882_DEFAULT_FEED_LIVE); ?>"></td></tr>
            <tr><th>Rotation (optional)</th><td><textarea name="rotation" rows="3" class="large-text code" placeholder="https://zazhibo82.com"><?php echo esc_textarea((string) get_option('z882_rotation', '')); ?></textarea>
                <p class="description">Other destinations, one per line. Each click then opens one of them or the destination above, at random. Empty = always the destination above.</p></td></tr>
            <tr><th>Upcoming per page</th><td><input type="number" name="page_size" min="0" max="500" value="<?php echo esc_attr(get_option('z882_upcoming_page', 30)); ?>"> <span class="description">0 = all</span></td></tr>
            <tr><th>Feed cache (minutes)</th><td><input type="number" name="cache" min="0" max="60" value="<?php echo esc_attr(get_option('z882_cache_duration', 5)); ?>"></td></tr>
        </table>
        <?php submit_button('Save and continue'); ?>
    </form>
    <?php
}

function z882_step_look() {
    $theme = z882_theme_status();
    ?>
    <h2>Site look</h2>
    <form method="post">
        <?php wp_nonce_field('z882_look'); ?>
        <input type="hidden" name="z882_action" value="look">
        <table class="form-table">
            <tr><th>Brand name</th><td><input type="text" name="brand" class="regular-text" placeholder="<?php echo esc_attr(get_bloginfo('name')); ?>" value="<?php echo esc_attr(get_option('z882_brand', '')); ?>">
                <p class="description">Shown in the header and footer. Empty = the site title. The logo is the Site Icon (Appearance → Customize → Site Identity) or the default mark.</p></td></tr>
            <tr><th>Theme</th><td>
                <?php if ($theme['active']): ?>
                <p><span class="z882-ok">✓</span> GeneratePress + Zhibo Streaming Child is active. It updates together with this plugin.</p>
                <label><input type="checkbox" name="install_theme" value="1"> Reinstall the child theme now</label>
                <?php else: ?>
                <label><input type="checkbox" name="install_theme" value="1" checked> Install GeneratePress<?php echo $theme['parent'] ? ' (already installed)' : ''; ?> + the Zhibo child theme and activate it</label>
                <p class="description">Gives the site the zhibo82.com look: header, footer, light/dark mode. Leave unticked to keep the current theme — the table still works in any theme.</p>
                <?php endif; ?>
            </td></tr>
        </table>
        <?php submit_button('Save and continue'); ?>
    </form>
    <?php
}

function z882_step_pages() {
    $map    = (array) get_option('z882_pages', array());
    $counts = z882_sport_counts();
    $pages  = get_pages(array('post_status' => 'publish,draft', 'sort_column' => 'post_title'));
    $first  = !$map;
    $home   = z882_homepage_status();
    ?>
    <h2>Pages</h2>
    <p><strong>Homepage:</strong>
        <?php if ($home): ?><span class="z882-ok">✓</span> <a href="<?php echo esc_url(home_url('/')); ?>" target="_blank"><?php echo esc_html($home->post_title); ?></a> shows every sport.
        <?php else: ?>gets the table automatically when you save this step.<?php endif; ?></p>
    <p class="description">Each ticked sport gets a page with its table right under the heading. New pages start with sample SEO text — replace it in the editor. An existing page keeps its content; the table is added under its heading.</p>
    <form method="post">
        <?php wp_nonce_field('z882_pages'); ?>
        <input type="hidden" name="z882_action" value="pages">
        <table class="widefat striped z882-sports">
            <thead><tr><th style="width:30px"></th><th>Sport</th><th>Page</th><th>Title (H1)</th><th>Address</th><th>Matches now</th></tr></thead>
            <tbody>
            <?php foreach (z882_page_sports() as $i => $type): ?>
            <?php
            $f       = 'sports[' . esc_attr($type) . ']';
            $current = !empty($map[$type]) ? get_post((int) $map[$type]) : null;
            if (!$current && ($bySlug = get_page_by_path(z882_sport_slug($type))) && has_shortcode($bySlug->post_content, 'zhibo882_streaming')) $current = $bySlug;
            $on      = $current || ($first && $i < 6);
            ?>
            <tr data-sport="<?php echo esc_attr($type); ?>">
                <td><input type="checkbox" name="<?php echo $f; ?>[on]" value="1" <?php checked($on); ?>><?php if ($current): ?><input type="hidden" name="<?php echo $f; ?>[was]" value="1"><?php endif; ?></td>
                <td><?php echo esc_html(z882_get_sport_name_cn($type)); ?> <span class="description"><?php echo esc_html($type); ?></span></td>
                <td>
                    <?php if ($current): ?>
                    <input type="hidden" name="<?php echo $f; ?>[page]" value="<?php echo (int) $current->ID; ?>">
                    <span class="z882-ok">✓</span> <a href="<?php echo esc_url(get_permalink($current)); ?>" target="_blank"><?php echo esc_html($current->post_title); ?></a>
                    · <a href="<?php echo esc_url(get_edit_post_link($current->ID)); ?>">Edit</a>
                    <?php else: ?>
                    <select name="<?php echo $f; ?>[page]">
                        <option value="new">Create new page</option>
                        <?php foreach ($pages as $pg): ?>
                        <option value="<?php echo (int) $pg->ID; ?>">Use: <?php echo esc_html($pg->post_title ?: '(no title)'); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <?php endif; ?>
                </td>
                <td><?php if (!$current): ?><input type="text" data-new name="<?php echo $f; ?>[title]" value="<?php echo esc_attr(z882_get_sport_name_cn($type) . '直播'); ?>"><?php endif; ?></td>
                <td><?php if (!$current): ?><code>/</code><input type="text" data-new name="<?php echo $f; ?>[slug]" value="<?php echo esc_attr(z882_sport_slug($type)); ?>" style="width:150px"><code>/</code><?php else: ?><code><?php echo esc_html(wp_make_link_relative(get_permalink($current))); ?></code><?php endif; ?></td>
                <td><?php echo (int) ($counts[$type] ?? 0); ?></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <p><label><input type="checkbox" name="menu" value="1" <?php checked(!has_nav_menu('primary')); ?> <?php disabled(has_nav_menu('primary')); ?>>
            Create the header menu (直播首页 + the first four sports)<?php echo has_nav_menu('primary') ? ' — this site already has one' : ''; ?></label></p>
        <?php submit_button('Create pages'); ?>
    </form>
    <?php
}

function z882_step_done() {
    $map  = (array) get_option('z882_pages', array());
    $home = z882_homepage_status();
    ?>
    <h2>Pages with the match table</h2>
    <table class="widefat striped" style="max-width:760px">
        <thead><tr><th>Page</th><th>Address</th><th>Matches open on</th><th></th></tr></thead>
        <tbody>
        <?php if ($home): ?>
        <tr><td><?php echo esc_html($home->post_title); ?> (homepage)</td><td><code>/</code></td><td><code><?php echo esc_html(z882_player_site()); ?>/#match-…</code></td>
            <td><a href="<?php echo esc_url(home_url('/')); ?>" target="_blank">View</a> · <a href="<?php echo esc_url(get_edit_post_link($home->ID)); ?>">Edit</a></td></tr>
        <?php endif; ?>
        <?php foreach ($map as $type => $id): $pg = get_post((int) $id); if (!$pg) continue; ?>
        <tr><td><?php echo esc_html($pg->post_title); ?></td><td><code><?php echo esc_html(wp_make_link_relative(get_permalink($pg))); ?></code></td>
            <td><code><?php echo esc_html(z882_player_site() . '/#' . z882_sport_slug($type)); ?>/…</code></td>
            <td><a href="<?php echo esc_url(get_permalink($pg)); ?>" target="_blank">View</a> · <a href="<?php echo esc_url(get_edit_post_link($pg->ID)); ?>">Edit SEO text</a></td></tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <p><a class="button" href="<?php echo esc_url(z882_admin_url('connect')); ?>">Run setup again</a> <a class="button" href="<?php echo esc_url(z882_admin_url('pages')); ?>">Add or change sport pages</a></p>

    <h2>Remove completely</h2>
    <p class="description">Takes the table out of every page, post and widget; keeps the sport pages with their text; puts back the theme, front page and menu the site had before; adds 301s for anything removed (when the ABS3 bridge is installed); deletes all settings and then the plugin itself.</p>
    <form method="post" onsubmit="return confirm('Remove the plugin and everything it added from this site?');">
        <?php wp_nonce_field('z882_remove'); ?>
        <input type="hidden" name="z882_action" value="remove">
        <button class="button button-link-delete">Remove completely</button>
    </form>

    <h2>Shortcode</h2>
    <p>The table can go on any page or post:</p>
    <p><code>[zhibo882_streaming]</code> — every sport<br>
       <code>[zhibo882_streaming type_filter="Football"]</code> — one sport (matches open in that sport's view)<br>
       <code>[zhibo882_streaming league_keywords="World Cup, 世界杯"]</code> — a keyword view with a “查看所有比赛” button<br>
       Other options: <code>show_type_filter="false"</code>, <code>heading="…"</code>, <code>show_date="true"</code>, <code>no_match_action="show_all"</code>.</p>
    <?php
}
