<?php
/**
 * Updates from the hub.
 *
 * The hub's config answer carries the latest published version and its download link. It is
 * added straight into WordPress's list of available updates (the update_plugins site transient)
 * every time that list is read. That is deliberate: WordPress's own Update URI mechanism only runs
 * after a successful call to api.wordpress.org, which servers in China often can't make. The
 * "Update URI" header still keeps wordpress.org from ever offering a same-named plugin.
 * WordPress then does the rest, including the background update when the hub has auto-update on.
 */

if (!defined('ABSPATH')) exit;

function z882_update_offer() {
    if (z882_mode() !== 'network') return null;
    $latest = z882_cfg('latest');
    if (empty($latest['version']) || empty($latest['package']) || !version_compare($latest['version'], Z882_VERSION, '>')) return null;
    return (object) array(
        'id'           => 'https://zhibo-hub/zhibo882-streaming-table',
        'slug'         => 'zhibo882-streaming-table',
        'plugin'       => Z882_BASENAME,
        'new_version'  => $latest['version'],
        'url'          => z882_hub_url(),
        'package'      => $latest['package'],
        'tested'       => get_bloginfo('version'),
        'requires_php' => '7.4',
    );
}

add_filter('site_transient_update_plugins', function ($value) {
    $offer = z882_update_offer();
    if (!$offer) {
        if (is_object($value) && isset($value->response[Z882_BASENAME])) unset($value->response[Z882_BASENAME]);
        return $value;
    }
    if (!is_object($value)) $value = (object) array('last_checked' => time(), 'response' => array(), 'no_update' => array(), 'translations' => array(), 'checked' => array());
    $value->response[Z882_BASENAME] = $offer;
    unset($value->no_update[Z882_BASENAME]);
    return $value;
});

// "View details" in the plugins list
add_filter('plugins_api', function ($result, $action, $args) {
    if ($action !== 'plugin_information' || ($args->slug ?? '') !== 'zhibo882-streaming-table') return $result;
    $latest = z882_cfg('latest');
    return (object) array(
        'name'          => 'Zhibo Streaming Table',
        'slug'          => 'zhibo882-streaming-table',
        'version'       => $latest['version'] ?? Z882_VERSION,
        'author'        => 'Zhibo',
        'download_link' => $latest['package'] ?? '',
        'sections'      => array('changelog' => nl2br(esc_html($latest['notes'] ?? 'Published from the hub.'))),
    );
}, 10, 3);

// Background auto-update, when the hub says so
add_filter('auto_update_plugin', function ($update, $item) {
    if (isset($item->plugin) && $item->plugin === Z882_BASENAME && z882_mode() === 'network') {
        return (bool) z882_cfg('auto_update');
    }
    return $update;
}, 10, 2);

// A newer version on the hub: show it in the plugins list right away, and — with auto-update on —
// install it with this plugin's own installer (z882_self_update in remote.php). WordPress's
// background updater isn't used for it: it skips or rolls back updates without telling anyone
// (e.g. its post-update loopback check fails on servers whose cron runs as https://127.0.0.1),
// which left live sites on 2.3.3 for days. A failed try is retried hourly; every outcome is sent
// to the hub with the next check-in (z882_update_status()).
add_action('init', function () {
    if (z882_mode() !== 'network') return;
    $latest = z882_cfg('latest');
    if (empty($latest['version']) || !version_compare($latest['version'], Z882_VERSION, '>')) return;
    if (get_option('z882_update_seen') !== $latest['version']) {
        update_option('z882_update_seen', $latest['version'], false);
        delete_site_transient('update_plugins');
        wp_schedule_single_event(time() + 30, 'wp_update_plugins');
    }
    if (!z882_cfg('auto_update')) return;
    $last = get_option('z882_update_result');
    $tried = is_array($last) && ($last['version'] ?? '') === $latest['version'];
    if ($tried && time() - (int) ($last['at'] ?? 0) < HOUR_IN_SECONDS) return;
    if (!function_exists('z882_queue_self_update')) return;
    // Stays as the result if WP-Cron never runs the job — then the hub sees that too
    update_option('z882_update_result', array('version' => $latest['version'], 'ok' => false, 'error' => 'queued, WP-Cron has not run it', 'at' => time()), false);
    z882_queue_self_update();
});

// "2.5.1 ok" / "2.5.1 failed: <reason>" for the hub, or '' when nothing was tried
function z882_update_status() {
    $r = get_option('z882_update_result');
    if (!is_array($r) || empty($r['version'])) return '';
    return $r['version'] . ($r['ok'] ? ' ok' : ' failed: ' . $r['error']);
}
