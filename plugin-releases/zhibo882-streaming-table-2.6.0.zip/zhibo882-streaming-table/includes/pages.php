<?php
/**
 * Pages: the homepage gets the table automatically; sport pages come from the setup wizard.
 * The table always goes right under the page heading, with the page's own content (SEO text) below.
 */

if (!defined('ABSPATH')) exit;

// The main sports (zhibo82.com's menu and footer), then whatever else the feed has now
function z882_page_sports() {
    $sports = array('Football', 'Basketball', 'Tennis', 'American Football', 'Ice Hockey', 'Cricket');
    foreach (z882_collect()['types'] as $type) {
        // "Soccer" is the feed's odd name for a few football matches — no second 足球直播 page
        if (in_array($type, array('Other', 'Soccer'), true) || z882_sport_slug($type) === '') continue;
        if (!in_array($type, $sports, true)) $sports[] = $type;
    }
    return $sports;
}

function z882_sport_counts() {
    $counts = array();
    $data = z882_collect();
    foreach (array_merge($data['live'], $data['upcoming'], $data['ended']) as $m) {
        $counts[$m['type']] = ($counts[$m['type']] ?? 0) + 1;
    }
    return $counts;
}

function z882_shortcode_block($type = '') {
    $sc = $type !== '' ? '[zhibo882_streaming type_filter="' . esc_attr($type) . '"]' : '[zhibo882_streaming]';
    return "<!-- wp:shortcode -->\n" . $sc . "\n<!-- /wp:shortcode -->";
}

// Content with the table added under the heading: after a leading heading block if the content
// starts with one, otherwise first (the page title is the heading). Unchanged if a table is there.
function z882_insert_table($content, $type = '') {
    if (has_shortcode($content, 'zhibo882_streaming')) return $content;
    $block = z882_shortcode_block($type);
    if (preg_match('~^\s*<!-- wp:heading\b.*?<!-- /wp:heading -->~s', $content, $m)) {
        return $m[0] . "\n\n" . $block . substr($content, strlen($m[0]));
    }
    if (preg_match('~^\s*<h[1-3][^>]*>.*?</h[1-3]>~is', $content, $m)) {   // classic editor content
        return $m[0] . "\n\n[zhibo882_streaming" . ($type !== '' ? ' type_filter="' . esc_attr($type) . '"' : '') . "]" . substr($content, strlen($m[0]));
    }
    return $block . "\n\n" . ltrim($content);
}

// ── Homepage (no wizard needed) ──────────────────────────────
// Blog on the front → a new 直播首页 page becomes the front page. A static front page → the
// table is added under its heading. Runs on activation and from the wizard.
function z882_setup_homepage() {
    $frontId = (int) get_option('page_on_front');
    z882_record_once('prev_show_on_front', get_option('show_on_front'));
    z882_record_once('prev_page_on_front', $frontId);
    if (get_option('show_on_front') === 'page' && $frontId && ($front = get_post($frontId)) && $front->post_status === 'publish') {
        $content = z882_insert_table($front->post_content);
        if ($content !== $front->post_content) wp_update_post(array('ID' => $frontId, 'post_content' => $content));
        return $frontId;
    }
    $id = wp_insert_post(array(
        'post_type'    => 'page',
        'post_status'  => 'publish',
        'post_title'   => '直播首页',
        'post_content' => z882_shortcode_block() . "\n",
    ));
    if (!$id || is_wp_error($id)) return 0;
    z882_record_add('created_pages', (int) $id);
    z882_record_once('created_front_page', (int) $id);
    update_option('show_on_front', 'page');
    update_option('page_on_front', $id);
    return $id;
}

function z882_homepage_status() {
    $frontId = (int) get_option('page_on_front');
    $front   = get_option('show_on_front') === 'page' && $frontId ? get_post($frontId) : null;
    return $front && has_shortcode($front->post_content, 'zhibo882_streaming') ? $front : null;
}

// ── Sport pages ──────────────────────────────────────────────
// Starter text for a new page, to replace with real SEO content in the editor
function z882_sport_page_content($type) {
    $name = z882_get_sport_name_cn($type);
    $p = function ($text) { return "<!-- wp:paragraph -->\n<p>" . $text . "</p>\n<!-- /wp:paragraph -->\n\n"; };
    $h = function ($text, $level = 2) {
        return '<!-- wp:heading' . ($level === 3 ? ' {"level":3}' : '') . " -->\n<h$level class=\"wp-block-heading\">" . $text . "</h$level>\n<!-- /wp:heading -->\n\n";
    };

    return z882_shortcode_block($type) . "\n\n"
        . $h($name . '直播在线观看')
        . $p('本站汇总今日及近期的' . $name . '赛事直播，列出比赛时间（北京时间）、对阵双方和所属赛事。点击任意比赛即可观看高清直播，多个直播源随时切换。')
        . $h($name . '直播常见问题')
        . $h($name . '直播免费吗？', 3)
        . $p('是的，所有' . $name . '直播均可免费观看，无需下载任何软件。')
        . $h('直播链接什么时候更新？', 3)
        . $p('赛程每隔几分钟自动更新，直播链接通常在比赛开始前约 30 分钟上线。');
}

// One sport from the wizard: $spec = ['page' => 'new'|<page id>, 'title' => …, 'slug' => …]
// Returns the page id, or a WP_Error.
function z882_setup_sport_page($type, $spec) {
    if (($spec['page'] ?? 'new') !== 'new') {
        $page = get_post((int) $spec['page']);
        if (!$page || $page->post_type !== 'page') return new WP_Error('z882', 'Page not found');
        $content = z882_insert_table($page->post_content, $type);
        if ($content !== $page->post_content) wp_update_post(array('ID' => $page->ID, 'post_content' => $content));
        return $page->ID;
    }

    $slug = sanitize_title($spec['slug'] ?? '') ?: z882_sport_slug($type);
    if (($existing = get_page_by_path($slug)) && $existing->post_status !== 'trash') {
        return new WP_Error('z882', '/' . $slug . '/ already exists — pick it as an existing page instead');
    }
    $id = wp_insert_post(array(
        'post_type'    => 'page',
        'post_status'  => 'publish',
        'post_name'    => $slug,
        'post_title'   => sanitize_text_field($spec['title'] ?? '') ?: z882_get_sport_name_cn($type) . '直播',
        'post_content' => z882_sport_page_content($type),
    ), true);
    if (!is_wp_error($id)) z882_record_add('created_pages', (int) $id);
    return $id;
}

// Header menu like zhibo82.com's: home + the first sport pages. Only when the theme has none.
function z882_setup_menu($sportPageIds) {
    if (has_nav_menu('primary')) return false;
    $existing = wp_get_nav_menu_object('主菜单');
    $menuId   = $existing ? $existing->term_id : wp_create_nav_menu('主菜单');
    if (is_wp_error($menuId)) return false;
    if (!$existing) {
        z882_record_add('created_menus', (int) $menuId);
        wp_update_nav_menu_item($menuId, 0, array('menu-item-title' => '直播首页', 'menu-item-url' => home_url('/'), 'menu-item-status' => 'publish'));
        foreach (array_slice($sportPageIds, 0, 4, true) as $type => $id) {
            wp_update_nav_menu_item($menuId, 0, array(
                'menu-item-title'     => z882_get_sport_name_cn($type),
                'menu-item-object'    => 'page',
                'menu-item-object-id' => $id,
                'menu-item-type'      => 'post_type',
                'menu-item-status'    => 'publish',
            ));
        }
    }
    $locations = get_theme_mod('nav_menu_locations', array());
    $locations['primary'] = $menuId;
    set_theme_mod('nav_menu_locations', $locations);
    return true;
}
