<?php
/**
 * What this plugin changed on the site, so removal can put it back (includes/remote.php → z882_cleanup).
 * First values win: the record keeps how the site looked before the plugin, not after a second setup run.
 */

if (!defined('ABSPATH')) exit;

function z882_record() {
    $r = get_option('z882_install_record', array());
    return is_array($r) ? $r : array();
}

// Set once: the value from before the plugin touched anything
function z882_record_once($key, $value) {
    $r = z882_record();
    if (array_key_exists($key, $r)) return;
    $r[$key] = $value;
    update_option('z882_install_record', $r, false);
}

// Lists: pages / menus the plugin created
function z882_record_add($key, $value) {
    $r = z882_record();
    $list = isset($r[$key]) && is_array($r[$key]) ? $r[$key] : array();
    if (!in_array($value, $list, true)) $list[] = $value;
    $r[$key] = $list;
    update_option('z882_install_record', $r, false);
}
