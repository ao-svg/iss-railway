/**
 * Zhibo82 Streaming Table
 * Row expand/collapse, sport filter, popup stream player and hash routing.
 *
 * Routes (all hash based, so links stay shareable and work with page caching):
 *   #football                 → sport filter
 *   #match-<id>               → open match
 *   #football/match-<id>      → sport filter + open match
 */

(function() {
    'use strict';

    let currentOpenRow = null;
    let lastAppliedRoute = null;

    // ── Helpers ──────────────────────────────────────────────
    function $(sel, root) { return (root || document).querySelector(sel); }
    function $$(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

    function getRow(matchId) {
        return matchId ? $('.z82-match-row[data-match-id="' + matchId + '"]') : null;
    }

    function getPrimaryTable() {
        return $('.z82-table-container[id^="z82-table-"]');
    }

    function getActiveSport(tableId) {
        const container = document.getElementById(tableId);
        const wrapper = container && container.closest('.z82-wrapper');
        const active = wrapper && $('.z82-filter-btn.active', wrapper);
        return active ? (active.getAttribute('data-sport') || '') : '';
    }

    // ── Routing ──────────────────────────────────────────────
    const SPORT_ALIASES = {
        'soccer':      'Football',
        'icehockey':   'Ice Hockey',
        'tabletennis': 'Table Tennis',
        'pingpong':    'Table Tennis',
        'mma':         'UFC/MMA',
        'ufc':         'UFC/MMA',
        'racing':      'Motorsport',
        'horseracing': 'Horse Racing',
        'aussierules': 'Australian Rules',
        'afl':         'Australian Rules'
    };

    function sportToSlug(type) {
        return String(type || '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
    }

    function slugToSport(slug) {
        const table = getPrimaryTable();
        const wrapper = table && table.closest('.z82-wrapper');
        const types = wrapper ? $$('.z82-filter-btn[data-sport]', wrapper).map(b => b.getAttribute('data-sport')).filter(Boolean) : [];

        for (let i = 0; i < types.length; i++) {
            if (sportToSlug(types[i]) === slug) return types[i];
        }
        const alias = SPORT_ALIASES[slug.replace(/-/g, '')];
        if (alias && types.indexOf(alias) !== -1) return alias;
        // Filter bar may be hidden (show_type_filter="false") — still honour known aliases
        return alias || null;
    }

    function parseRoute(hash) {
        const route = { sport: '', match: '' };
        String(hash || '').replace(/^#\/?/, '').split('/').forEach(part => {
            part = decodeURIComponent(part).trim().toLowerCase();
            if (!part) return;
            if (part.indexOf('match-') === 0) {
                route.match = part;
            } else {
                const sport = slugToSport(part);
                if (sport) route.sport = sport;
            }
        });
        return route;
    }

    function buildHash(route) {
        const parts = [];
        if (route.sport) parts.push(sportToSlug(route.sport));
        if (route.match) parts.push(route.match);
        return parts.length ? '#' + parts.join('/') : '';
    }

    function currentRoute() {
        const table = getPrimaryTable();
        return {
            sport: table ? getActiveSport(table.id) : '',
            match: currentOpenRow || ''
        };
    }

    // Write the current UI state into the URL (no reload, no hashchange event)
    function syncUrl() {
        const hash = buildHash(currentRoute());
        if (hash === (window.location.hash || '')) return;
        lastAppliedRoute = hash;
        const url = window.location.pathname + window.location.search + hash;
        if (window.history && window.history.pushState) {
            window.history.pushState(null, '', url);
        } else {
            window.location.hash = hash;
        }
    }

    // Read the URL and bring the UI in line with it
    function applyRoute(opts) {
        opts = opts || {};
        const hash = window.location.hash || '';
        if (hash === lastAppliedRoute && !opts.force) return;
        lastAppliedRoute = hash;

        const route = parseRoute(hash);
        const table = getPrimaryTable();

        if (table && getActiveSport(table.id) !== route.sport) {
            filterType(table.id, route.sport, null, { silent: true });
        }

        if (route.match) {
            const row = getRow(route.match);
            if (!row) {
                if (table) loadIncludedMatch(table.closest('.z82-wrapper'), route.match);
                return;
            }
            revealRow(row);
            if (currentOpenRow !== route.match) toggleRow(route.match, { silent: true });
            if (!opts.noScroll) setTimeout(() => row.scrollIntoView({ behavior: 'smooth', block: 'center' }), 60);
        } else if (currentOpenRow) {
            toggleRow(currentOpenRow, { silent: true });
        }
    }

    // Make sure a row targeted by a link is not hidden by ended/keyword collapsing
    function revealRow(row) {
        if (row.classList.contains('z82-match-hidden')) setEndedExpanded(true);
        if (row.classList.contains('z82-kw-hidden')) {
            const container = row.closest('.z82-table-container');
            if (container) window.z82ResetKeywords(container.id);
        }
    }

    // ── Row expand / collapse ────────────────────────────────
    function setRowOpen(row, open) {
        const content = document.getElementById('content-' + row.getAttribute('data-match-id'));
        const header = $('.z82-row-header', row);
        row.classList.toggle('expanded', open);
        if (content) content.style.display = open ? 'block' : 'none';
        if (header) header.setAttribute('aria-expanded', open ? 'true' : 'false');
        if (open) pauseFeatured();
        ytRowToggled(row, open);
    }

    function toggleRow(matchId, opts) {
        opts = opts || {};
        const row = getRow(matchId);
        if (!row) return;

        if (currentOpenRow && currentOpenRow !== matchId) {
            const other = getRow(currentOpenRow);
            if (other) setRowOpen(other, false);
        }

        if (row.classList.contains('expanded')) {
            setRowOpen(row, false);
            currentOpenRow = null;
        } else {
            setRowOpen(row, true);
            currentOpenRow = matchId;
            if (!opts.silent) {
                setTimeout(() => row.scrollIntoView({ behavior: 'smooth', block: 'nearest' }), 100);
            }
        }

        if (!opts.silent) syncUrl();
    }

    window.z82ToggleRow = function(matchId) { toggleRow(matchId); };

    // ── Popup stream player ──────────────────────────────────
    // Every stream opens our player page (?z82_stream=1), browsers with native HLS too: it plays
    // without a Referer, and if a source hasn't started after a few seconds it moves on to the
    // next one by itself (slow direct hosts outside the US).
    let popupWindow = null;

    // Is the stream popup still open? (the theme uses this to tell watching from browsing)
    window.z82IsWatching = function() {
        return !!(popupWindow && !popupWindow.closed);
    };

    // The player page needs the whole source list to switch on its own. It reads it from
    // localStorage under a one-time key in its URL (works before it has loaded, and in a reused
    // popup); postMessage is the fallback when storage is blocked.
    function stashSources(sources, activeIdx) {
        const key = 'z82_src_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
        try {
            for (let i = localStorage.length - 1; i >= 0; i--) {
                const k = localStorage.key(i);
                if (k && k.indexOf('z82_src_') === 0) {
                    let t = 0;
                    try { t = JSON.parse(localStorage.getItem(k)).t || 0; } catch (e) {}
                    if (Date.now() - t > 3600e3) localStorage.removeItem(k);
                }
            }
            localStorage.setItem(key, JSON.stringify({ t: Date.now(), sources, index: activeIdx }));
        } catch (e) {}
        return key;
    }

    window.z82OpenStream = function(popupUrl, sources, activeIdx) {
        // Cancelable hook: a theme can stop playback (e.g. ask the visitor to sign in first)
        const before = new CustomEvent('z82:beforeopen', { cancelable: true, detail: { popupUrl, sources, index: activeIdx } });
        if (!document.dispatchEvent(before)) return;

        if (sources && sources.length > 1) {
            popupUrl += (popupUrl.indexOf('?') < 0 ? '?' : '&') + 'z82list=' + stashSources(sources, activeIdx);
        }
        const sendSources = () => [500, 1500, 3000, 6000].forEach(ms => setTimeout(() => {
            if (popupWindow && !popupWindow.closed) popupWindow.postMessage({ type: 'z82_sources', sources, index: activeIdx }, '*');
        }, ms));

        if (popupWindow && !popupWindow.closed) {
            popupWindow.location.href = popupUrl;
            sendSources();
            popupWindow.focus();
            return;
        }

        const w = Math.min(1100, screen.availWidth  * 0.9);
        const h = Math.min(680,  screen.availHeight * 0.88);
        const x = Math.round((screen.availWidth  - w) / 2);
        const y = Math.round((screen.availHeight - h) / 2);
        popupWindow = window.open(
            popupUrl,
            'z82player',
            `width=${w},height=${h},left=${x},top=${y},resizable=yes,scrollbars=no,toolbar=no,menubar=no,location=no`
        );

        if (popupWindow) sendSources();
    };

    // ── Sport filter ─────────────────────────────────────────
    function filterType(tableId, sportType, callerBtn, opts) {
        opts = opts || {};
        const container = document.getElementById(tableId);
        if (!container) return;
        const wrapper = container.closest('.z82-wrapper') || container.parentElement;

        // Close any open row when filtering
        if (currentOpenRow) {
            const row = getRow(currentOpenRow);
            if (row) setRowOpen(row, false);
            currentOpenRow = null;
        }

        $$('.z82-filter-btn', wrapper).forEach(btn => {
            const isActive = callerBtn ? btn === callerBtn : (btn.getAttribute('data-sport') || '') === sportType;
            btn.classList.toggle('active', isActive);
            btn.setAttribute('aria-selected', isActive ? 'true' : 'false');
            if (isActive && btn.scrollIntoView && !opts.silent) {
                btn.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'center' });
            }
        });

        let visibleCount = 0;
        $$('.z82-match-row', container).forEach(row => {
            const show = sportType === '' || row.getAttribute('data-type') === sportType;
            row.classList.toggle('z82-filter-hidden', !show);
            if (show && !row.classList.contains('z82-match-hidden') && !row.classList.contains('z82-kw-hidden')) {
                visibleCount++;
            }
        });

        const wrapperEl = container.closest('.z82-wrapper');
        const remaining = wrapperEl ? updateLoadMore(wrapperEl) : 0;
        if (visibleCount === 0 && remaining > 0) {
            // Nothing of this sport loaded yet — fetch the first batch instead of showing "empty"
            const btn = $('.z82-load-more', container);
            if (btn) window.z82LoadMore(btn);
        }

        let empty = $('.z82-no-matches', container);
        if (visibleCount === 0 && remaining === 0 && !empty) {
            empty = document.createElement('div');
            empty.className = 'z82-no-matches';
            empty.innerHTML =
                '<p class="z82-no-matches-title">该分类暂无比赛</p>' +
                '<p class="z82-no-matches-text">请选择其他运动类型</p>' +
                '<button type="button" class="z82-btn-reset-filter">查看全部</button>';
            $('button', empty).addEventListener('click', () => window.z82ResetFilter(tableId));
            container.appendChild(empty);
        } else if ((visibleCount > 0 || remaining > 0) && empty) {
            empty.remove();
        }

        if (!opts.silent) syncUrl();
    }

    window.z82FilterType = function(tableId, sportType, callerBtn) {
        filterType(tableId, sportType || '', callerBtn || null);
    };

    window.z82ResetFilter = function(tableId) {
        filterType(tableId, '', null);
    };

    // ── Ended matches ────────────────────────────────────────
    function setEndedExpanded(expanded) {
        const toggle = document.getElementById('z82-show-ended-again');
        $$('.z82-match-row[data-is-finished="1"]').forEach(row => {
            // Only rows the server rendered collapsed can be collapsed again;
            // the first three ended matches always stay visible
            if (row.hasAttribute('data-ended-collapsible') || row.classList.contains('z82-match-hidden')) {
                row.setAttribute('data-ended-collapsible', '1');
                row.classList.toggle('z82-match-hidden', !expanded);
            }
        });
        if (toggle) {
            toggle.setAttribute('aria-expanded', expanded ? 'true' : 'false');
            const label = $('.z82-ended-info-label', toggle);
            if (label) label.textContent = label.getAttribute(expanded ? 'data-hide' : 'data-show');
        }
    }

    window.z82ShowAllEnded = function() {
        const toggle = document.getElementById('z82-show-ended-again');
        const expanded = toggle && toggle.getAttribute('aria-expanded') === 'true';
        setEndedExpanded(!expanded);
    };

    // ── Keyword view ([zhibo82_streaming league_keywords="..."]) ──
    window.z82ResetKeywords = function(tableId) {
        const container = document.getElementById(tableId);
        if (!container) return;
        $$('.z82-kw-hidden', container).forEach(row => row.classList.remove('z82-kw-hidden'));
        const wrapper = container.closest('.z82-wrapper');
        const bar = wrapper && $('.z82-kw-reset-bar', wrapper);
        if (bar) bar.style.display = 'none';
    };

    // ── Admin: flush cache ───────────────────────────────────
    window.z82FlushCache = function(btn, nonce, ajaxUrl) {
        btn.disabled = true;
        btn.textContent = 'Flushing…';
        fetch(ajaxUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'action=z82_flush_cache_ajax&nonce=' + encodeURIComponent(nonce)
        })
            .then(r => r.json())
            .then(d => {
                btn.textContent = d.success ? 'Done' : 'Error';
                if (d.success) setTimeout(() => location.reload(), 600);
            })
            .catch(() => { btn.textContent = 'Error'; btn.disabled = false; });
    };

    // ── Filter bar edge fades ────────────────────────────────
    function initFilterScroll(root) {
        $$('.z82-filters-wrap', root).forEach(wrap => {
            const bar = $('.z82-filters', wrap);
            if (!bar) return;
            const update = () => {
                const max = bar.scrollWidth - bar.clientWidth;
                wrap.classList.toggle('can-scroll-left', bar.scrollLeft > 2);
                wrap.classList.toggle('can-scroll-right', max - bar.scrollLeft > 2);
            };
            bar.addEventListener('scroll', update, { passive: true });
            window.addEventListener('resize', update);
            update();
        });
    }

    // ── Countdowns ───────────────────────────────────────────
    // Same format as the server ("2小时5分后" / "35分钟后"), ticked in the browser so the
    // auto refresh doesn't have to reload the table just because time passed.
    function updateCountdowns() {
        const now = Date.now() / 1000;
        $$('.z82-countdown[data-start]').forEach(el => {
            const mins = (Number(el.getAttribute('data-start')) - now) / 60;
            if (!(mins > 15)) {
                // Within 15 minutes the server treats it as live; the next refresh flips it
                el.textContent = '即将开始';
                return;
            }
            const h = Math.floor(mins / 60);
            const m = Math.floor(mins) % 60;
            el.textContent = h > 0 ? h + '小时' + m + '分后' : m + '分钟后';
        });
    }

    // ── Auto refresh ─────────────────────────────────────────
    // Asks the server whether the table changed (it compares fingerprints) and swaps
    // the new table in place, keeping filter, open match, toggles and scroll position.
    function captureState(wrapper) {
        const bar = $('.z82-filters', wrapper);
        const toggle = $('#z82-show-ended-again', wrapper);
        const kwBar = $('.z82-kw-reset-bar', wrapper);

        // Scroll anchor: the open row, else the first row visible in the viewport
        let anchor = currentOpenRow ? getRow(currentOpenRow) : null;
        if (!anchor || !wrapper.contains(anchor)) {
            anchor = $$('.z82-match-row', wrapper).find(r => r.offsetParent && r.getBoundingClientRect().bottom > 0) || null;
        }

        return {
            filtersScroll: bar ? bar.scrollLeft : 0,
            endedExpanded: !!toggle && toggle.getAttribute('aria-expanded') === 'true',
            kwReset: !!kwBar && kwBar.style.display === 'none',
            anchorId: anchor ? anchor.getAttribute('data-match-id') : null,
            anchorTop: anchor ? anchor.getBoundingClientRect().top : 0
        };
    }

    function swapWrapper(oldWrapper, html) {
        const state = captureState(oldWrapper);
        const tpl = document.createElement('template');
        tpl.innerHTML = html.trim();
        const fresh = tpl.content.querySelector('.z82-wrapper');
        if (!fresh) return;

        unobserveGifs(oldWrapper);
        oldWrapper.parentNode.replaceChild(fresh, oldWrapper);
        currentOpenRow = null;

        const table = $('.z82-table-container', fresh);
        if (state.kwReset && table) window.z82ResetKeywords(table.id);
        if (state.endedExpanded) setEndedExpanded(true);
        applyRoute({ force: true, noScroll: true });

        initFilterScroll(fresh);
        updateLoadMore(fresh);
        syncBells(fresh);
        observeGifs(fresh);
        applyYouTube(fresh).then(() => { if (ytOk && !featured) buildFeatured(fresh); });
        const bar = $('.z82-filters', fresh);
        if (bar) bar.scrollLeft = state.filtersScroll;
        updateCountdowns();

        // Keep the same row at the same place on screen
        const anchor = state.anchorId ? getRow(state.anchorId) : null;
        if (anchor && anchor.offsetParent) {
            const delta = anchor.getBoundingClientRect().top - state.anchorTop;
            if (Math.abs(delta) > 1) window.scrollBy(0, delta);
        }

        document.dispatchEvent(new CustomEvent('z82:refreshed', { detail: { wrapper: fresh } }));
    }

    function readAtts(wrapper) {
        try { return JSON.parse(wrapper.getAttribute('data-z82-atts') || '{}') || {}; } catch (e) { return {}; }
    }

    // POSTs to the refresh endpoint. v = fingerprint the page has ('' forces a fresh table).
    function fetchTable(wrapper, atts, v) {
        const ajaxUrl = window.z82Config && window.z82Config.ajaxUrl;
        if (!ajaxUrl || !window.fetch) return Promise.reject(new Error('no ajax'));
        const body = new URLSearchParams();
        body.append('action', 'z82_refresh');
        body.append('v', v || '');
        body.append('atts', JSON.stringify(atts));
        return fetch(ajaxUrl, { method: 'POST', body: body, credentials: 'same-origin' })
            .then(r => r.json())
            .then(res => (res && res.success && res.data) ? res.data : { changed: false });
    }

    // ── Load more upcoming matches ───────────────────────────
    // Shows "还有 N 场" for the active sport and hides the button when nothing is left.
    // Returns how many upcoming matches of the active sport are still unloaded.
    function updateLoadMore(wrapper) {
        const btn = $('.z82-load-more', wrapper);
        if (!btn) return 0;
        const table = $('.z82-table-container', wrapper);
        const sport = table ? getActiveSport(table.id) : '';
        let remaining = {};
        try { remaining = JSON.parse(btn.getAttribute('data-remaining') || '{}'); } catch (e) {}
        const left = remaining[sport] || 0;
        btn.hidden = left === 0;
        const count = $('.z82-load-more-count', btn);
        if (count) count.textContent = '还有 ' + left + ' 场';
        return left;
    }

    window.z82LoadMore = function(btn) {
        const wrapper = btn.closest('.z82-wrapper');
        if (!wrapper || btn.classList.contains('is-loading')) return;
        const table = $('.z82-table-container', wrapper);
        const sport = table ? getActiveSport(table.id) : '';
        const page = parseInt(wrapper.getAttribute('data-z82-page'), 10) || 30;
        const atts = readAtts(wrapper);
        const limits = atts.limits && typeof atts.limits === 'object' ? atts.limits : {};

        if (sport === '') {
            limits[''] = Math.max(limits[''] || 0, page) + page;
        } else {
            const loaded = $$('.z82-match-row.upcoming', wrapper).filter(r => r.getAttribute('data-type') === sport).length;
            limits[sport] = loaded + page;
        }
        atts.limits = limits;

        btn.classList.add('is-loading');
        btn.disabled = true;
        fetchTable(wrapper, atts, '')
            .then(data => { if (data.html) swapWrapper(wrapper, data.html); })
            .catch(() => {
                btn.classList.remove('is-loading');
                btn.disabled = false;
            });
    };

    // Deep link (#match-…) to an upcoming match outside the loaded pages: ask the server
    // to include it, then open it. One attempt per match id.
    const includeTried = {};
    function loadIncludedMatch(wrapper, matchId) {
        if (!wrapper || includeTried[matchId]) return;
        includeTried[matchId] = true;
        const atts = readAtts(wrapper);
        atts.include = matchId;
        fetchTable(wrapper, atts, '').then(data => {
            if (!data.html) return;
            swapWrapper(wrapper, data.html);
            const row = getRow(matchId);
            if (row) setTimeout(() => row.scrollIntoView({ behavior: 'smooth', block: 'center' }), 60);
        }).catch(() => {});
    }

    function initAutoRefresh() {
        const first = $('.z82-wrapper[data-z82-refresh]');
        const seconds = first ? parseInt(first.getAttribute('data-z82-refresh'), 10) : 0;
        const ajaxUrl = window.z82Config && window.z82Config.ajaxUrl;
        if (!seconds || !ajaxUrl || !window.fetch) return;

        const interval = seconds * 1000;
        let timer = null;
        let lastRun = Date.now();
        let running = false;

        function schedule(delay) {
            clearTimeout(timer);
            timer = setTimeout(run, delay);
        }

        function refreshOne(wrapper) {
            if ($('.z82-yt-player iframe', wrapper)) return Promise.resolve();
            return fetchTable(wrapper, readAtts(wrapper), wrapper.getAttribute('data-z82-v') || '')
                .then(data => {
                    if (data.changed && data.html && document.body.contains(wrapper)) swapWrapper(wrapper, data.html);
                });
        }

        function run() {
            if (document.hidden || running) return;
            running = true;
            // Sequential, one table at a time
            $$('.z82-wrapper[data-z82-v]')
                .reduce((chain, w) => chain.then(() => refreshOne(w)).catch(() => {}), Promise.resolve())
                .then(() => {
                    running = false;
                    lastRun = Date.now();
                    schedule(interval);
                });
        }

        // No polling while the tab is in the background; catch up on return
        document.addEventListener('visibilitychange', () => {
            if (document.hidden) {
                clearTimeout(timer);
            } else {
                const due = interval - (Date.now() - lastRun);
                if (due <= 0) run(); else schedule(due);
            }
        });

        schedule(interval);
    }

    // ── Match reminders (bell on upcoming rows) ──────────────
    // Web Push when the browser supports it (works with the site closed); otherwise, or if
    // the push service is unreachable, an in-page notification while a tab stays open.
    // State lives in localStorage: { matchId: { start, title, league, push, notified } }
    const REMINDER_KEY = 'z82-reminders';

    function pushCfg() {
        return (window.z82Config && window.z82Config.push) || {};
    }

    function loadReminders() {
        try { return JSON.parse(localStorage.getItem(REMINDER_KEY)) || {}; } catch (e) { return {}; }
    }

    function saveReminders(rem) {
        try { localStorage.setItem(REMINDER_KEY, JSON.stringify(rem)); } catch (e) {}
    }

    function leadText() {
        const lead = pushCfg().lead || 0;
        return lead > 0 ? '开赛前 ' + lead + ' 分钟' : '开赛时';
    }

    function syncBells(root) {
        const rem = loadReminders();
        $$('.z82-remind', root).forEach(btn => {
            const on = !!rem[btn.getAttribute('data-remind')];
            btn.classList.toggle('is-on', on);
            btn.setAttribute('aria-pressed', on ? 'true' : 'false');
            btn.setAttribute('data-z82-tip', on
                ? '已订阅：' + leadText() + '会通知你（点击取消）'
                : '开播提醒：' + leadText() + '通知我');
            btn.setAttribute('aria-label', btn.getAttribute('data-z82-tip'));
        });
    }

    // One floating tooltip for every [data-z82-tip] (the rows clip overflow, so it lives on <body>)
    function initTooltips() {
        let tip = null;
        const show = el => {
            if (!tip) {
                tip = document.createElement('div');
                tip.className = 'z82-tip';
                tip.setAttribute('role', 'tooltip');
                document.body.appendChild(tip);
            }
            tip.textContent = el.getAttribute('data-z82-tip');
            tip.classList.add('is-visible');
            const r = el.getBoundingClientRect();
            const w = tip.offsetWidth, h = tip.offsetHeight;
            let left = r.left + r.width / 2 - w / 2;
            left = Math.max(8, Math.min(left, document.documentElement.clientWidth - w - 8));
            const above = r.top - h - 8;
            tip.style.left = left + 'px';
            tip.style.top = (above > 8 ? above : r.bottom + 8) + 'px';
        };
        const hide = () => { if (tip) tip.classList.remove('is-visible'); };
        const target = e => e.target.closest && e.target.closest('[data-z82-tip]');

        document.addEventListener('mouseover', e => { const el = target(e); if (el) show(el); });
        document.addEventListener('mouseout', e => { const el = target(e); if (el && !el.contains(e.relatedTarget)) hide(); });
        document.addEventListener('focusin', e => { const el = target(e); if (el) show(el); });
        document.addEventListener('focusout', hide);
        window.addEventListener('scroll', hide, { passive: true });
        // Keep the text current right after a click toggles the bell
        document.addEventListener('click', e => { const el = target(e); if (el && tip && tip.classList.contains('is-visible')) setTimeout(() => show(el), 0); });
    }

    let toastTimer = null;
    function toast(text) {
        let el = document.querySelector('.z82-toast');
        if (!el) {
            el = document.createElement('div');
            el.className = 'z82-toast';
            el.setAttribute('role', 'status');
            el.setAttribute('aria-live', 'polite');
            document.body.appendChild(el);
        }
        el.textContent = text;
        el.classList.add('is-visible');
        clearTimeout(toastTimer);
        toastTimer = setTimeout(() => el.classList.remove('is-visible'), 4000);
    }

    function pushSupported() {
        const cfg = pushCfg();
        return !!(cfg.enabled && cfg.key && window.isSecureContext &&
                  'serviceWorker' in navigator && 'PushManager' in window);
    }

    let swReady = null;
    function getServiceWorker() {
        if (!swReady) {
            const cfg = pushCfg();
            swReady = navigator.serviceWorker.register(cfg.sw, { scope: cfg.scope || '/' })
                .then(() => navigator.serviceWorker.ready);
        }
        return swReady;
    }

    function b64uToBytes(str) {
        const bin = atob((str + '='.repeat((4 - str.length % 4) % 4)).replace(/-/g, '+').replace(/_/g, '/'));
        return Uint8Array.from(bin, ch => ch.charCodeAt(0));
    }

    function getSubscription() {
        return getServiceWorker().then(reg => reg.pushManager.getSubscription().then(sub =>
            sub || reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: b64uToBytes(pushCfg().key) })
        ));
    }

    function sendReminder(sub, matchId, on) {
        const body = new URLSearchParams();
        body.append('action', 'z82_push_remind');
        body.append('subscription', JSON.stringify(sub));
        body.append('match_id', matchId);
        body.append('on', on ? '1' : '0');
        return fetch(window.z82Config.ajaxUrl, { method: 'POST', body: body, credentials: 'same-origin' })
            .then(r => r.json());
    }

    // Old Safari only supports the callback form
    function askPermission() {
        if (Notification.permission === 'granted' || Notification.permission === 'denied') {
            return Promise.resolve(Notification.permission);
        }
        return new Promise(resolve => {
            const p = Notification.requestPermission(resolve);
            if (p && p.then) p.then(resolve);
        });
    }

    window.z82ToggleReminder = function(btn) {
        const id = btn.getAttribute('data-remind');
        const rem = loadReminders();

        if (rem[id]) {
            const was = rem[id];
            delete rem[id];
            saveReminders(rem);
            syncBells();
            toast('已取消开播提醒');
            if (was.push && pushSupported()) {
                getServiceWorker()
                    .then(reg => reg.pushManager.getSubscription())
                    .then(sub => sub && sendReminder(sub, id, false))
                    .catch(() => {});
            }
            return;
        }

        // Save first: the bell stays on even if the browser can't show notifications —
        // then the reminder appears inside the page instead
        rem[id] = {
            start: Number(btn.getAttribute('data-start')),
            title: btn.getAttribute('data-title') || '',
            league: btn.getAttribute('data-league') || '',
            push: false
        };
        saveReminders(rem);
        syncBells();

        const when = leadText();
        const inPage = '已设置提醒 · 保持本页打开，' + when + '会在页面上提醒你';

        // Notifications need HTTPS and browser support
        if (!('Notification' in window) || !window.isSecureContext) {
            toast(inPage);
            return;
        }

        askPermission().then(permission => {
            if (permission !== 'granted') {
                toast('浏览器通知已被关闭，' + when + '会在本页提醒你。可在地址栏左侧的网站设置中允许通知');
                return;
            }

            const localOnly = '已设置提醒 · 保持本页打开，' + when + '通知你';
            if (!pushSupported()) { toast(localOnly); return; }

            btn.classList.add('is-busy');
            getSubscription()
                .then(sub => sendReminder(sub, id, true))
                .then(res => {
                    const current = loadReminders();
                    if (!current[id]) return;
                    if (res && res.success) {
                        current[id].push = true;
                        saveReminders(current);
                        toast('已设置提醒 · ' + when + '通知你，关闭网页也能收到');
                    } else {
                        toast((res && res.data && res.data.message) ? res.data.message : localOnly);
                    }
                })
                // Push service unreachable (e.g. blocked network): the in-page reminder still works
                .catch(() => toast(localOnly))
                .then(() => btn.classList.remove('is-busy'));
        });
    };

    function showLocalNotification(id, r) {
        const cfg = pushCfg();
        const mins = Math.max(0, Math.round((r.start - Date.now() / 1000) / 60));
        const title = r.title || '比赛即将开始';
        const url = location.origin + location.pathname + '#' + id;
        const options = {
            body: (mins > 0 ? mins + ' 分钟后开赛' : '比赛已开始') + (r.league ? ' · ' + r.league : '') + ' — 点击观看直播',
            icon: cfg.icon || undefined,
            tag: id,
            requireInteraction: true,
            data: { url: url }
        };
        // Service-worker notifications also work on Android, where `new Notification` throws
        if (navigator.serviceWorker && navigator.serviceWorker.controller) {
            navigator.serviceWorker.ready.then(reg => reg.showNotification(title, options)).catch(() => {});
            return;
        }
        try {
            const n = new Notification(title, options);
            n.onclick = () => { window.focus(); location.hash = id; n.close(); };
        } catch (e) {}
    }

    // Reminder banner inside the page, for browsers where system notifications aren't allowed
    function showInPageReminder(id, r) {
        const mins = Math.max(0, Math.round((r.start - Date.now() / 1000) / 60));
        const box = document.createElement('div');
        box.className = 'z82-reminder-banner';
        box.setAttribute('role', 'alert');
        box.innerHTML =
            '<div class="z82-reminder-text"><strong></strong><span></span></div>' +
            '<a class="z82-reminder-watch" href="#' + id + '">观看</a>' +
            '<button type="button" class="z82-reminder-close" aria-label="关闭">×</button>';
        box.querySelector('strong').textContent = r.title || '比赛即将开始';
        box.querySelector('span').textContent = (mins > 0 ? mins + ' 分钟后开赛' : '比赛已开始') + (r.league ? ' · ' + r.league : '');
        box.addEventListener('click', e => {
            if (e.target.closest('.z82-reminder-watch, .z82-reminder-close')) box.remove();
        });
        document.body.appendChild(box);
    }

    // Due reminders that aren't on the push service: system notification if allowed,
    // otherwise a banner in the page
    function checkLocalReminders() {
        const canNotify = 'Notification' in window && window.isSecureContext && Notification.permission === 'granted';
        const rem = loadReminders();
        const now = Date.now() / 1000;
        const lead = (pushCfg().lead || 0) * 60;
        let changed = false;

        Object.keys(rem).forEach(id => {
            const r = rem[id];
            if (r.start < now - 7200) { delete rem[id]; changed = true; return; }   // old
            if (r.push || r.notified || r.start - lead > now) return;
            r.notified = true;
            changed = true;
            if (canNotify) showLocalNotification(id, r);
            else showInPageReminder(id, r);
        });

        if (changed) { saveReminders(rem); syncBells(); }
    }

    function initReminders() {
        initTooltips();
        syncBells();
        checkLocalReminders();
        setInterval(checkLocalReminders, 30000);

        if ('serviceWorker' in navigator) {
            navigator.serviceWorker.addEventListener('message', e => {
                const msg = e.data || {};
                // Notification clicked while this tab was open: jump to the match
                if (msg.type === 'z82_open' && msg.url) {
                    const url = new URL(msg.url, location.href);
                    if (url.pathname === location.pathname) location.hash = url.hash;
                    else location.href = url.href;
                }
            });
        }
    }

    // ── Animated previews (sourceGif) ────────────────────────
    // Desktop: the GIF plays over the screenshot while hovering / focusing a source card.
    // Touch: it plays on its own while the card is on screen. GIFs are only downloaded
    // when shown, and removed afterwards so the clip restarts next time.
    const canHover = !!(window.matchMedia && window.matchMedia('(hover: hover) and (pointer: fine)').matches);
    let gifObserver = null;

    function showGif(wrap) {
        if (wrap.querySelector('.z82-thumb-gif')) return;
        const img = document.createElement('img');
        img.className = 'z82-thumb-gif';
        img.alt = '';
        img.decoding = 'async';
        img.onload = () => img.classList.add('is-loaded');
        img.onerror = () => img.remove();   // keep the screenshot if the GIF is missing
        img.src = wrap.getAttribute('data-gif');
        // Below the LIVE tag and play button
        wrap.insertBefore(img, wrap.querySelector('.z82-thumb-live, .z82-play'));
    }

    function hideGif(wrap) {
        const img = wrap.querySelector('.z82-thumb-gif');
        if (img) img.remove();
    }

    function autoplayAllowed() {
        const reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
        const saveData = navigator.connection && navigator.connection.saveData;
        return !reduceMotion && !saveData;
    }

    function observeGifs(root) {
        if (canHover || !autoplayAllowed()) return;
        const thumbs = $$('.z82-thumb-wrap[data-gif]', root);
        if (!thumbs.length) return;
        if (!('IntersectionObserver' in window)) return;
        if (!gifObserver) {
            gifObserver = new IntersectionObserver(entries => {
                entries.forEach(e => (e.isIntersecting ? showGif(e.target) : hideGif(e.target)));
            }, { rootMargin: '100px 0px' });
        }
        thumbs.forEach(t => gifObserver.observe(t));
    }

    function unobserveGifs(root) {
        if (gifObserver) $$('.z82-thumb-wrap[data-gif]', root).forEach(t => gifObserver.unobserve(t));
    }

    function initGifPreviews() {
        if (canHover) {
            const toggle = (e, show) => {
                const card = e.target.closest && e.target.closest('.z82-popup-btn');
                if (!card || (e.relatedTarget && card.contains(e.relatedTarget))) return;
                const wrap = card.querySelector('.z82-thumb-wrap[data-gif]');
                if (wrap) (show ? showGif : hideGif)(wrap);
            };
            document.addEventListener('mouseover', e => toggle(e, true));
            document.addEventListener('mouseout', e => toggle(e, false));
            document.addEventListener('focusin', e => toggle(e, true));
            document.addEventListener('focusout', e => toggle(e, false));
        } else {
            observeGifs(document);
        }
    }

    // ── YouTube ──────────────────────────────────────────────
    // Nothing from YouTube loads until the browser proves youtube.com is reachable (it's
    // blocked in mainland China). Then: YouTube sources play embedded inside their row
    // (tabs when there are several), and a live match with YouTube autoplays above the
    // list. Only one video plays at a time.
    let ytOk = null;              // null = not checked yet
    let featured = null;          // { el, iframe, embed, started, autoplay }

    // What each video turned out to be, kept for a while (per tab):
    //   live  — plays, and is a live stream right now
    //   ended — plays, but the stream is over (a replay)
    //   dead  — errors, needs sign-in (bot check), or never starts
    //   signin — YouTube wants this viewer to sign in first (bot check): listed, opens on YouTube
    const YT_TTL = { live: 3 * 60 * 1000, ended: 60 * 60 * 1000, dead: 10 * 60 * 1000, signin: 10 * 60 * 1000 };
    const YT_START_TIMEOUT = 15000;
    // ?z82yt=debug — forget cached results and log every decision to the console
    const ytDebug = /[?&]z82yt=debug\b/.test(location.search);
    const ytLog = (...args) => { if (ytDebug) console.log('%c[z82 YouTube]', 'color:#d97706;font-weight:bold', ...args); };
    if (ytDebug) {
        try { sessionStorage.removeItem('z82-yt-verdicts'); sessionStorage.removeItem('z82-yt'); } catch (e) {}
    }
    const ytVerdicts = (() => {
        try {
            const saved = JSON.parse(sessionStorage.getItem('z82-yt-verdicts') || '{}');
            Object.keys(saved).forEach(k => { if (Date.now() - saved[k].t > (YT_TTL[saved[k].v] || 0)) delete saved[k]; });
            return saved;
        } catch (e) { return {}; }
    })();
    const ytWatchers = new Map(); // iframe → watcher

    function verdictOf(embed) {
        const r = embed && ytVerdicts[embed];
        return r && Date.now() - r.t < (YT_TTL[r.v] || 0) ? r.v : null;
    }

    function setVerdict(embed, v, why) {
        ytLog(v.toUpperCase(), embed, why || '');
        ytVerdicts[embed] = { v: v, t: Date.now(), why: why || '' };
        try { sessionStorage.setItem('z82-yt-verdicts', JSON.stringify(ytVerdicts)); } catch (e) {}
    }

    function isDead(embed) {
        return verdictOf(embed) === 'dead';
    }

    function markDead(embed, why) {
        setVerdict(embed, 'dead', why);
    }

    // Posters: YouTube's sharp 16:9 thumbnail (hq720), or the small one for videos without it
    function setPoster(img, url) {
        if (!img || !url) return;
        // A missing hq720 comes back as YouTube's 120×90 grey placeholder (or an error)
        const smaller = () => {
            if (!/\/hq720\.jpg$/.test(img.src)) return;
            img.src = img.src.replace(/\/hq720\.jpg$/, '/hqdefault.jpg');
        };
        img.onerror = smaller;
        img.onload = () => { if (img.naturalWidth && img.naturalWidth <= 120) smaller(); };
        img.src = url;
    }

    // The block's "open on YouTube" link follows the video shown
    function setWatchLink(player, url) {
        if (!player || !url) return;
        player.setAttribute('data-watch', url);
        const block = player.closest('[data-yt-block]');
        const link = block && $('.z82-yt-out', block);
        if (link) link.href = url;
    }

    // A video the visitor opened that YouTube won't start here (e.g. it asks this viewer to sign
    // in, which can't work inside the frame): say so and offer it on YouTube, instead of leaving
    // YouTube's error page or silently removing the player
    function showYtFallback(player, text) {
        const old = $('iframe', player);
        if (old) old.remove();
        player.classList.remove('is-playing');
        if ($('.z82-yt-fallback', player)) return;
        const box = document.createElement('div');
        box.className = 'z82-yt-fallback';
        const msg = document.createElement('p');
        msg.textContent = text || '此视频无法在本页播放';
        const a = document.createElement('a');
        a.href = player.getAttribute('data-watch') || 'https://www.youtube.com/';
        a.target = '_blank';
        a.rel = 'noopener noreferrer';
        a.textContent = '在 YouTube 观看 ↗';
        box.appendChild(msg);
        box.appendChild(a);
        player.appendChild(box);
    }

    function checkYouTube() {
        try {
            const cached = JSON.parse(sessionStorage.getItem('z82-yt') || 'null');
            if (cached && Date.now() - cached.t < 5 * 60 * 1000) return Promise.resolve(cached.ok);
        } catch (e) {}
        return new Promise(resolve => {
            let done = false;
            const finish = ok => {
                if (done) return;
                done = true;
                clearTimeout(timer);
                try { sessionStorage.setItem('z82-yt', JSON.stringify({ ok: ok, t: Date.now() })); } catch (e) {}
                ytLog('youtube.com reachable:', ok);
                resolve(ok);
            };
            const timer = setTimeout(() => finish(false), 3500);
            const img = new Image();
            img.onload = () => finish(true);
            img.onerror = () => finish(false);
            img.src = 'https://www.youtube.com/favicon.ico?z82=' + Date.now();
        });
    }

    function ytEmbedUrl(base, opts) {
        const params = new URLSearchParams({
            autoplay: opts.autoplay ? '1' : '0',
            mute: opts.mute ? '1' : '0',
            playsinline: '1',
            rel: '0',
            modestbranding: '1',
            enablejsapi: '1',
            origin: location.origin
        });
        return base + (base.indexOf('?') === -1 ? '?' : '&') + params.toString();
    }

    function ytIframe(src) {
        const f = document.createElement('iframe');
        f.src = src;
        f.title = 'YouTube';
        f.setAttribute('allow', 'autoplay; encrypted-media; picture-in-picture; fullscreen');
        f.setAttribute('allowfullscreen', '');
        f.setAttribute('referrerpolicy', 'strict-origin-when-cross-origin');
        return f;
    }

    function ytCommand(iframe, func) {
        try {
            iframe.contentWindow.postMessage(JSON.stringify({ event: 'command', func: func, args: [] }), '*');
        } catch (e) {}
    }

    // Watch a player: it's dead if YouTube reports an error, or if it doesn't come up in
    // time — "up" means playing when it autoplays muted (reliable), otherwise just ready.
    function ytWatch(iframe, embed, needPlay) {
        const w = { embed: embed, needPlay: needPlay, ready: false, playing: false, timer: null };
        const fail = why => {
            if (!ytWatchers.has(iframe)) return;
            ytWatchers.delete(iframe);
            markDead(embed, why || "shown player failed to start");
            // The row the visitor has open keeps its player, with the way out to YouTube
            const player = iframe.closest('.z82-yt-player');
            const openRow = player && document.body.contains(iframe) ? player.closest('.z82-match-row') : null;
            if (openRow) showYtFallback(player);
            dropDeadVideos(null, openRow);
        };
        w.fail = fail;
        w.restart = needPlay => {
            w.needPlay = needPlay;
            clearTimeout(w.timer);
            w.timer = setTimeout(() => {
                if (!document.body.contains(iframe)) { ytWatchers.delete(iframe); return; }
                if (w.playing || (!w.needPlay && w.ready)) return;
                // Background tabs hold autoplay back — wait until the page is seen
                if (document.hidden) { w.restart(w.needPlay); return; }
                fail();
            }, YT_START_TIMEOUT);
        };
        iframe.addEventListener('load', () => {
            // Ask the player to report its events
            try {
                iframe.contentWindow.postMessage(JSON.stringify({ event: 'listening', id: 'z82', channel: 'widget' }), '*');
            } catch (e) {}
        });
        ytWatchers.set(iframe, w);
        w.restart(needPlay);
        return w;
    }

    function ytMessage(e) {
        let w = null;
        ytWatchers.forEach((v, f) => { if (f.contentWindow === e.source) w = v; });
        if (!w) return;
        let data = e.data;
        if (typeof data === 'string') { try { data = JSON.parse(data); } catch (err) { return; } }
        if (!data || !data.event) return;
        if (data.event === 'onError') { w.fail('player error ' + data.info); return; }
        w.ready = true;
        const state = data.event === 'onStateChange' ? data.info : (data.info && data.info.playerState);
        if (state === 1) w.playing = true;
        if (w.onUp && (w.playing || !w.needPlay)) { const up = w.onUp; w.onUp = null; up(); }
        // A live stream that reaches "ended" while watched has finished
        if (state === 0 && verdictOf(w.embed) === 'live') videoEnded(w.embed);
    }

    // ── Probing: is a live match's video really live, over, or unplayable here? ──
    // A hidden, muted player starts the video just long enough to tell, then goes away.
    // - An error (incl. YouTube's "confirm you're not a bot") or no start → dead
    // - Starts, and had a length before playing (a finished stream's replay) → ended
    // - Starts otherwise → live
    const YT_PROBE_MAX = 4;
    const ytProbes = {};          // embed → pending Promise
    const probeQueue = [];
    let probeActive = 0;
    let probeHost = null;

    function probeVideo(embed) {
        const known = verdictOf(embed);
        if (known) return Promise.resolve(known);
        if (ytProbes[embed]) return ytProbes[embed];
        return (ytProbes[embed] = new Promise(resolve => {
            probeQueue.push(() => runProbe(embed, (v, why) => {
                delete ytProbes[embed];
                setVerdict(embed, v, why);
                resolve(v);
            }));
            pumpProbes();
        }));
    }

    function pumpProbes() {
        while (probeActive < YT_PROBE_MAX && probeQueue.length) {
            probeActive++;
            probeQueue.shift()();
        }
    }

    function runProbe(embed, done) {
        if (!probeHost) {
            probeHost = document.createElement('div');
            probeHost.className = 'z82-yt-probes';
            probeHost.setAttribute('aria-hidden', 'true');
            document.body.appendChild(probeHost);
        }
        const f = ytIframe(ytEmbedUrl(embed, { autoplay: true, mute: true }));
        f.tabIndex = -1;
        let videoData = {}, lengthBeforePlay = 0, timer = null, finished = false;

        const finish = v => {
            if (finished) return;
            finished = true;
            clearTimeout(timer);
            window.removeEventListener('message', onMessage);
            f.remove();
            probeActive--;
            pumpProbes();
            done(v, finishWhy);
        };
        let finishWhy = '', lastState = null;
        const finishWith = (v, why) => { finishWhy = why; finish(v); };
        const onMessage = e => {
            if (e.source !== f.contentWindow) return;
            let d = e.data;
            if (typeof d === 'string') { try { d = JSON.parse(d); } catch (err) { return; } }
            if (!d || !d.event) return;
            if (d.event === 'onError') { finishWith('dead', 'player error ' + d.info); return; }
            const info = d.info && typeof d.info === 'object' ? d.info : {};
            if (info.videoData) videoData = info.videoData;
            const state = d.event === 'onStateChange' ? d.info : info.playerState;
            if (state !== undefined) lastState = state;
            if (videoData.errorCode) {
                // "Sign in to confirm you're not a bot": YouTube challenges this viewer's network (often a
                // VPN), not the video — it plays on youtube.com after the check, just not embedded here
                if (videoData.errorCode === 'auth') finishWith('signin', 'YouTube wants sign-in ("confirm you\'re not a bot") — watch on YouTube');
                else finishWith('dead', 'error ' + videoData.errorCode);
                return;
            }
            if (videoData.isPlayable === false) { finishWith('dead', 'not playable'); return; }
            if (state !== 1) {
                if (typeof info.duration === 'number') lengthBeforePlay = info.duration;
                return;
            }
            if (videoData.isLive || !(lengthBeforePlay > 0)) finishWith('live', 'playing live');
            else finishWith('ended', 'replay, ' + Math.round(lengthBeforePlay / 60) + ' min long');
        };
        const arm = () => {
            // Background tabs hold autoplay back — wait until the page is seen
            timer = setTimeout(() => {
                if (document.hidden) arm();
                else finishWith('dead', 'did not start within ' + (YT_START_TIMEOUT / 1000) + 's (player state ' + lastState + ')');
            }, YT_START_TIMEOUT);
        };

        window.addEventListener('message', onMessage);
        f.addEventListener('load', () => {
            try { f.contentWindow.postMessage(JSON.stringify({ event: 'listening', id: 'z82-probe', channel: 'widget' }), '*'); } catch (err) {}
        });
        arm();
        probeHost.appendChild(f);
    }

    // Every video of a row, whatever its state
    function rowEmbeds(row) {
        const tabs = $$('.z82-yt-tab', row);
        if (tabs.length) return tabs.map(t => t.getAttribute('data-embed'));
        const p = $('.z82-yt-player', row);
        return p ? [p.getAttribute('data-embed')] : [];
    }

    function updateYtCount(row) {
        const others = parseInt(row.getAttribute('data-other-count'), 10) || 0;
        const count = $('.z82-sources-count', row);
        if (count) count.textContent = (others + readRowVideos(row).length) + '个直播';
        if (others === 0 && !readRowVideos(row).length) row.classList.add('z82-yt-hidden');
    }

    // Keep only the row's videos that pass keep(embed): drop tabs, or the whole block
    function pruneRow(row, keep) {
        const block = $('[data-yt-block]', row);
        if (!block) return;
        const player = $('.z82-yt-player', block);
        const tabs = $$('.z82-yt-tab', block);
        let changed = false;
        tabs.forEach(t => { if (!keep(t.getAttribute('data-embed'))) { t.remove(); changed = true; } });
        const left = $$('.z82-yt-tab', block);

        if (tabs.length ? !left.length : !keep(player.getAttribute('data-embed'))) {
            block.remove();
            updateYtCount(row);
            return;
        }
        if (left.length && !keep(player.getAttribute('data-embed'))) {
            // The shown video went: move to the next one (restarting it if the row is playing)
            if ($('iframe', player)) ytSwitchTab(left[0]);
            else {
                left.forEach((t, i) => t.classList.toggle('is-active', i === 0));
                player.setAttribute('data-embed', left[0].getAttribute('data-embed'));
                setWatchLink(player, left[0].getAttribute('data-watch'));
                setPoster($('.z82-yt-poster', player), left[0].getAttribute('data-thumb'));
            }
        }
        if (left.length === 1) { const bar = $('.z82-yt-tabs', block); if (bar) bar.remove(); }
        if (changed) updateYtCount(row);
    }

    // Remove dead videos from rows, then fix whatever was playing them
    function dropDeadVideos(root, keepRow) {
        $$('.z82-match-row.z82-has-yt', root || document).forEach(row => {
            if (row !== keepRow) pruneRow(row, e => !isDead(e));
        });
        checkFeatured();
    }

    function checkFeatured() {
        if (!featured) return;
        const v = verdictOf(featured.embed);
        if (v === 'dead' || v === 'ended') nextFeatured();
    }

    // A live match once its videos are probed: keep the live ones. If only replays are left
    // the stream is over, so a YouTube-only match is shown as ended. Nothing playable → the
    // videos go, and a YouTube-only match with them.
    function settleRow(row) {
        const others = parseInt(row.getAttribute('data-other-count'), 10) || 0;
        const verdicts = rowEmbeds(row).map(verdictOf);
        ytLog('match "' + (($('.z82-teams', row) || {}).textContent || '').trim() + '":',
            verdicts.indexOf('live') !== -1 ? 'LIVE — shown (can be the main video)'
                : verdicts.indexOf('signin') !== -1 ? 'LIVE, but YouTube wants sign-in here — shown, opens on YouTube'
                : verdicts.indexOf('ended') !== -1 && others === 0 ? 'stream over — shown as ended'
                : others ? 'no playable YouTube — other sources only' : 'no playable YouTube — hidden',
            verdicts);
        row.classList.remove('z82-yt-pending');
        if (verdicts.indexOf('live') !== -1) {
            pruneRow(row, e => verdictOf(e) === 'live');
            row.setAttribute('data-yt-live', '1');
        } else if (verdicts.indexOf('signin') !== -1) {
            // Live on YouTube, but YouTube won't play it embedded for this viewer: keep the match
            // listed; opening it offers the stream on YouTube (not a main/featured video)
            pruneRow(row, e => verdictOf(e) === 'signin');
            row.removeAttribute('data-yt-live');
        } else if (verdicts.indexOf('ended') !== -1 && others === 0) {
            pruneRow(row, e => verdictOf(e) === 'ended');
            row.removeAttribute('data-yt-live');
            markRowEnded(row);
        } else {
            pruneRow(row, () => false);
            row.removeAttribute('data-yt-live');
        }
        const block = $('[data-yt-block]', row);
        if (block) block.hidden = false;
        if (row.getAttribute('data-match-id') === currentOpenRow) ytRowToggled(row, true);

        // The featured player starts with the first verified live match; later ones join as chips
        const wrapper = row.closest('.z82-wrapper');
        if (featured) renderFeaturedChips();
        else if (row.getAttribute('data-yt-live') && wrapper) buildFeatured(wrapper);
    }

    function videoEnded(embed) {
        setVerdict(embed, 'ended');
        $$('.z82-match-row.live.z82-has-yt').forEach(r => { if (rowEmbeds(r).indexOf(embed) !== -1) settleRow(r); });
        checkFeatured();
    }

    // Live → ended in place: badge, state, and moved up to the other ended matches
    function markRowEnded(row) {
        row.classList.remove('live');
        row.classList.add('finished');
        row.setAttribute('data-is-finished', '1');
        const badge = $('.z82-row-right .z82-live-badge', row);
        if (badge) {
            const s = document.createElement('span');
            s.className = 'z82-ended-badge';
            s.textContent = '已结束';
            badge.replaceWith(s);
        }
        const container = row.parentNode;
        if (!container) return;
        // Just ended → the most recent: first of the ended group
        const toggle = document.getElementById('z82-show-ended-again');
        const first = $$('.z82-match-row[data-is-finished="1"]', container).find(r => r !== row);
        if (toggle && toggle.parentNode === container) toggle.after(row);
        else if (first) first.before(row);
        else container.insertBefore(row, container.firstChild);
        capEndedRows(container);
    }

    // Same as the server: 3 ended matches visible, the rest behind the "显示全部" toggle
    const ENDED_VISIBLE = 3;
    function capEndedRows(container) {
        const ended = $$('.z82-match-row[data-is-finished="1"]', container);
        let toggle = document.getElementById('z82-show-ended-again');
        if (ended.length <= ENDED_VISIBLE && !toggle) return;
        if (!toggle) {
            toggle = document.createElement('button');
            toggle.type = 'button';
            toggle.className = 'z82-ended-info';
            toggle.id = 'z82-show-ended-again';
            toggle.setAttribute('aria-expanded', 'false');
            toggle.setAttribute('onclick', 'z82ShowAllEnded()');
            toggle.innerHTML = '<span class="z82-ended-info-label" data-hide="收起已结束的比赛"></span>' +
                '<svg class="z82-icon z82-ended-info-chevron" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>';
            container.insertBefore(toggle, container.firstChild);
        }
        const expanded = toggle.getAttribute('aria-expanded') === 'true';
        ended.forEach((r, i) => {
            if (i < ENDED_VISIBLE) {
                r.classList.remove('z82-match-hidden');
                r.removeAttribute('data-ended-collapsible');
            } else {
                r.setAttribute('data-ended-collapsible', '1');
                r.classList.toggle('z82-match-hidden', !expanded);
            }
        });
        const label = $('.z82-ended-info-label', toggle);
        if (label) {
            label.setAttribute('data-show', '显示全部 ' + ended.length + ' 场已结束的比赛');
            label.textContent = label.getAttribute(expanded ? 'data-hide' : 'data-show');
        }
    }

    // Show or drop the YouTube parts of a table once the check is done. Resolves when every
    // live match with YouTube has been probed and settled.
    function applyYouTube(root) {
        if (ytOk === null) return Promise.resolve();
        const jobs = [];
        $$('.z82-match-row.z82-has-yt', root).forEach(row => {
            const block = $('[data-yt-block]', row);
            if (!ytOk) {
                // Blocked: remove the YouTube player, fix the count, hide YouTube-only matches
                if (block) block.remove();
                updateYtCount(row);
                row.classList.remove('z82-yt-pending');
                return;
            }
            const poster = block && $('.z82-yt-poster', block);
            if (poster && !poster.src && poster.getAttribute('data-src')) setPoster(poster, poster.getAttribute('data-src'));
            if (!row.classList.contains('live')) {
                // Not live: nothing to verify yet
                if (block) block.hidden = false;
                row.classList.remove('z82-yt-pending');
                return;
            }
            jobs.push(Promise.all(rowEmbeds(row).map(probeVideo)).then(() => settleRow(row)));
        });
        if (ytOk) dropDeadVideos(root);
        return Promise.all(jobs);
    }

    // Row opened/closed: start or stop its embedded video
    function ytRowToggled(row, open) {
        const player = $('.z82-yt-player', row);
        if (!player) return;
        const iframe = $('iframe', player);
        if (!open) {
            if (iframe) iframe.remove();
            const fb = $('.z82-yt-fallback', player);
            if (fb) fb.remove();
            player.classList.remove('is-playing');
            // A video that failed while the row was open goes now, like everywhere else
            if (isDead(player.getAttribute('data-embed'))) pruneRow(row, e => !isDead(e));
            return;
        }
        // Not until its video is verified (the block stays hidden till then)
        const block = player.closest('[data-yt-block]');
        if (!ytOk || iframe || (block && block.hidden)) return;
        startRowVideo(player, player.getAttribute('data-embed'));
    }

    // Unmuted autoplay may be refused by the browser, so a row video only has to load
    function startRowVideo(player, embed) {
        // YouTube wants this viewer to sign in first: an embed would only show its challenge
        if (verdictOf(embed) === 'signin') { showYtFallback(player, 'YouTube 需要验证后才能观看'); return; }
        const f = ytIframe(ytEmbedUrl(embed, { autoplay: true }));
        ytWatch(f, embed, false);
        player.appendChild(f);
        player.classList.add('is-playing');
    }

    function ytSwitchTab(tab) {
        const block = tab.closest('[data-yt-block]');
        const player = block && $('.z82-yt-player', block);
        if (!player) return;
        $$('.z82-yt-tab', block).forEach(t => {
            const on = t === tab;
            t.classList.toggle('is-active', on);
            t.setAttribute('aria-selected', on ? 'true' : 'false');
        });
        player.setAttribute('data-embed', tab.getAttribute('data-embed'));
        setWatchLink(player, tab.getAttribute('data-watch'));
        setPoster($('.z82-yt-poster', player), tab.getAttribute('data-thumb'));
        const old = $('iframe', player);
        if (old) old.remove();
        const fb = $('.z82-yt-fallback', player);
        if (fb) fb.remove();
        startRowVideo(player, tab.getAttribute('data-embed'));
    }

    // ── Featured live match above the list ──
    function featuredCandidates() {
        // Only matches whose YouTube stream was verified live
        return $$('.z82-match-row.live.z82-has-yt[data-yt-live="1"]')
            .filter(r => !r.classList.contains('z82-yt-hidden') && readRowVideos(r).some(v => verdictOf(v.embed) === 'live'));
    }

    function readRowVideos(row) {
        const tabs = $$('.z82-yt-tab', row);
        if (tabs.length) {
            return tabs.filter(t => !isDead(t.getAttribute('data-embed'))).map(t => ({
                embed: t.getAttribute('data-embed'),
                label: ($('.z82-yt-tab-label', t) || t).textContent.trim()
            }));
        }
        const p = $('.z82-yt-player', row);
        return p && !isDead(p.getAttribute('data-embed')) ? [{ embed: p.getAttribute('data-embed'), label: '' }] : [];
    }

    function playFeatured(row, autoplay) {
        if (!featured) return;
        const videos = readRowVideos(row);
        if (!videos.length) return;
        const el = featured.el;
        $('.z82-featured-title', el).textContent = ($('.z82-teams', row) || {}).textContent || '';
        $('.z82-featured-league', el).textContent = ($('.z82-league', row) || {}).textContent.trim();
        el.setAttribute('data-match', row.getAttribute('data-match-id'));

        // Tabs for several YouTube sources of the same match
        const tabs = $('.z82-featured-tabs', el);
        tabs.innerHTML = '';
        if (videos.length > 1) {
            videos.forEach((v, i) => {
                const b = document.createElement('button');
                b.type = 'button';
                b.className = 'z82-yt-tab' + (i === 0 ? ' is-active' : '');
                b.textContent = '直播' + (i + 1) + (v.label ? ' · ' + v.label : '');
                b.addEventListener('click', () => {
                    $$('.z82-yt-tab', tabs).forEach(x => x.classList.toggle('is-active', x === b));
                    loadFeatured(v.embed, true);
                });
                tabs.appendChild(b);
            });
        }
        tabs.hidden = videos.length < 2;

        // Chips to switch to other live YouTube matches
        $$('.z82-featured-chip', el).forEach(c => c.classList.toggle('is-active', c.getAttribute('data-match') === row.getAttribute('data-match-id')));
        loadFeatured(videos[0].embed, autoplay);
    }

    function loadFeatured(embed, autoplay) {
        const player = $('.z82-featured-player', featured.el);
        if (featured.iframe) { ytWatchers.delete(featured.iframe); featured.iframe.remove(); }
        // Muted: browsers only allow autoplay without sound
        featured.iframe = ytIframe(ytEmbedUrl(embed, { autoplay: autoplay, mute: autoplay }));
        featured.embed = embed;
        featured.started = false;
        featured.autoplay = !!autoplay;
        featured.watch = ytWatch(featured.iframe, embed, !!autoplay);
        featured.watch.onUp = () => {
            if (!featured) return;
            featured.el.classList.remove('is-pending');
            featured.el.style.width = '';
        };
        player.appendChild(featured.iframe);
    }

    function pauseFeatured() {
        if (!featured || !featured.iframe) return;
        if (featured.started) {
            ytCommand(featured.iframe, 'pauseVideo');
        } else {
            // Not playing yet: reload without autoplay so it can't start behind the open row
            featured.autoplay = false;
            featured.watch.ready = false;
            featured.watch.restart(false);
            featured.iframe.src = featured.iframe.src.replace('autoplay=1', 'autoplay=0');
        }
    }

    // The featured video died: next video of the same match, else the next live match,
    // else drop the whole section
    function nextFeatured() {
        const candidates = featuredCandidates();
        const same = getRow(featured.el.getAttribute('data-match'));
        const row = candidates.indexOf(same) !== -1 ? same : candidates[0];
        renderFeaturedChips();
        if (row) { playFeatured(row, featured.autoplay); return; }
        if (featured.iframe) ytWatchers.delete(featured.iframe);
        featured.el.remove();
        featured = null;
    }

    function renderFeaturedChips() {
        const el = featured.el;
        const rows = featuredCandidates();
        let chips = $('.z82-featured-chips', el);
        if (rows.length < 2) { if (chips) chips.remove(); return; }
        if (!chips) {
            chips = document.createElement('div');
            chips.className = 'z82-featured-chips';
            el.insertBefore(chips, $('.z82-featured-tabs', el));
        }
        chips.innerHTML = '';
        rows.slice(0, 8).forEach(r => {
            const b = document.createElement('button');
            b.type = 'button';
            b.className = 'z82-featured-chip';
            b.setAttribute('data-match', r.getAttribute('data-match-id'));
            b.classList.toggle('is-active', r.getAttribute('data-match-id') === el.getAttribute('data-match'));
            b.textContent = ($('.z82-teams', r) || {}).textContent || '';
            b.addEventListener('click', () => {
                const target = getRow(b.getAttribute('data-match'));
                if (currentOpenRow) toggleRow(currentOpenRow);
                if (target) playFeatured(target, true);
            });
            chips.appendChild(b);
        });
    }

    function buildFeatured(wrapper) {
        const rows = featuredCandidates();
        if (!rows.length || featured) return;

        const el = document.createElement('section');
        el.className = 'z82-featured is-pending';
        el.setAttribute('aria-label', '正在直播');
        el.innerHTML =
            '<div class="z82-featured-head">' +
                '<span class="z82-live-badge"><span class="z82-live-dot" aria-hidden="true"></span>直播中</span>' +
                '<div class="z82-featured-meta"><strong class="z82-featured-title"></strong><span class="z82-featured-league"></span></div>' +
            '</div>' +
            '<div class="z82-yt-tabs z82-featured-tabs" hidden></div>' +
            '<div class="z82-featured-player"></div>';

        // Outside the table (right above the filters), so the 3-minute refresh never restarts
        // the video. Invisible until a video actually comes up — a dead one is never shown.
        el.style.width = wrapper.offsetWidth + 'px';
        wrapper.parentNode.insertBefore(el, wrapper);
        featured = { el: el, iframe: null, started: false };
        renderFeaturedChips();

        // Don't autoplay over a shared link to a specific match
        const deepLink = /match-/.test(location.hash);
        playFeatured(rows[0], !deepLink);
    }

    function initYouTube() {
        if (!$('.z82-match-row.z82-has-yt')) return;

        // Tabs inside rows
        document.addEventListener('click', e => {
            const tab = e.target.closest('.z82-yt .z82-yt-tab');
            if (tab) ytSwitchTab(tab);
        });

        // Player events: errors / started (all watched players)
        window.addEventListener('message', ytMessage);

        // Featured player started playing (user pressed play) → close the open match
        window.addEventListener('message', e => {
            if (!featured || !featured.iframe || e.source !== featured.iframe.contentWindow) return;
            let data = e.data;
            if (typeof data === 'string') { try { data = JSON.parse(data); } catch (err) { return; } }
            const state = data && data.info && data.info.playerState;
            if (state === 1) {
                // The first "playing" of an autoplaying video is the autoplay itself, not the user
                const wasAutoStart = !featured.started && featured.autoplay;
                featured.started = true;
                if (!wasAutoStart && currentOpenRow) toggleRow(currentOpenRow);
            }
        });

        checkYouTube().then(ok => {
            ytOk = ok;
            // A row may already be open (deep link) — start its video now (live rows
            // start theirs once verified, in settleRow)
            const start = () => {
                const row = currentOpenRow && getRow(currentOpenRow);
                if (row && ok) ytRowToggled(row, true);
            };
            Promise.all($$('.z82-wrapper').map(w => {
                const done = applyYouTube(w);
                start();
                return done;
            })).then(() => {
                const wrapper = $('.z82-wrapper');
                if (ok && wrapper && !featured) buildFeatured(wrapper);
            });
        });
    }

    // ── Keyboard ─────────────────────────────────────────────
    function initKeyboard() {
        document.addEventListener('keydown', e => {
            if (e.key === 'Escape' && currentOpenRow) {
                toggleRow(currentOpenRow);
                return;
            }
            const header = e.target && e.target.closest && e.target.closest('.z82-row-header');
            if (header && e.target === header && (e.key === 'Enter' || e.key === ' ')) {
                e.preventDefault();
                header.click();
            }
        });
    }

    // ── Init ─────────────────────────────────────────────────
    function init() {
        if (!$('.z82-wrapper')) return;
        initFilterScroll();
        initKeyboard();
        applyRoute({ force: true });
        $$('.z82-wrapper').forEach(updateLoadMore);
        updateCountdowns();
        setInterval(updateCountdowns, 30000);
        initAutoRefresh();
        initReminders();
        initGifPreviews();
        initYouTube();
        document.addEventListener('z82:beforeopen', pauseFeatured);
        window.addEventListener('popstate', () => applyRoute());
        window.addEventListener('hashchange', () => applyRoute());
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
