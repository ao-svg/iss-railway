# Changelog

## 4.6.0 (2026-11-24)
- Manual channels that are a web page are shown in an iframe. The feed marks them (sourceEmbed): its
  /manual-channels page (or JSON) can now add a channel as an "embed" - a player page of a federation or
  league, Twitch, Vimeo... - next to plain stream links. The player page shows it in a frame (https pages
  only), sandboxed so it can run and play but cannot navigate the window or open pop-ups, with the site’s
  origin as Referer for embeds locked to a domain. The feed takes the thumbnail, as for any source.
  No automatic switch away from an embed (nothing can be measured from outside the frame); it never takes the
  "open the stream link itself" shortcut that HLS links get on browsers with native HLS. YouTube keeps its own player.
- Older plugins show an embed as a stream that fails: publish this version before adding embeds.

## 4.5.2 (2026-11-23)
- A copy of the feed that can no longer be downloaded stops showing old matches as live. zhibo82.com showed
  six games from 10 November as 直播中 for two weeks: its server was refused on the feed’s new public address,
  the plugin kept its last good copy without a word, and a row marked live stayed live whatever its age.
  - The feed is tried twice (as a browser, then as WordPress); why a download failed and when the last one
    worked are kept and sent with every hub check-in, so the hub shows the site and moves it to the feed’s
    direct address when the public one refuses it (HTTP 403).
  - A copy older than two hours loses its live rows; a row the feed marks live that started over 12 hours
    ago is not shown as live. Same rules as zhibo882 2.6.1.
- The feed’s own links (/go?u=… and /screenshots/…) are recognised on any address, not only the one the
  feed is downloaded from: YouTube sources wrapped in /go are played as YouTube again, and screenshots are
  served from this site, when the hub hands the server the direct address and the links use the public one.

## 4.5.1 (2026-11-04)
- Streams open in their own window again, as before 4.5.0: on browsers that play HLS themselves
  (Chrome 142+, Safari, Edge) the window opens the feed's /go link directly, which hands the browser
  the relay's playlist (checked: a relayed DAZN source plays at 1080p that way). No zhibo82 player
  page in between. Firefox and YouTube sources still use the player page (with its automatic switch).
- YouTube videos play on the page again when YouTube's hidden check asks for a sign-in: the row opens
  the embedded player instead of a "在 YouTube 观看" button. They still don't become the featured video.
  The small "无法播放？在 YouTube 观看" link stays under every player.

## 4.5.0 (2026-11-03)
- Sources that go through the feed’s relay are listed first (直播1, 直播2 …), direct hosts after them, in feed
  order within each group (the feed’s sourceVisitorPath). Direct hosts are often slow or never start outside
  the US: 9-23 s to the first picture from Israel, against 3-7 s for relayed ones.
- The player switches by itself: no picture 8 s after starting a source (one 4 s extension when video data is
  already arriving), or the source fails, and it plays the next one not yet tried, with a note such as
  “直播1 加载较慢，已自动切换到直播2”. After the last one it shows the error; 重试 goes round them once more.
- Every stream now opens the player page, browsers with native HLS (Chrome 142+, Safari) included: they used
  to open the stream link itself, where nothing could switch. The page plays with the browser’s own HLS player
  where there is one (no CORS needed, no Referer), hls.js elsewhere (?hlsjs=1 forces hls.js).
- Direct http:// hosts can’t play inside the https page (the browser blocks mixed content), so for those the
  window opens the stream itself, as before; the automatic switch tries them only after every other source,
  and only on browsers with native HLS.
- The source list reaches the player page through localStorage (one-time key in ?z82list=), so it no longer
  gets lost when the popup loads slowly; postMessage stays as the fallback.

## 4.4.3 (2026-11-03)
- Test release of the hub’s automatic install (no code change).

## 4.4.2 (2026-11-03)
- Live YouTube games stay listed when YouTube asks the viewer to sign in (“confirm you’re not a bot”,
  common on VPNs; youtube-nocookie gets it too). They used to count as dead, so every YouTube-only live
  game disappeared for those viewers. Now: shown as live; opening one says “YouTube 需要验证后才能观看”
  with a button to the stream on YouTube. They don’t become the featured video. Games whose videos are
  really unavailable or not live yet are still hidden.

## 4.4.1 (2026-11-01)
- Auto-updates from the hub no longer go through WordPress’s background updater, which skipped or
  rolled them back without telling anyone (zhibo82.com stayed on 4.3.4 for days with 4.4.0 offered).
  With auto-update on, the plugin installs the hub’s newer version with its own installer (the
  “update now” code), retries hourly after a failure, and sends the outcome with each check-in, so the
  hub’s sites page shows “update 4.4.x failed: <reason>”. zhibo882-streaming-table 2.5.1 does the same.

## 4.4.0 (2026-10-28)
- YouTube rows: embedded from youtube-nocookie.com (YouTube’s privacy-enhanced player). On youtube.com a
  sign-in check YouTube asks some viewers for loops inside the frame when the browser blocks Google’s
  cookies there (“accounts.google.com redirected you too many times”).
- A video the visitor opened that YouTube won’t start here now shows “此视频无法在本页播放” with a
  “在 YouTube 观看” button instead of YouTube’s error page; every YouTube block also has a small
  “无法播放？在 YouTube 观看” link under the player.
- YouTube posters use the sharp 16:9 thumbnail (hq720, 1280×720) instead of the blurry 480×360 one,
  falling back to it when a video has none.
- Feed down (e.g. while iss-railway restarts and answers 404 until its first run): the table keeps
  showing the last good copy and retries every minute, instead of “暂无比赛数据”. Same as zhibo882.
- Update now from the hub: zhibo82/v1/poke accepts {"update": true}. When the hub has a newer
  published version of this plugin, the site installs it right away in the background (WP-Cron)
  instead of at WordPress's next update check, and checks in with the new version. It only ever
  installs the hub's own published release. Used by the hub's POST /api/hub/update and
  `npm run hub -- update | release` in iss-railway.

## 4.3.5 (2026-10-25)
- Can be connected from the hub (“Add a site” on the hub’s WordPress sites page): new REST routes
  zhibo82/v1/connect and zhibo82/v1/status (administrators only — the hub calls them with a one-time
  Application Password from WordPress’s “Authorize Application” page, then deletes it) and
  zhibo82/v1/poke (public; only makes the site ask its own hub now). Same as the schedule plugin’s zhibo/v1/*.

## 4.3.4 (2026-10-19)
- Rows labelled 今天 / 明天 also show the date itself (m月d日), small under the time.
- A small note above the table: 时间均为北京时间（UTC+8）. zhibo882-streaming-table 2.3.3 shows both the same way.

## 4.3.3 (2026-10-19)
- Matches with no playable source (none in the feed, all dead, or only a "soon" placeholder) are no
  longer listed at all — upcoming ones included (they used to show as 即将上线). A match appears once
  the feed has a source for it. zhibo882-streaming-table keeps listing them as 即将上线, so zhibo882
  can show matches zhibo82 doesn't; its links to those land on zhibo82's page without that row.

## 4.3.2 (2026-10-19)
- Sources the feed marks dead (sourceWorking false) get no button: the feed’s /go answers 502 for them, so they
  could never play. Unknown (null) sources stay. A match left with no source is shown like one whose sources
  aren’t in yet: upcoming → 即将上线, live → not listed, ended → dropped. zhibo882-streaming-table 2.3.2 counts
  sources the same way, so both list the same matches. (On 2026-10-19: 342 of 608 feed sources dead.)

## 4.3.1 (2026-10-19, not released — included in 4.3.2)
- Ended matches: only those that ended in the last 2 hours, at most the 20 most recent, newest first
  (was every ended match still in the feed, oldest first — 87 on 2026-10-18). Still 3 visible, the rest
  behind “显示全部”. zhibo882-streaming-table 2.3.1+ uses the same rule, so both sites list the same matches.
- Live matches the page marks as ended (YouTube check) go to the top of the ended group and no longer
  push it past 3 visible rows; the “显示全部 N” count follows.
- Hub check-ins report the site’s public address. zhibo82.com’s server runs WP-cron with home_url() =
  https://127.0.0.1, so a check-in from a background job would have listed the site as “127.0.0.1”.
  An IP or localhost is now replaced by the last public address seen (option z82_public_home).

## 4.3.0 (2026-10-18)
- Streams play through the feed's own link (`https://<feed>/go?u=<link>`) instead of the raw CDN link.
  The feed re-resolves the link when it's opened and sends most sources through its relay, which
  fixes geo-blocked and no-CORS sources (measured from outside the US: 19 of 30 "working" sources
  play through it, 13 raw). Sources the feed never relays (doms9) are redirected to the raw link.
- Player page (`?z82_stream=1`, hls.js): if the feed link fails before playing, it tries the raw
  link once, then shows the usual error. Retry starts over from the feed link.
- The raw link is still used for YouTube detection, cached screenshot/GIF keys and the "soon" check.
- The player page no longer decodes an already-plain `url` a second time (it broke `/go?u=` links).
